import React, { useState, useEffect } from 'react';
import { useSettings } from '../context/SettingsContext';
import { WALLPAPERS, OS_NAME } from '../config/system';

const LoginClock: React.FC = () => {
    const [time, setTime] = useState(new Date());

    useEffect(() => {
        const timerId = setInterval(() => setTime(new Date()), 1000);
        return () => clearInterval(timerId);
    }, []);

    return (
        <div className="text-center text-white">
            <h1 className="text-8xl font-semibold tracking-tighter" style={{ textShadow: '0 4px 20px rgba(0,0,0,0.3)' }}>
                {time.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}
            </h1>
            <p className="text-2xl mt-2" style={{ textShadow: '0 2px 8px rgba(0,0,0,0.3)' }}>
                {time.toLocaleDateString([], { weekday: 'long', day: 'numeric', month: 'long' })}
            </p>
        </div>
    );
};

export const LoginScreen: React.FC = () => {
    const { users, login, signup } = useSettings();

    const hasRealUsers = users.some(u => !u.isAI);
    const [mode, setMode] = useState<'login' | 'signup'>(hasRealUsers ? 'login' : 'signup');
    
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');

    const handleLogin = (e: React.FormEvent) => {
        e.preventDefault();
        if (!username.trim() || !password.trim()) {
            setError('Username and password are required.');
            setTimeout(() => setError(''), 3000);
            return;
        }
        const result = login(username, password);
        if (!result.success) {
            setError(result.message || 'Login failed.');
            setTimeout(() => setError(''), 3000);
        }
    };
    
    const handleSignup = (e: React.FormEvent) => {
        e.preventDefault();
        if (!username.trim() || !password.trim()) {
            setError('Username and password are required.');
            setTimeout(() => setError(''), 3000);
            return;
        }
        const result = signup(username, password);
        if (!result.success) {
            setError(result.message || 'Signup failed.');
            setTimeout(() => setError(''), 3000);
        }
    };

    const switchMode = (newMode: 'login' | 'signup') => {
        setMode(newMode);
        setUsername('');
        setPassword('');
        setError('');
    };
    
    const defaultWallpaper = WALLPAPERS[0].url;

    return (
        <div 
            className="w-screen h-screen flex flex-col items-center bg-cover bg-center transition-all duration-500"
            style={{ backgroundImage: `url(${defaultWallpaper})` }}
        >
            <div className="absolute inset-0 bg-black/30 backdrop-blur-xl"></div>
            
            <div className="relative z-10 flex flex-col items-center h-full w-full justify-center">
                
                <div className="absolute top-16 animate-fade-in" style={{animationDelay: '200ms'}}>
                    <LoginClock />
                </div>

                <div className="bg-black/20 backdrop-blur-2xl p-8 rounded-2xl border border-white/10 w-80 flex flex-col items-center animate-fade-in transition-all">
                    {error && <div className="absolute -top-14 bg-red-500 text-white px-4 py-2 rounded-lg shadow-lg animate-fade-in">{error}</div>}
                    
                    {mode === 'login' ? (
                        <form onSubmit={handleLogin} className="w-full flex flex-col items-center">
                            <h1 className="text-3xl font-light text-white mb-6">Welcome to {OS_NAME}</h1>
                            <div className="w-full space-y-3">
                                <input
                                    type="text"
                                    value={username}
                                    onChange={e => setUsername(e.target.value)}
                                    placeholder="Username"
                                    autoFocus
                                    className="w-full text-center px-4 py-3 bg-white/10 text-white placeholder-white/60 rounded-xl border-2 border-white/20 focus:ring-2 focus:ring-white/50 focus:border-white/20 focus:outline-none transition-all backdrop-blur-md"
                                />
                                <input
                                    type="password"
                                    value={password}
                                    onChange={e => setPassword(e.target.value)}
                                    placeholder="Password"
                                    className="w-full text-center px-4 py-3 bg-white/10 text-white placeholder-white/60 rounded-xl border-2 border-white/20 focus:ring-2 focus:ring-white/50 focus:border-white/20 focus:outline-none transition-all backdrop-blur-md"
                                />
                            </div>
                            <button type="submit" className="mt-6 w-full py-3 bg-white/20 hover:bg-white/30 text-white rounded-full transition-colors font-semibold text-lg">Log In</button>
                            <button type="button" onClick={() => switchMode('signup')} className="text-sm text-white/80 hover:text-white mt-4">Don't have an account? Sign Up</button>
                        </form>
                    ) : (
                        <form onSubmit={handleSignup} className="w-full flex flex-col items-center">
                            <h1 className="text-3xl font-light text-white mb-6">Create Account</h1>
                            <div className="w-full space-y-3">
                                <input
                                    type="text"
                                    value={username}
                                    onChange={e => setUsername(e.target.value)}
                                    placeholder="Choose a Username"
                                    autoFocus
                                    className="w-full text-center px-4 py-3 bg-white/10 text-white placeholder-white/60 rounded-xl border-2 border-white/20 focus:ring-2 focus:ring-white/50 focus:border-white/20 focus:outline-none transition-all backdrop-blur-md"
                                />
                                <input
                                    type="password"
                                    value={password}
                                    onChange={e => setPassword(e.target.value)}
                                    placeholder="Choose a Password"
                                    className="w-full text-center px-4 py-3 bg-white/10 text-white placeholder-white/60 rounded-xl border-2 border-white/20 focus:ring-2 focus:ring-white/50 focus:border-white/20 focus:outline-none transition-all backdrop-blur-md"
                                />
                            </div>
                            <button type="submit" className="mt-6 w-full py-3 bg-white/20 hover:bg-white/30 text-white rounded-full transition-colors font-semibold text-lg">Create Account</button>
                            {hasRealUsers && <button type="button" onClick={() => switchMode('login')} className="text-sm text-white/80 hover:text-white mt-4">Already have an account? Log In</button>}
                        </form>
                    )}
                </div>
            </div>
             <style>{`
                @keyframes fade-in {
                    from { opacity: 0; transform: translateY(10px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                .animate-fade-in { animation: fade-in 0.7s ease-out forwards; }
            `}</style>
        </div>
    );
};