import React, { useState, useMemo, useCallback } from 'react';
import type { AppDefinition, WindowInstance } from '../types';
import { APPS } from '../config/apps';
import { useSettings } from '../context/SettingsContext';
import { ContextMenu } from './ContextMenu';

interface DockProps {
    windows: WindowInstance[];
    onToggleMinimize: (id: string) => void;
    onFocus: (id: string) => void;
    onLaunchpadClick: () => void;
    onCloseApp: (id: string) => void;
    activeWindowId: string | null;
    onOpenApp: (app: AppDefinition) => void;
    isFullScreenMode?: boolean;
    isVisible?: boolean;
}

const LaunchpadIconFC = () => (
    <div className="w-full h-full rounded-[22%] bg-gray-700 grid grid-cols-3 grid-rows-3 p-[10%] gap-[5%]">
        {[...Array(9)].map((_, i) => (
            <div key={i} className={`rounded-full ${['bg-red-500', 'bg-blue-500', 'bg-green-500', 'bg-yellow-500', 'bg-purple-500', 'bg-pink-500', 'bg-orange-500', 'bg-indigo-500', 'bg-teal-500'][i]}`}></div>
        ))}
    </div>
);

const DockIcon: React.FC<{
    app: AppDefinition;
    onClick: () => void;
    onContextMenu: (e: React.MouseEvent) => void;
    isRunning: boolean;
}> = ({ app, onClick, onContextMenu, isRunning }) => {
    const { dockSize, dockMagnification } = useSettings();
    const [isHovered, setIsHovered] = useState(false);

    const iconStyle = {
        width: `${dockSize}px`,
        height: `${dockSize}px`,
        transition: 'transform 0.15s cubic-bezier(0.4, 0, 0.2, 1)',
        transform: isHovered ? `scale(${dockMagnification}) translateY(-10px)` : 'scale(1) translateY(0)',
    };
    
    return (
        <div 
            className="flex flex-col items-center relative cursor-pointer" 
            onClick={onClick}
            onContextMenu={onContextMenu}
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
        >
            <div
                style={iconStyle}
                className="p-1 drop-shadow-lg"
                aria-label={app.name}
            >
                {app.icon}
            </div>
            {isRunning && <div className="absolute bottom-0 w-1.5 h-1.5 bg-white/80 rounded-full mb-0.5"></div>}
            <div 
                className={`absolute bottom-full mb-3 px-3 py-1.5 bg-black/70 text-white text-sm rounded-md shadow-lg backdrop-blur-sm pointer-events-none transition-opacity duration-150 ${isHovered ? 'opacity-100' : 'opacity-0'}`}
            >
                {app.name}
            </div>
        </div>
    );
};

export const Dock: React.FC<DockProps> = ({ windows, onToggleMinimize, onFocus, onLaunchpadClick, onCloseApp, activeWindowId, onOpenApp, isFullScreenMode = false, isVisible = true }) => {
    const { installedApps, pinnedApps, pinApp, unpinApp, theme, focusMode } = useSettings();
    const [contextMenu, setContextMenu] = useState<{ x: number, y: number, app: AppDefinition } | null>(null);

    const hideDock = focusMode?.settings.hideDock ?? false;

    const dockApps = useMemo(() => {
        const openAppIds = new Set(windows.map(win => win.appId));
        const pinnedAndOpenAppIds = new Set([...pinnedApps, ...openAppIds]);

        return APPS
            .filter(app => installedApps.includes(app.id) && pinnedAndOpenAppIds.has(app.id))
            .sort((a, b) => {
                const aIsPinned = pinnedApps.includes(a.id);
                const bIsPinned = pinnedApps.includes(b.id);
                if (aIsPinned && !bIsPinned) return -1;
                if (!aIsPinned && bIsPinned) return 1;
                // If both are pinned, or both are not, sort by default order
                 return APPS.findIndex(app => app.id === a.id) - APPS.findIndex(app => app.id === b.id);
            });
    }, [windows, installedApps, pinnedApps]);
    
    const handleIconClick = (app: AppDefinition) => {
        const window = windows.find(w => w.appId === app.id);
        if (window) {
            if (activeWindowId === window.id && !window.isMinimized) {
                onToggleMinimize(window.id);
            } else {
                if(window.isMinimized) {
                    onToggleMinimize(window.id);
                }
                onFocus(window.id);
            }
        } else {
            onOpenApp(app);
        }
    };
    
    const handleContextMenu = (e: React.MouseEvent, app: AppDefinition) => {
        e.preventDefault();
        setContextMenu({ x: e.clientX, y: e.clientY, app });
    };

    const closeContextMenu = useCallback(() => setContextMenu(null), []);

    const contextMenuItems = useMemo(() => {
        if (!contextMenu) return [];
        const { app } = contextMenu;
        const isPinned = pinnedApps.includes(app.id);
        const isRunning = windows.some(w => w.appId === app.id);
        const win = windows.find(w => w.appId === app.id);

        const items = [];
        if (!isRunning) {
            items.push({ label: 'Open', action: () => onOpenApp(app) });
        }
        items.push({
            label: isPinned ? 'Unpin from Dock' : 'Pin to Dock',
            action: () => isPinned ? unpinApp(app.id) : pinApp(app.id),
        });
        if (isRunning) {
             items.push({ label: 'Close', action: () => win && onCloseApp(win.id) });
        }
        
        return items.map(item => ({...item, action: () => { item.action(); closeContextMenu(); }}));
    }, [contextMenu, pinnedApps, windows, pinApp, unpinApp, onOpenApp, onCloseApp, closeContextMenu]);

    const dockContainerClasses = [
        'fixed bottom-2 left-0 right-0 h-24 flex justify-center items-end z-[1000] pointer-events-none transition-transform duration-300 ease-in-out',
        (isFullScreenMode ? (isVisible ? 'translate-y-0' : 'translate-y-[120%]') : ''),
        (hideDock ? 'translate-y-[120%]' : '')
    ].join(' ');
    
    const dockClasses = [
        "flex items-end space-x-2 bg-white/20 p-2 rounded-2xl shadow-2xl border border-white/30 pointer-events-auto",
        theme.glassmorphism ? 'backdrop-blur-xl' : ''
    ].join(' ');

    return (
        <footer className={dockContainerClasses}>
            <div className={dockClasses}>
                <DockIcon 
                    app={{ id: 'launchpad', name: 'Launchpad', icon: <LaunchpadIconFC />, component: () => null, category: 'System', description: '', sizeMB: 0 }}
                    onClick={onLaunchpadClick}
                    onContextMenu={(e) => e.preventDefault()}
                    isRunning={false}
                />

                {dockApps.map(app => {
                    const win = windows.find(w => w.appId === app.id);
                    return (
                        <DockIcon
                            key={app.id}
                            app={app}
                            onClick={() => handleIconClick(app)}
                            onContextMenu={(e) => handleContextMenu(e, app)}
                            isRunning={!!win}
                        />
                    );
                })}
            </div>
            {contextMenu && <ContextMenu x={contextMenu.x} y={contextMenu.y} items={contextMenuItems} onClose={closeContextMenu} />}
        </footer>
    );
};