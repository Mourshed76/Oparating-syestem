import React, { useEffect, useRef } from 'react';

interface ContextMenuItem {
    label: string;
    action: () => void;
    disabled?: boolean;
}

interface ContextMenuProps {
    x: number;
    y: number;
    items: ContextMenuItem[];
    onClose: () => void;
}

export const ContextMenu: React.FC<ContextMenuProps> = ({ x, y, items, onClose }) => {
    const menuRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
                onClose();
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, [onClose]);

    // Adjust position if menu would go off-screen
    const menuStyle: React.CSSProperties = {
        top: y,
        left: x,
    };
    if (menuRef.current) {
        const menuRect = menuRef.current.getBoundingClientRect();
        if (y + menuRect.height > window.innerHeight) {
            menuStyle.top = window.innerHeight - menuRect.height - 10;
        }
        if (x + menuRect.width > window.innerWidth) {
            menuStyle.left = window.innerWidth - menuRect.width - 10;
        }
    }


    return (
        <div 
            ref={menuRef}
            style={menuStyle}
            className="fixed z-[3000] bg-white/70 backdrop-blur-xl rounded-lg shadow-2xl border border-white/20 p-1.5 w-52 animate-fade-in-fast"
            onClick={(e) => e.stopPropagation()} // Prevent clicks inside from closing it
        >
            {items.map((item, index) => (
                <button 
                    key={index} 
                    onClick={item.action} 
                    disabled={item.disabled} 
                    className="w-full text-left px-3 py-1.5 text-sm text-black rounded-md hover:bg-mac-blue hover:text-white disabled:opacity-40 disabled:hover:bg-transparent disabled:hover:text-black transition-colors"
                >
                    {item.label}
                </button>
            ))}
             <style>{`
                @keyframes fade-in-fast {
                    from { opacity: 0; transform: scale(0.95); }
                    to { opacity: 1; transform: scale(1); }
                }
                .animate-fade-in-fast { animation: fade-in-fast 0.1s ease-out forwards; }
            `}</style>
        </div>
    );
};
