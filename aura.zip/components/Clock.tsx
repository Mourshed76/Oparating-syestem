import React, { useState, useEffect, useMemo, useRef } from 'react';

const CalendarGrid: React.FC<{ date: Date }> = ({ date }) => {
    const year = date.getFullYear();
    const month = date.getMonth();

    const daysInMonth = useMemo(() => {
        const firstDayOfMonth = new Date(year, month, 1);
        const lastDayOfMonth = new Date(year, month + 1, 0);
        const days = [];
        const startDayOfWeek = firstDayOfMonth.getDay();

        for (let i = 0; i < startDayOfWeek; i++) {
            days.push(null);
        }
        for (let day = 1; day <= lastDayOfMonth.getDate(); day++) {
            days.push(new Date(year, month, day));
        }
        return days;
    }, [year, month]);

    const weekdays = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
    const today = new Date();

    return (
        <div className="grid grid-cols-7 gap-y-1 text-center text-sm">
            {weekdays.map((day, i) => <div key={i} className="font-medium text-gray-500">{day}</div>)}
            {daysInMonth.map((day, index) => {
                const isToday = day && day.toDateString() === today.toDateString();
                return (
                    <div key={index} className="py-1">
                        {day && (
                            <span className={`flex items-center justify-center h-6 w-6 rounded-full ${isToday ? 'bg-mac-blue text-white' : 'text-mac-text'}`}>
                                {day.getDate()}
                            </span>
                        )}
                    </div>
                );
            })}
        </div>
    );
};

const DoNotDisturbToggle: React.FC = () => (
    <div className="flex items-center justify-between p-3 rounded-lg bg-black/5 hover:bg-black/10 transition-colors">
        <div className="flex items-center">
            <div className="w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center mr-3 text-white">🌙</div>
            <span className="font-medium text-mac-text">Do Not Disturb</span>
        </div>
        <label className="relative inline-flex items-center cursor-pointer">
          <input type="checkbox" value="" className="sr-only peer" />
          <div className="w-11 h-6 bg-gray-400 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-mac-blue"></div>
        </label>
    </div>
);

export const Clock: React.FC = () => {
    const [time, setTime] = useState(new Date());
    const [isDropdownOpen, setIsDropdownOpen] = useState(false);
    const dropdownRef = useRef<HTMLDivElement>(null);
    const buttonRef = useRef<HTMLButtonElement>(null);

    useEffect(() => {
        const timerId = setInterval(() => setTime(new Date()), 1000);
        return () => clearInterval(timerId);
    }, []);

    useEffect(() => {
        if (!isDropdownOpen) return;

        const handleClickOutside = (event: MouseEvent) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node) && !buttonRef.current?.contains(event.target as Node)) {
                setIsDropdownOpen(false);
            }
        };

        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, [isDropdownOpen]);

    const formattedDate = useMemo(() => {
        return time.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' });
    }, [time]);
    
    const formattedTime = useMemo(() => {
        return time.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
    }, [time]);

    return (
        <div className="relative">
            <button 
                ref={buttonRef}
                onClick={() => setIsDropdownOpen(prev => !prev)}
                className="text-sm font-medium tracking-wide px-3 py-1 rounded-md hover:bg-black/10"
                aria-haspopup="true"
                aria-expanded={isDropdownOpen}
            >
                <span>{formattedDate} </span>
                <span>{formattedTime}</span>
            </button>

            {isDropdownOpen && (
                <div 
                    ref={dropdownRef}
                    className="absolute top-full right-0 mt-2 w-72 bg-mac-gray-header/80 backdrop-blur-2xl rounded-2xl shadow-lg border border-black/10 p-3 text-mac-text animate-fade-in-fast"
                    role="menu"
                >
                    <div className="mb-3">
                        <CalendarGrid date={time} />
                    </div>
                    <DoNotDisturbToggle />
                </div>
            )}
             <style>{`
                @keyframes fade-in-fast {
                    from { opacity: 0; transform: translateY(-5px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                .animate-fade-in-fast { animation: fade-in-fast 0.15s ease-out forwards; }
            `}</style>
        </div>
    );
};