import React, { useState, useMemo, useCallback } from 'react';
import type { AppDefinition } from '../types';
import { APPS } from '../config/apps';
import { useSettings } from '../context/SettingsContext';
import { ContextMenu } from './ContextMenu';

interface LaunchpadProps {
    isOpen: boolean;
    onOpenApp: (app: AppDefinition) => void;
    onClose: () => void;
}

const AppIcon: React.FC<{ app: AppDefinition; onClick: () => void; onContextMenu: (e: React.MouseEvent) => void; }> = ({ app, onClick, onContextMenu }) => (
    <div
        onClick={onClick}
        onContextMenu={onContextMenu}
        className="flex flex-col items-center justify-start space-y-2 text-center p-2 rounded-lg transition-transform duration-200 cursor-pointer w-28 transform hover:scale-110"
        aria-label={`Open ${app.name}`}
    >
        <div className="w-16 h-16 drop-shadow-lg">{app.icon}</div>
        <span className="text-white text-sm font-medium select-none truncate w-full">{app.name}</span>
    </div>
);

export const Launchpad: React.FC<LaunchpadProps> = ({ isOpen, onOpenApp, onClose }) => {
    const { installedApps, pinnedApps, pinApp, desktopShortcuts, addDesktopShortcut } = useSettings();
    const [searchTerm, setSearchTerm] = useState('');
    const [contextMenu, setContextMenu] = useState<{ x: number, y: number, app: AppDefinition } | null>(null);

    const availableApps = useMemo(() => {
        return APPS.filter(app => installedApps.includes(app.id));
    }, [installedApps]);

    const filteredApps = useMemo(() => {
        if (!searchTerm) return availableApps;
        return availableApps.filter(app => app.name.toLowerCase().includes(searchTerm.toLowerCase()));
    }, [searchTerm, availableApps]);

    const handleContextMenu = (e: React.MouseEvent, app: AppDefinition) => {
        e.preventDefault();
        setContextMenu({ x: e.clientX, y: e.clientY, app });
    };

    const closeContextMenu = useCallback(() => setContextMenu(null), []);

    const contextMenuItems = useMemo(() => {
        if (!contextMenu) return [];
        const { app } = contextMenu;
        const isPinned = pinnedApps.includes(app.id);
        const isDesktop = desktopShortcuts.includes(app.id);
        
        const items = [
            { label: 'Open', action: () => onOpenApp(app) },
            { label: isPinned ? 'Unpin from Dock' : 'Pin to Dock', action: () => pinApp(app.id) },
            { label: 'Add to Desktop', action: () => addDesktopShortcut(app.id), disabled: isDesktop },
        ];
        
        return items.map(item => ({...item, action: () => { if(!item.disabled) item.action(); closeContextMenu(); }}));
    }, [contextMenu, onOpenApp, pinApp, pinnedApps, addDesktopShortcut, desktopShortcuts, closeContextMenu]);


    if (!isOpen) return null;

    return (
        <>
            <div 
                className="fixed inset-0 z-[1500] bg-black/30 backdrop-blur-xl animate-fade-in"
                onClick={onClose}
                aria-hidden="true"
            ></div>
            <div 
                className="fixed inset-0 z-[1600] flex flex-col items-center p-12 animate-fade-in"
                role="dialog"
                aria-modal="true"
                onClick={closeContextMenu}
            >
                <div className="w-full max-w-sm mb-8">
                    <input 
                        type="text"
                        placeholder="Search"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-full px-4 py-2 bg-white/20 text-white placeholder-white/60 rounded-lg border-none focus:ring-2 focus:ring-white/50 focus:outline-none"
                    />
                </div>
                <div className="flex-grow w-full max-w-6xl overflow-y-auto">
                     <div className="flex flex-wrap justify-center gap-x-8 gap-y-6">
                        {filteredApps.map(app => (
                            <AppIcon 
                                key={app.id} 
                                app={app} 
                                onClick={() => onOpenApp(app)} 
                                onContextMenu={(e) => handleContextMenu(e, app)}
                            />
                        ))}
                    </div>
                </div>
                {contextMenu && <ContextMenu {...contextMenu} items={contextMenuItems} onClose={closeContextMenu} />}
            </div>
            <style>{`
                @keyframes fade-in {
                    from { opacity: 0; }
                    to { opacity: 1; }
                }
                .animate-fade-in { animation: fade-in 0.3s ease-out forwards; }
            `}</style>
        </>
    );
};
