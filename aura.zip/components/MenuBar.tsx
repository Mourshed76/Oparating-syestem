import React from 'react';
import { Clock } from './Clock';
import { useSettings } from '../context/SettingsContext';

interface MenuBarProps {
    activeAppName: string;
    isFullScreenMode?: boolean;
    isVisible?: boolean;
}

const AppleIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
      <path d="M12.015 6.444c-.754.01-1.503.433-2.222.805-1.233.642-2.342 1.94-2.859 3.282-.555 1.423-.835 2.946-.835 4.508 0 1.29.324 2.52.88 3.568.529.994 1.258 1.83 2.164 2.458.895.62 1.898.945 2.94.945.39 0 .78-.05 1.16-.14.99-.25 1.94-.8 2.76-1.56.42-.38.78-.81 1.05-1.29.07-.13.1-.28.16-.42a.71.71 0 00-.63-1.03.73.73 0 00-.89.39c-.18.33-.42.64-.71.91-.65.59-1.42.99-2.26.99-.58 0-1.13-.19-1.6-.51-.49-.33-.9-.78-1.2-1.32-.5-1-1.02-2.3-1.02-3.83 0-1.74.32-3.32.96-4.66.6-1.26 1.54-2.25 2.7-2.77.2-.09.39-.16.59-.22.5-.15 1.01-.22 1.52-.22.28 0 .56.02.83.07.2.04.4.08.59.14l.2.06c.64.24 1.18.66 1.63 1.21.05.06.13.04.16-.04a.72.72 0 00-.47-1.12c-.59-.42-1.29-.68-2.03-.78a4.6 4.6 0 00-1.47-.223zM15.485 2.05a.71.71 0 00-.71.71c0 .2.08.38.21.51.98.98 1.51 2.4 1.51 3.86 0 .26-.02.52-.05.78a.71.71 0 00.86.8c.4-.04.68-.44.64-.84-.04-.3-.1-.6-.15-.9C17.745 4.715 16.895 3.125 15.485 2.05z"/>
    </svg>
);

const ControlCenterIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
      <path fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clipRule="evenodd" />
    </svg>
);


export const MenuBar: React.FC<MenuBarProps> = ({ activeAppName, isFullScreenMode = false, isVisible = true }) => {
    const { coins } = useSettings();

    return (
        <header className={`fixed top-0 left-0 right-0 h-7 bg-white/20 backdrop-blur-xl z-[2000] flex items-center justify-between px-4 text-mac-text shadow-sm transition-transform duration-300 ease-in-out ${isFullScreenMode ? (isVisible ? 'translate-y-0' : '-translate-y-full') : ''}`}>
            <div className="flex items-center space-x-4">
                <AppleIcon />
                <span className="font-bold text-sm">{activeAppName}</span>
            </div>
            <div className="flex items-center space-x-4">
                <div className="flex items-center gap-1 text-sm font-medium">
                    <span>🪙</span>
                    <span>{coins}</span>
                </div>
                <ControlCenterIcon />
                <Clock />
            </div>
        </header>
    );
};