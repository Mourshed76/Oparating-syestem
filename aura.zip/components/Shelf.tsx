import React, { useState } from 'react';
import type { ShelfItem } from '../types';

interface ShelfProps {
    items: ShelfItem[];
    onRemoveItem: (id: string) => void;
}

const ShelfItemCard: React.FC<{ item: ShelfItem; onRemove: () => void }> = ({ item, onRemove }) => {
    return (
        <div className="bg-white/10 p-2 rounded-lg relative group">
            <button onClick={onRemove} className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-red-500 text-white text-xs opacity-0 group-hover:opacity-100 transition-opacity">×</button>
            {item.type === 'text' && <p className="text-sm text-gray-200 break-words">{item.data}</p>}
            {item.type === 'image' && <img src={item.data} alt="shelf item" className="rounded max-w-full h-auto" />}
            {item.type === 'file' && <p className="text-sm text-gray-200">📄 {item.name}</p>}
        </div>
    );
};

export const Shelf: React.FC<ShelfProps> = ({ items, onRemoveItem }) => {
    const [isOpen, setIsOpen] = useState(false);

    // Basic drag-and-drop support would be added here.
    // For this implementation, items are added programmatically.

    return (
        <div
            className={`fixed top-0 right-0 h-full z-[1200] transition-transform duration-300 ease-in-out ${isOpen ? 'translate-x-0' : 'translate-x-[calc(100%-20px)]'}`}
            onMouseEnter={() => setIsOpen(true)}
            onMouseLeave={() => setIsOpen(false)}
        >
            <div className="w-72 h-full bg-black/40 backdrop-blur-2xl border-l-2 border-white/20 p-4 pt-10 flex flex-col">
                <h2 className="text-lg font-bold text-white mb-4">The Shelf</h2>
                <div className="flex-grow overflow-y-auto space-y-3 pr-2">
                    {items.map(item => (
                        <ShelfItemCard key={item.id} item={item} onRemove={() => onRemoveItem(item.id)} />
                    ))}
                    {items.length === 0 && (
                        <div className="text-center text-gray-400 text-sm pt-10">
                            Drag items here to use across apps.
                        </div>
                    )}
                </div>
            </div>
             <div className="absolute top-1/2 left-0 -translate-x-1/2 -translate-y-1/2 w-2 h-24 bg-white/50 rounded-l-full" />
        </div>
    );
};