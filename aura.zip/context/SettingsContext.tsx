import React, { createContext, useState, useContext, ReactNode, useMemo, useEffect, useCallback } from 'react';
import { WALLPAPERS } from '../config/system';
import { APPS } from '../config/apps';
import type { VFS, VFSItem, VFSFolder, VFSFile, NotesState, PhotosState, BrowserState, Bookmark, HistoryItem, Note, Photo, PhotoAlbum, NoteFolder, User, ConnectSphereState, ConnectSpherePost, Conversation, DirectMessage, ConnectSphereComment, NetworkSpeed, KingdomsAscendancyState, ThemeSettings, FocusMode, PlacedBuilding, GameUnit } from '../types';
import { v4 as uuidv4 } from 'uuid';
import { faker } from '@faker-js/faker';
import { aiService } from '../utils/aiService';

// --- INITIAL STATE GENERATORS ---

const createInitialUsers = (): User[] => {
    const users: User[] = [];
    for (let i = 0; i < 50; i++) {
        const username = faker.internet.userName().replace(/[^a-zA-Z0-9]/g, '_').substring(0, 15);
        users.push({
            id: `ai-user-${i}`,
            username: username,
            isAI: true,
            bio: faker.person.bio(),
            friends: [],
            friendRequests: [],
            coverPhotoSeed: uuidv4(),
        });
    }
    return users;
};

const createInitialVFS = (): VFS => {
    const rootId = uuidv4();
    const homeId = uuidv4();
    const desktopId = uuidv4();
    const documentsId = uuidv4();
    const downloadsId = uuidv4();
    const trashId = uuidv4();

    const vfs: VFS = {
        items: {
            [rootId]: { id: rootId, type: 'folder', name: 'Aura', parentId: null, path: '/', children: [homeId, trashId] },
            [homeId]: { id: homeId, type: 'folder', name: 'Home', parentId: rootId, path: '/Home', children: [desktopId, documentsId, downloadsId] },
            [desktopId]: { id: desktopId, type: 'folder', name: 'Desktop', parentId: homeId, path: '/Home/Desktop', children: [] },
            [documentsId]: { id: documentsId, type: 'folder', name: 'Documents', parentId: homeId, path: '/Home/Documents', children: [] },
            [downloadsId]: { id: downloadsId, type: 'folder', name: 'Downloads', parentId: homeId, path: '/Home/Downloads', children: [] },
            [trashId]: { id: trashId, type: 'folder', name: 'Trash', parentId: rootId, path: '/Trash', children: [] },
        },
        rootId, homeId, desktopId, documentsId, downloadsId, trashId
    };
    return vfs;
};

const createInitialNotesState = (): NotesState => ({
    folders: [{ id: 'default', name: 'All Notes' }],
    notes: [{
        id: uuidv4(),
        folderId: 'default',
        title: 'Welcome to Notes!',
        content: '<p>This is your new and improved Notes app. You can now use <b>bold</b>, <i>italic</i>, and <u>underline</u>. Organize your thoughts into different folders!</p>',
        updatedAt: Date.now(),
        type: 'text'
    }]
});

const createInitialPhotosState = (): PhotosState => {
    const defaultPhotos = Array.from({ length: 15 }, () => ({
        id: Math.random().toString(36).substring(7),
        albumIds: ['all'],
        addedAt: Date.now() - Math.random() * 1000 * 3600 * 24 * 5
    }));
    return {
        photos: defaultPhotos,
        albums: [
            { id: 'all', name: 'All Photos' },
            { id: 'private', name: 'Private' },
            { id: 'favorites', name: 'Favorites' }
        ],
        privateAlbumPassword: ''
    };
};

const createInitialBrowserState = (): BrowserState => ({
    bookmarks: [],
    history: [],
    tabGroups: []
});

const createInitialConnectSphereState = (): ConnectSphereState => ({
    posts: [],
    conversations: [],
});

const createInitialKingdomsState = (): KingdomsAscendancyState => ({
    resources: { wood: 200, gold: 100, food: 150, stone: 50, population: 3, maxPopulation: 10 },
    enemyResources: { wood: 200, gold: 100, food: 150, stone: 50, population: 0, maxPopulation: 10 },
    buildings: [{
      id: 'start_th',
      type: 'town_hall',
      x: 10,
      y: 10,
      level: 1,
      owner: 'player',
      health: 1500,
      maxHealth: 1500,
      isConstructing: false,
      constructionProgress: 100,
      trainingQueue: []
    }],
    units: [
        { id: uuidv4(), type: 'villager', x: 120, y: 120, health: 50, maxHealth: 50, task: { type: 'idle' }, owner: 'player', resourceAmount: 0, attackCooldown: 0 },
        { id: uuidv4(), type: 'villager', x: 120, y: 130, health: 50, maxHealth: 50, task: { type: 'idle' }, owner: 'player', resourceAmount: 0, attackCooldown: 0 },
        { id: uuidv4(), type: 'villager', x: 130, y: 120, health: 50, maxHealth: 50, task: { type: 'idle' }, owner: 'player', resourceAmount: 0, attackCooldown: 0 },
    ],
    resourceNodes: [],
    researchedTechs: [],
    currentAge: 'Stone Age',
    lastUpdated: Date.now(),
    gameSpeed: 1,
    aiState: { attackWaveCooldown: 60, state: 'expanding', scoutTarget: null },
    notifications: []
});

const createInitialThemeSettings = (): ThemeSettings => ({
    accentColor: '#007aff',
    mode: 'light',
    glassmorphism: true,
});

// --- LOCALSTORAGE HOOK ---
function usePersistentState<T>(key: string, initialStateCreator: () => T): [T, React.Dispatch<React.SetStateAction<T>>] {
    const [state, setState] = useState<T>(() => {
        try {
            const storedValue = localStorage.getItem(key);
            if(key === 'aura-users' && !storedValue) {
                return initialStateCreator();
            }
            return storedValue ? JSON.parse(storedValue) : initialStateCreator();
        } catch (error) {
            console.error(`Error reading localStorage key "${key}":`, error);
            return initialStateCreator();
        }
    });

    useEffect(() => {
        try {
            localStorage.setItem(key, JSON.stringify(state));
        } catch (error) {
            console.error(`Error writing to localStorage key "${key}":`, error);
        }
    }, [key, state]);

    return [state, setState];
}


// --- CONTEXT ---
interface SettingsContextType {
    // General
    wallpaper: string;
    setWallpaper: (url: string) => void;
    dockSize: number;
    setDockSize: (size: number) => void;
    dockMagnification: number;
    setDockMagnification: (mag: number) => void;
    networkSpeed: NetworkSpeed;
    setNetworkSpeed: (speed: NetworkSpeed) => void;
    
    // Auth
    users: User[];
    currentUser: User | null;
    signup: (username: string, password?: string) => { success: boolean, message?: string };
    login: (username: string, password?: string) => { success: boolean, message?: string };
    logout: () => void;
    sendFriendRequest: (toId: string) => void;
    acceptFriendRequest: (fromId: string) => void;
    declineFriendRequest: (fromId: string) => void;

    // Apps & Coins
    installedApps: string[];
    installingProgress: { [key: string]: number };
    installApp: (appId: string) => void;
    pinnedApps: string[];
    pinApp: (appId: string) => void;
    unpinApp: (appId: string) => void;
    desktopShortcuts: string[];
    addDesktopShortcut: (appId: string) => void;
    removeDesktopShortcut: (appId: string) => void;
    coins: number;
    addCoins: (amount: number) => void;
    
    // Theming & Personalization
    theme: ThemeSettings;
    setTheme: React.Dispatch<React.SetStateAction<ThemeSettings>>;
    focusMode: FocusMode | null;
    setFocusMode: (mode: FocusMode | null) => void;


    // VFS / Finder
    vfs: VFS;
    createVFSItem: (type: 'folder' | 'file', parentId: string, name: string, content?: string) => VFSItem | null;
    renameVFSItem: (id: string, newName: string) => void;
    moveVFSItemToTrash: (id: string) => void;
    emptyTrash: () => void;
    updateVFSFileContent: (id: string, newContent: string) => void;

    // Notes
    notesState: NotesState;
    createNote: (folderId: string) => Note;
    updateNote: (id: string, updates: Partial<Note>) => void;
    deleteNote: (id: string) => void;
    createNoteFolder: (name: string) => NoteFolder;

    // Photos
    photosState: PhotosState;
    importPhotos: (count: number) => void;
    createPhotoAlbum: (name: string) => PhotoAlbum;
    addPhotoToAlbum: (photoId: string, albumId: string) => void;
    removePhotoFromAlbum: (photoId: string, albumId: string) => void;
    setPrivateAlbumPassword: (password: string) => void;

    // Browser
    browserState: BrowserState;
    addBookmark: (url: string, title: string) => void;
    removeBookmark: (id: string) => void;
    addHistoryItem: (url: string, title: string) => void;

    // Aura
    auraChatClearCount: number;
    clearAuraChat: () => void;

    // ConnectSphere
    connectSphereState: ConnectSphereState;
    createConnectSpherePost: (content: string, imageUrl?: string) => void;
    toggleLikeConnectSpherePost: (postId: string) => void;
    addConnectSphereComment: (postId: string, content: string) => void;
    sendDirectMessage: (toId: string, content: string) => void;
    
    // Kingdoms
    kingdomsState: KingdomsAscendancyState;
    setKingdomsState: React.Dispatch<React.SetStateAction<KingdomsAscendancyState>>;
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

export const SettingsProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    // --- General State ---
    const [wallpaper, setWallpaper] = usePersistentState<string>('aura-wallpaper', () => WALLPAPERS[0].url);
    const [dockSize, setDockSize] = usePersistentState<number>('aura-dockSize', () => 56);
    const [dockMagnification, setDockMagnification] = usePersistentState<number>('aura-dockMagnification', () => 1.5);
    const [networkSpeed, setNetworkSpeed] = usePersistentState<NetworkSpeed>('aura-networkSpeed', () => 'fast');
    const [installedApps, setInstalledApps] = usePersistentState<string[]>('aura-installedApps', () => ['finder', 'aura_chat', 'browser', 'app_store', 'settings', 'notes', 'photos', 'calculator', 'terminal', 'connect_sphere']);
    const [installingProgress, setInstallingProgress] = useState<{ [key: string]: number }>({});
    const [pinnedApps, setPinnedApps] = usePersistentState<string[]>('aura-pinnedApps', () => ['finder', 'browser', 'app_store', 'settings']);
    const [desktopShortcuts, setDesktopShortcuts] = usePersistentState<string[]>('aura-desktopShortcuts', () => ['browser', 'notes', 'photos']);
    
    // --- Auth State ---
    const [users, setUsers] = usePersistentState<User[]>('aura-users', createInitialUsers);
    const [currentUser, setCurrentUser] = usePersistentState<User | null>('aura-currentUser', () => null);
    
    // --- Theming & Personalization State ---
    const [theme, setTheme] = usePersistentState<ThemeSettings>('aura-theme', createInitialThemeSettings);
    const [focusMode, setFocusMode] = usePersistentState<FocusMode | null>('aura-focusMode', () => null);

    // --- Coins ---
    const [coins, setCoins] = usePersistentState<number>('aura-coins', () => 0);

    // --- App-specific States ---
    const [vfs, setVfs] = usePersistentState<VFS>('aura-vfs', createInitialVFS);
    const [notesState, setNotesState] = usePersistentState<NotesState>('aura-notesState', createInitialNotesState);
    const [photosState, setPhotosState] = usePersistentState<PhotosState>('aura-photosState', createInitialPhotosState);
    const [browserState, setBrowserState] = usePersistentState<BrowserState>('aura-browserState', createInitialBrowserState);
    const [connectSphereState, setConnectSphereState] = usePersistentState<ConnectSphereState>('aura-connectSphere', createInitialConnectSphereState);
    const [auraChatClearCount, setAuraChatClearCount] = useState(0);
    const [kingdomsState, setKingdomsState] = usePersistentState<KingdomsAscendancyState>('aura-kingdomsState', createInitialKingdomsState);


    // --- Auth Functions ---
    const signup = (username: string, password = ''): { success: boolean, message?: string } => {
        if (users.some(u => u.username.toLowerCase() === username.toLowerCase() && !u.isAI)) {
            return { success: false, message: 'Username already exists.' };
        }
        const newUser: User = { 
            id: uuidv4(), 
            username, 
            password,
            isAI: false,
            bio: 'A new Aura user exploring the digital world.',
            friends: [],
            friendRequests: [],
            coverPhotoSeed: uuidv4()
        };
        setUsers(prev => [...prev, newUser]);
        setCurrentUser(newUser);
        return { success: true };
    };

    const login = (username: string, password = ''): { success: boolean, message?: string } => {
        const user = users.find(u => u.username.toLowerCase() === username.toLowerCase() && !u.isAI);
        if (user && user.password === password) {
            setCurrentUser(user);
            return { success: true };
        }
        return { success: false, message: 'Invalid username or password.' };
    };

    const logout = () => {
        setCurrentUser(null);
    };

    // --- App Management Functions ---
    const installApp = (appId: string) => {
        if (installedApps.includes(appId) || installingProgress[appId] !== undefined) return;
        const app = APPS.find(a => a.id === appId);
        if (!app) return;

        const speedFactors: Record<NetworkSpeed, number> = {
            fast: 5,   // MB/s
            medium: 1, // MB/s
            slow: 0.2, // MB/s
            offline: 0,
        };

        const speed = speedFactors[networkSpeed];
        if (speed === 0) {
            alert("Cannot install apps. You are offline.");
            return;
        }

        const installTimeMs = ((app.sizeMB || 10) / speed) * 1000;
        const updateInterval = 50;
        const steps = Math.max(1, installTimeMs / updateInterval);
        const progressPerStep = 100 / steps;
        
        setInstallingProgress(prev => ({ ...prev, [appId]: 0 }));

        const intervalId = setInterval(() => {
            setInstallingProgress(prev => {
                const currentProgress = prev[appId] ?? 0;
                const newProgress = currentProgress + progressPerStep;
                
                if (newProgress >= 100) {
                    clearInterval(intervalId);
                    setInstalledApps(prevApps => [...prevApps, appId]);
                    const finalProgress = { ...prev };
                    delete finalProgress[appId];
                    return finalProgress;
                }
                return { ...prev, [appId]: newProgress };
            });
        }, updateInterval);
    };
    
    const pinApp = (appId: string) => setPinnedApps(prev => [...new Set([...prev, appId])]);
    const unpinApp = (appId: string) => setPinnedApps(prev => prev.filter(id => id !== appId));
    const addDesktopShortcut = (appId: string) => setDesktopShortcuts(prev => [...new Set([...prev, appId])]);
    const removeDesktopShortcut = (appId: string) => setDesktopShortcuts(prev => prev.filter(id => id !== appId));
    const addCoins = useCallback((amount: number) => setCoins(prev => prev + amount), [setCoins]);


    // --- VFS Functions ---
    const createVFSItem = (type: 'folder' | 'file', parentId: string, name: string, content = ''): VFSItem | null => {
        const parent = vfs.items[parentId];
        if (!parent || parent.type !== 'folder') return null;

        let newName = name;
        let counter = 1;
        while (parent.children.some(childId => vfs.items[childId]?.name === newName)) {
            newName = `${name} (${counter++})`;
        }
        
        const newItem: VFSItem = type === 'folder'
            ? { id: uuidv4(), type: 'folder', name: newName, parentId, path: `${parent.path}/${newName}`, children: [] }
            : { id: uuidv4(), type: 'file', name: newName, parentId, path: `${parent.path}/${newName}`, content, size: content.length, createdAt: Date.now(), modifiedAt: Date.now() };

        setVfs(prev => {
            const newItems = { ...prev.items, [newItem.id]: newItem };
            const newParent = { ...newItems[parentId] as VFSFolder, children: [...(newItems[parentId] as VFSFolder).children, newItem.id] };
            newItems[parentId] = newParent;
            return { ...prev, items: newItems };
        });
        return newItem;
    };
    
    const renameVFSItem = (id: string, newName: string) => {
        setVfs(prev => {
            const item = prev.items[id];
            if (!item || !item.parentId) return prev;
            const parent = prev.items[item.parentId] as VFSFolder;
            if (parent.children.some(childId => prev.items[childId]?.name === newName && childId !== id)) {
                console.error("Name already exists in directory.");
                return prev;
            }
            const updatedItem = { ...item, name: newName, path: `${parent.path}/${newName}` };
            return { ...prev, items: { ...prev.items, [id]: updatedItem } };
        });
    };

    const moveVFSItemToTrash = (id: string) => {
        setVfs(prev => {
            const item = prev.items[id];
            if (!item || !item.parentId || item.parentId === prev.trashId) return prev;
            
            const newVfs = { ...prev, items: { ...prev.items } };
            // Remove from old parent
            const oldParent = newVfs.items[item.parentId] as VFSFolder;
            newVfs.items[item.parentId] = { ...oldParent, children: oldParent.children.filter(childId => childId !== id) };
            
            // Add to trash
            const trash = newVfs.items[prev.trashId] as VFSFolder;
            newVfs.items[prev.trashId] = { ...trash, children: [...trash.children, id] };
            
            // Update item's parentId
            newVfs.items[id] = { ...item, parentId: prev.trashId };
            return newVfs;
        });
    };
    
    const emptyTrash = () => {
        setVfs(prev => {
            const trashFolder = prev.items[prev.trashId] as VFSFolder;
            const newItems = { ...prev.items };
            trashFolder.children.forEach(childId => delete newItems[childId]);
            newItems[prev.trashId] = { ...trashFolder, children: [] };
            return { ...prev, items: newItems };
        });
    };

    const updateVFSFileContent = useCallback((id: string, newContent: string) => {
        setVfs(prev => {
            const item = prev.items[id];
            if (!item || item.type !== 'file') {
                console.error(`Cannot update content of non-file or non-existent item: ${id}`);
                return prev;
            }
            const updatedItem: VFSFile = {
                ...item,
                content: newContent,
                size: newContent.length,
                modifiedAt: Date.now()
            };
            return { ...prev, items: { ...prev.items, [id]: updatedItem } };
        });
    }, []);

    // --- Notes Functions ---
    const createNote = (folderId: string): Note => {
        const newNote: Note = { id: uuidv4(), folderId, title: 'New Note', content: '', updatedAt: Date.now(), type: 'text' };
        setNotesState(prev => ({ ...prev, notes: [newNote, ...prev.notes] }));
        return newNote;
    };
    const updateNote = (id: string, updates: Partial<Note>) => {
        setNotesState(prev => ({
            ...prev,
            notes: prev.notes
                .map(n => n.id === id ? { ...n, ...updates, updatedAt: Date.now() } : n)
                .sort((a,b) => b.updatedAt - a.updatedAt)
        }));
    };
    const deleteNote = (id: string) => {
        setNotesState(prev => ({ ...prev, notes: prev.notes.filter(n => n.id !== id) }));
    };
    const createNoteFolder = (name: string): NoteFolder => {
        const newFolder: NoteFolder = { id: uuidv4(), name };
        setNotesState(prev => ({ ...prev, folders: [...prev.folders, newFolder] }));
        return newFolder;
    };

    // --- Photos Functions ---
    const importPhotos = (count: number) => {
        const newPhotos: Photo[] = Array.from({ length: count }, () => ({
            id: Math.random().toString(36).substring(7),
            albumIds: ['all'],
            addedAt: Date.now()
        }));
        setPhotosState(prev => ({ ...prev, photos: [...newPhotos, ...prev.photos] }));
    };
    const createPhotoAlbum = (name: string): PhotoAlbum => {
        const newAlbum: PhotoAlbum = { id: uuidv4(), name };
        setPhotosState(prev => ({ ...prev, albums: [...prev.albums, newAlbum] }));
        return newAlbum;
    };
    const addPhotoToAlbum = (photoId: string, albumId: string) => {
        setPhotosState(prev => ({
            ...prev,
            photos: prev.photos.map(p => p.id === photoId ? { ...p, albumIds: [...new Set([...p.albumIds, albumId])] } : p)
        }));
    };
    const removePhotoFromAlbum = (photoId: string, albumId: string) => {
        setPhotosState(prev => ({
            ...prev,
            photos: prev.photos.map(p => p.id === photoId ? { ...p, albumIds: p.albumIds.filter(id => id !== albumId) } : p)
        }));
    };
    const setPrivateAlbumPassword = (password: string) => {
        setPhotosState(prev => ({ ...prev, privateAlbumPassword: password }));
    };

    // --- Browser Functions ---
    const addBookmark = (url: string, title: string) => {
        const newBookmark: Bookmark = { id: uuidv4(), url, title, favicon: `https://www.google.com/s2/favicons?domain=${new URL(url).hostname}&sz=32` };
        setBrowserState(prev => ({...prev, bookmarks: [newBookmark, ...prev.bookmarks]}));
    };
    const removeBookmark = (id: string) => {
        setBrowserState(prev => ({...prev, bookmarks: prev.bookmarks.filter(b => b.id !== id)}));
    };
    const addHistoryItem = (url: string, title: string) => {
        const newHistoryItem: HistoryItem = { id: uuidv4(), url, title, timestamp: Date.now() };
        setBrowserState(prev => ({ ...prev, history: [newHistoryItem, ...prev.history.slice(0, 99)]}));
    };

    // --- Aura Functions ---
    const clearAuraChat = () => {
        setAuraChatClearCount(prev => prev + 1);
    };

    // --- ConnectSphere Simulation & Functions ---

    const _createAiPost = async () => {
        const aiUser = users[Math.floor(Math.random() * users.length)];
        if (!aiUser || aiUser.id === currentUser?.id || !aiUser.isAI) return;

        const prompt = `You are a social media user named ${aiUser.username}. Write a short, interesting, or funny post. It could be about technology, nature, a personal thought, or a random musing. Keep it under 280 characters.`;

        try {
            const response = await aiService.generateContent(prompt);
            const postContent = response.text.trim().replace(/"/g, ''); // Clean up quotes
             if (postContent) {
                 const newPost: ConnectSpherePost = {
                    id: uuidv4(),
                    authorId: aiUser.id, authorName: aiUser.username,
                    content: postContent,
                    timestamp: Date.now(),
                    likes: 0, likedBy: [], comments: [],
                    imageUrl: Math.random() < 0.2 ? `https://picsum.photos/seed/${uuidv4()}/600/400` : undefined
                };
                setConnectSphereState(prev => ({ ...prev, posts: [newPost, ...prev.posts] }));
            }
        } catch (error) { console.error("AI post generation failed:", error); }
    };

    const _createAiLike = () => {
        setConnectSphereState(prev => {
            if (prev.posts.length === 0) return prev;
            const postToLike = prev.posts[Math.floor(Math.random() * prev.posts.length)];
            const aiUser = users[Math.floor(Math.random() * users.length)];
            if (!aiUser || postToLike.likedBy.includes(aiUser.id) || !aiUser.isAI) return prev;

            const newPosts = prev.posts.map(p => p.id === postToLike.id ? { ...p, likes: p.likes + 1, likedBy: [...p.likedBy, aiUser.id] } : p);
            return { ...prev, posts: newPosts };
        });
    };
    
    const _createAiComment = async () => {
        const state = await new Promise<ConnectSphereState>(resolve => setConnectSphereState(s => { resolve(s); return s; }));
        if (state.posts.length === 0) return;
        
        const postToComment = state.posts[Math.floor(Math.random() * state.posts.length)];
        const aiUser = users[Math.floor(Math.random() * users.length)];
        if (!aiUser || aiUser.id === postToComment.authorId || !aiUser.isAI) return;

        const prompt = `You are a social media user named ${aiUser.username}. You are commenting on a post by ${postToComment.authorName} that says: "${postToComment.content}". Write a short, relevant, and friendly comment.`;

        try {
            const response = await aiService.generateContent(prompt);
            const commentContent = response.text.trim().replace(/"/g, '');
            if(commentContent) {
                 addConnectSphereComment(postToComment.id, commentContent, aiUser);
            }
        } catch (error) { console.error("AI comment generation failed:", error); }
    };

    const _createAiFriendRequest = () => {
        if (!currentUser) return;
        setUsers(prevUsers => {
            const aiUser = prevUsers[Math.floor(Math.random() * prevUsers.length)];
            const me = prevUsers.find(u => u.id === currentUser.id);
            if (!aiUser || !me || !aiUser.isAI || me.friends.includes(aiUser.id) || me.friendRequests.some(r => r.from === aiUser.id)) {
                return prevUsers;
            }
            return prevUsers.map(u => u.id === currentUser.id ? { ...u, friendRequests: [...u.friendRequests, { from: aiUser.id, to: currentUser.id }] } : u);
        });
    }

    const _respondToDirectMessage = async (conversationId: string, messageHistory: string) => {
        const [userId1, userId2] = conversationId.split('--');
        const aiUserId = currentUser?.id === userId1 ? userId2 : userId1;
        const aiUser = users.find(u => u.id === aiUserId);
        if(!aiUser) return;

        const prompt = `You are the social media user ${aiUser.username}. You are in a private chat. Here is the recent chat history:\n\n${messageHistory}\n\nContinue the conversation with a short, natural, friendly reply.`;

        try {
            const response = await aiService.generateContent(prompt);
            const messageContent = response.text.trim().replace(/"/g, '');
            if(messageContent) {
                setTimeout(() => sendDirectMessage(currentUser!.id, messageContent, aiUser), 1500);
            }
        } catch (error) { console.error("AI DM response generation failed:", error); }
    }

    const _aiAcceptsHumanFriendRequests = useCallback(() => {
        if (!currentUser) return;
        setUsers(prevUsers => {
            const humanId = currentUser.id;
            const requestsToAccept = prevUsers
                .filter(u => u.isAI && u.friendRequests.some(r => r.from === humanId) && !u.friends.includes(humanId))
                .map(u => u.id);
            
            if (requestsToAccept.length === 0) {
                return prevUsers;
            }

            return prevUsers.map(user => {
                // For AIs that are accepting a request
                if (requestsToAccept.includes(user.id)) {
                    return {
                        ...user,
                        friends: [...user.friends, humanId],
                        friendRequests: user.friendRequests.filter(r => r.from !== humanId)
                    };
                }
                // For the human user
                if (user.id === humanId) {
                    return {
                        ...user,
                        friends: [...new Set([...user.friends, ...requestsToAccept])]
                    };
                }
                return user;
            });
        });
    }, [currentUser]);

    useEffect(() => {
        if (!currentUser) return; // Only run simulation when logged in
        const postInterval = setInterval(_createAiPost, 120000); // New post every 2 mins
        const likeInterval = setInterval(_createAiLike, 5000); // New like every 5s
        const commentInterval = setInterval(_createAiComment, 180000); // New comment every 3 mins
        const friendRequestInterval = setInterval(_createAiFriendRequest, 60000); // New friend request every minute

        // This makes AI users accept friend requests from the human user
        const acceptInterval = setInterval(_aiAcceptsHumanFriendRequests, 5000); // Check every 5 seconds

        return () => {
            clearInterval(postInterval);
            clearInterval(likeInterval);
            clearInterval(commentInterval);
            clearInterval(friendRequestInterval);
            clearInterval(acceptInterval);
        };
    }, [currentUser, _aiAcceptsHumanFriendRequests]);

    // User-facing functions
    const sendFriendRequest = (toId: string) => {
        if (!currentUser) return;
        setUsers(prev => prev.map(u => u.id === toId ? { ...u, friendRequests: [...u.friendRequests, { from: currentUser.id, to: toId }] } : u));
    };

    const acceptFriendRequest = (fromId: string) => {
        if (!currentUser) return;
        setUsers(prev => prev.map(u => {
            if (u.id === currentUser.id) {
                return { ...u, friends: [...u.friends, fromId], friendRequests: u.friendRequests.filter(r => r.from !== fromId) };
            }
            if (u.id === fromId) {
                return { ...u, friends: [...u.friends, currentUser.id] };
            }
            return u;
        }));
    };
    
    const declineFriendRequest = (fromId: string) => {
        if(!currentUser) return;
        setUsers(prev => prev.map(u => u.id === currentUser.id ? { ...u, friendRequests: u.friendRequests.filter(r => r.from !== fromId) } : u));
    };


    const createConnectSpherePost = (content: string, imageUrl?: string) => {
        if (!currentUser) return;

        const newPost: ConnectSpherePost = {
            id: uuidv4(),
            authorId: currentUser.id, authorName: currentUser.username,
            content, imageUrl,
            timestamp: Date.now(),
            likes: 0, likedBy: [], comments: [],
        };
        setConnectSphereState(prev => ({ ...prev, posts: [newPost, ...prev.posts] }));
    };

    const toggleLikeConnectSpherePost = (postId: string) => {
        if (!currentUser) return;
        setConnectSphereState(prev => {
            const newPosts = prev.posts.map(post => {
                if (post.id === postId) {
                    const isLiked = post.likedBy.includes(currentUser.id);
                    if (isLiked) {
                        return { ...post, likes: post.likes - 1, likedBy: post.likedBy.filter(id => id !== currentUser.id) };
                    } else {
                        return { ...post, likes: post.likes + 1, likedBy: [...post.likedBy, currentUser.id] };
                    }
                }
                return post;
            });
            return { ...prev, posts: newPosts };
        });
    };
    
    const addConnectSphereComment = (postId: string, content: string, author?: User) => {
        const commentAuthor = author || currentUser;
        if (!commentAuthor) return;
        const newComment: ConnectSphereComment = {
            id: uuidv4(),
            authorId: commentAuthor.id, authorName: commentAuthor.username,
            content, timestamp: Date.now(),
        };
        setConnectSphereState(prev => ({
            ...prev,
            posts: prev.posts.map(p => p.id === postId ? { ...p, comments: [...p.comments, newComment] } : p)
        }));
    };

    const sendDirectMessage = (toId: string, content: string, author?: User) => {
        const messageAuthor = author || currentUser;
        if(!messageAuthor) return;

        const participantIds = [messageAuthor.id, toId].sort();
        const conversationId = participantIds.join('--');

        const newMessage: DirectMessage = { id: uuidv4(), senderId: messageAuthor.id, content, timestamp: Date.now() };

        setConnectSphereState(prev => {
            const existingConvo = prev.conversations.find(c => c.id === conversationId);
            let newConversations;

            if (existingConvo) {
                newConversations = prev.conversations.map(c => c.id === conversationId ? { ...c, messages: [...c.messages, newMessage] } : c);
            } else {
                const newConvo: Conversation = { id: conversationId, participants: participantIds as [string, string], messages: [newMessage] };
                newConversations = [newConvo, ...prev.conversations];
            }
            return { ...prev, conversations: newConversations };
        });
        
        // If the user sent the message, trigger an AI response
        if(!author) {
             const convo = connectSphereState.conversations.find(c => c.id === conversationId) || { messages: [] };
             const historyText = [...convo.messages, newMessage]
                .slice(-5) // Get last 5 messages
                .map(m => `${users.find(u=>u.id === m.senderId)?.username}: ${m.content}`)
                .join('\n');
             _respondToDirectMessage(conversationId, historyText);
        }
    }
    
    // --- Context Value ---
    const value = useMemo(() => ({
        wallpaper, setWallpaper, dockSize, setDockSize, dockMagnification, setDockMagnification, networkSpeed, setNetworkSpeed,
        users, currentUser, signup, login, logout, sendFriendRequest, acceptFriendRequest, declineFriendRequest,
        installedApps, installingProgress, installApp,
        pinnedApps, pinApp, unpinApp,
        desktopShortcuts, addDesktopShortcut, removeDesktopShortcut,
        coins, addCoins,
        theme, setTheme, focusMode, setFocusMode,
        vfs, createVFSItem, renameVFSItem, moveVFSItemToTrash, emptyTrash, updateVFSFileContent,
        notesState, createNote, updateNote, deleteNote, createNoteFolder,
        photosState, importPhotos, createPhotoAlbum, addPhotoToAlbum, removePhotoFromAlbum, setPrivateAlbumPassword,
        browserState, addBookmark, removeBookmark, addHistoryItem,
        auraChatClearCount, clearAuraChat,
        connectSphereState, createConnectSpherePost, toggleLikeConnectSpherePost, addConnectSphereComment, sendDirectMessage,
        kingdomsState, setKingdomsState
    }), [
        wallpaper, dockSize, dockMagnification, networkSpeed, users, currentUser, installedApps, installingProgress,
        pinnedApps, desktopShortcuts, coins, theme, focusMode,
        vfs, notesState, photosState, browserState, auraChatClearCount, connectSphereState, kingdomsState,
        signup, login, logout, sendFriendRequest, acceptFriendRequest, declineFriendRequest, installApp, pinApp, unpinApp, addDesktopShortcut, removeDesktopShortcut, addCoins, setTheme, setFocusMode, createVFSItem, renameVFSItem, moveVFSItemToTrash, emptyTrash, updateVFSFileContent, createNote, updateNote, deleteNote, createNoteFolder, importPhotos, createPhotoAlbum, addPhotoToAlbum, removePhotoFromAlbum, setPrivateAlbumPassword, addBookmark, removeBookmark, addHistoryItem, clearAuraChat, createConnectSpherePost, toggleLikeConnectSpherePost, addConnectSphereComment, sendDirectMessage, setKingdomsState
    ]);

    return (
        <SettingsContext.Provider value={value}>
            {children}
        </SettingsContext.Provider>
    );
};

export const useSettings = (): SettingsContextType => {
    const context = useContext(SettingsContext);
    if (context === undefined) {
        throw new Error('useSettings must be used within a SettingsProvider');
    }
    return context;
};
