export const OS_NAME = "Aura";

export const WALLPAPERS = [
    { name: 'Sonoma Horizon', url: 'https://images.unsplash.com/photo-1684784332026-100f2e32e43f?q=80&w=2670&auto=format&fit=crop' },
    { name: 'Ventura Graphic', url: 'https://images.unsplash.com/photo-1667839353523-2de76abc31a3?q=80&w=2574&auto=format&fit=crop' },
    { name: 'Monterey Abstract', url: 'https://images.unsplash.com/photo-1635777418762-835c55a5b1f5?q=80&w=2670&auto=format&fit=crop' },
    { name: 'Big Sur', url: 'https://images.unsplash.com/photo-1603815334224-9669538ef877?q=80&w=2670&auto=format&fit=crop' },
    { name: 'Catalina Island', url: 'https://images.unsplash.com/photo-1574324734162-33d3957c5053?q=80&w=2670&auto=format&fit=crop' },
    { name: 'Mojave Night', url: 'https://images.unsplash.com/photo-1542337809-507621a6475f?q=80&w=2574&auto=format&fit=crop' },
    { name: 'Sierra', url: 'https://images.unsplash.com/photo-1647413695221-39e7638f362c?q=80&w=2670&auto=format&fit=crop' },
    { name: 'Abstract Flow', url: 'https://images.unsplash.com/photo-1558591710-4b4a1ae0f04d?q=80&w=2487&auto=format&fit=crop' },
    { name: 'Cosmic Nebula', url: 'https://images.unsplash.com/photo-1534796636912-3b95b3ab5986?q=80&w=2574&auto=format&fit=crop' },
    { name: 'Autumn Path', url: 'https://images.unsplash.com/photo-1476842634003-7dcca8f832de?q=80&w=2670&auto=format&fit=crop' },
];
