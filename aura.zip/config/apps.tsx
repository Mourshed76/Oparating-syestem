import React from 'react';
import type { AppDefinition } from '../types';

// Icons
import {
    FinderIcon, AuraIcon, AppStoreIcon, SettingsIcon, BrowserIcon, NotesIcon, MailIcon, CalendarIcon,
    RemindersIcon, PhotosIcon, MusicIcon, TVIcon, CalculatorIcon, TerminalIcon, ConnectSphereIcon,
    CodeEditorIcon, PodcastsIcon, ContactsIcon, WhiteboardIcon, FileSharingIcon, HomeIcon, PixelateIcon,
    AudiobooksIcon, ComicsIcon, NewsIcon, MapsIcon, WeatherIcon, StocksIcon, VoiceMemosIcon,
    // Game Icons
    BrickBreakerIcon, SnakeIcon, TicTacToeIcon, PongIcon, MinesweeperIcon, SudokuIcon, Game2048Icon,
    TetrisIcon, WordleIcon, FlappyAuraIcon, SolitaireIcon, PacManIcon, NitroRacerIcon, ChronoQuestIcon,
    GalaxyStrikeIcon, AsteroidsIcon, SuperJumperIcon, LogicBlocksIcon, KingdomsIcon, AuraCardsIcon, MahjongIcon, CheckersIcon, ChessIcon,
    VoidWallowIcon, WeaversGambitIcon, GildedHollowIcon, RustSwarmIcon
} from './icons';

// App Components
// System
import { FinderApp } from '../apps/system/Finder';
import { AuraApp } from '../apps/system/Aura';
import { AppStoreApp } from '../apps/system/AppStore';
import { SettingsApp } from '../apps/system/Settings';
import { TerminalApp } from '../apps/system/Terminal';
import { BrowserApp } from '../apps/system/Browser';

// Productivity
import { NotesApp } from '../apps/productivity/Notes';
import { RemindersApp } from '../apps/productivity/Reminders';
import { CalculatorApp } from '../apps/productivity/Calculator';
import { ConnectSphereApp } from '../apps/productivity/ConnectSphere';
import { MapsApp } from '../apps/productivity/Maps';
import { StocksApp } from '../apps/productivity/Stocks';
import { VoiceMemosApp } from '../apps/productivity/VoiceMemos';
import { CodeEditorApp } from '../apps/productivity/CodeEditor';
import { MailApp } from '../apps/productivity/Mail';
import { CalendarApp } from '../apps/productivity/Calendar';
import { ContactsApp } from '../apps/productivity/Contacts';
import { WhiteboardApp } from '../apps/productivity/Whiteboard';
import { DropZoneApp } from '../apps/productivity/DropZone';
import { HomeHubApp } from '../apps/productivity/HomeHub';

// Entertainment
import { PhotosApp } from '../apps/entertainment/Photos';
import { PixelateApp } from '../apps/entertainment/Pixelate';
import { NewsApp } from '../apps/entertainment/News';
import { WeatherApp } from '../apps/entertainment/Weather';
import { MusicApp } from '../apps/entertainment/Music';
import { TVApp } from '../apps/entertainment/TV';
import { PodcastsApp } from '../apps/entertainment/Podcasts';
import { AudiobooksApp } from '../apps/entertainment/Audiobooks';
import { ComicsApp } from '../apps/entertainment/Comics';

// Games
import { MinesweeperApp } from '../apps/games/Minesweeper';
import { SudokuApp } from '../apps/games/Sudoku';
import { Game2048App } from '../apps/games/Game2048';
import { TetrisApp } from '../apps/games/Tetris';
import { WordleApp } from '../apps/games/Wordle';
import { FlappyAuraApp } from '../apps/games/FlappyAura';
import { SolitaireApp } from '../apps/games/Solitaire';
import { PacManApp } from '../apps/games/PacMan';
import { NitroRacerApp } from '../apps/games/NitroRacer';
import { ChronoQuestApp } from '../apps/games/ChronoQuest';
import { GalaxyStrikeApp } from '../apps/games/GalaxyStrike';
import { AsteroidsApp } from '../apps/games/Asteroids';
import { SuperJumperApp } from '../apps/games/SuperJumper';
import { LogicBlocksApp } from '../apps/games/LogicBlocks';
import { KingdomsAscendancyApp } from '../apps/games/Kingdoms';
import { AuraCardsApp } from '../apps/games/AuraCards';
import { MahjongApp } from '../apps/games/Mahjong';
import { CheckersApp } from '../apps/games/Checkers';
import { VoidWallowApp } from '../apps/games/VoidWallow';
import { WeaversGambitApp } from '../apps/games/WeaversGambit';
import { GildedHollowApp } from '../apps/games/GildedHollow';
import { RustSwarmApp } from '../apps/games/RustSwarm';
import { ChessApp } from '../apps/games/Chess';
import { BrickBreakerApp } from '../apps/games/BrickBreaker';
import { SnakeApp } from '../apps/games/Snake';
import { TicTacToeApp } from '../apps/games/TicTacToe';
import { PongApp } from '../apps/games/Pong';


export const APPS: AppDefinition[] = [
    // System
    { id: 'finder', name: 'Finder', icon: <FinderIcon />, component: FinderApp, category: 'System', description: 'File manager for Aura.', sizeMB: 1.2 },
    { id: 'aura_chat', name: 'Aura', icon: <AuraIcon />, component: AuraApp, defaultSize: { width: 500, height: 680 }, category: 'System', description: 'Your personal AI assistant.', sizeMB: 5.5 },
    { id: 'browser', name: 'Nexus Browser', icon: <BrowserIcon />, component: BrowserApp, defaultSize: { width: 1024, height: 768 }, category: 'System', description: 'Browse the web with an AI-powered browser.', sizeMB: 8.1 },
    { id: 'app_store', name: 'App Store', icon: <AppStoreIcon />, component: AppStoreApp, defaultSize: { width: 800, height: 600 }, category: 'System', description: 'Discover and install new apps.', sizeMB: 3.4 },
    { id: 'settings', name: 'Settings', icon: <SettingsIcon />, component: SettingsApp, defaultSize: { width: 700, height: 500 }, category: 'System', description: 'Customize your Aura experience.', sizeMB: 2.1 },
    { id: 'terminal', name: 'Terminal', icon: <TerminalIcon />, component: TerminalApp, defaultSize: { width: 600, height: 400 }, category: 'System', description: 'Command-line interface for Aura.', sizeMB: 0.8 },
    
    // Productivity
    { id: 'notes', name: 'Notes', icon: <NotesIcon />, component: NotesApp, defaultSize: { width: 700, height: 550 }, category: 'Productivity', description: 'Jot down your thoughts.', sizeMB: 1.5 },
    { id: 'mail', name: 'Mail', icon: <MailIcon />, component: MailApp, defaultSize: { width: 900, height: 600 }, category: 'Productivity', description: 'Your inbox, simplified.', sizeMB: 4.2 },
    { id: 'calendar', name: 'Calendar', icon: <CalendarIcon />, component: CalendarApp, defaultSize: { width: 800, height: 600 }, category: 'Productivity', description: 'Manage your schedule.', sizeMB: 2.8 },
    { id: 'reminders', name: 'Reminders', icon: <RemindersIcon />, component: RemindersApp, defaultSize: { width: 400, height: 500 }, category: 'Productivity', description: 'Never forget a task.', sizeMB: 1.1 },
    { id: 'calculator', name: 'Calculator', icon: <CalculatorIcon />, component: CalculatorApp, defaultSize: { width: 320, height: 480 }, category: 'Productivity', description: 'Perform calculations.', sizeMB: 0.5 },
    { id: 'connect_sphere', name: 'ConnectSphere', icon: <ConnectSphereIcon />, component: ConnectSphereApp, defaultSize: { width: 1000, height: 700 }, category: 'Productivity', description: 'Connect with your friends.', sizeMB: 12.5 },
    { id: 'code_editor', name: 'CodePad', icon: <CodeEditorIcon />, component: CodeEditorApp, defaultSize: { width: 900, height: 650 }, category: 'Productivity', description: 'An AI-powered editor for code.', sizeMB: 3.8 },
    { id: 'contacts', name: 'Contacts', icon: <ContactsIcon />, component: ContactsApp, defaultSize: { width: 600, height: 500 }, category: 'Productivity', description: 'Manage your contacts.', sizeMB: 1.3 },
    { id: 'whiteboard', name: 'Whiteboard', icon: <WhiteboardIcon />, component: WhiteboardApp, defaultSize: { width: 700, height: 500 }, category: 'Productivity', description: 'Collaborate and sketch ideas.', sizeMB: 1.4 },
    { id: 'drop_zone', name: 'DropZone', icon: <FileSharingIcon />, component: DropZoneApp, defaultSize: { width: 500, height: 600 }, category: 'Productivity', description: 'Simulated file sharing.', sizeMB: 0.9 },
    { id: 'home_hub', name: 'Home Hub', icon: <HomeIcon />, component: HomeHubApp, defaultSize: { width: 600, height: 450 }, category: 'Productivity', description: 'Control your smart home.', sizeMB: 2.1 },
    { id: 'maps', name: 'Maps', icon: <MapsIcon />, component: MapsApp, defaultSize: { width: 800, height: 600 }, category: 'Productivity', description: 'Find places and get directions.', sizeMB: 2.4 },
    { id: 'stocks', name: 'Stocks', icon: <StocksIcon />, component: StocksApp, defaultSize: { width: 400, height: 600 }, category: 'Productivity', description: 'Track the stock market.', sizeMB: 1.2 },
    { id: 'voice_memos', name: 'Voice Memos', icon: <VoiceMemosIcon />, component: VoiceMemosApp, defaultSize: { width: 400, height: 550 }, category: 'Productivity', description: 'Record and listen to audio notes.', sizeMB: 1.0 },

    // Entertainment
    { id: 'photos', name: 'Photos', icon: <PhotosIcon />, component: PhotosApp, defaultSize: { width: 900, height: 600 }, category: 'Entertainment', description: 'Browse and edit your memories.', sizeMB: 5.6 },
    { id: 'pixelate', name: 'Pixelate', icon: <PixelateIcon />, component: PixelateApp, defaultSize: { width: 1024, height: 768 }, category: 'Entertainment', description: 'Advanced AI-powered photo editor.', sizeMB: 15.2 },
    { id: 'music', name: 'Music', icon: <MusicIcon />, component: MusicApp, defaultSize: { width: 750, height: 500 }, category: 'Entertainment', description: 'Listen to your favorite tunes.', sizeMB: 3.3 },
    { id: 'tv', name: 'TV', icon: <TVIcon />, component: TVApp, defaultSize: { width: 900, height: 600 }, category: 'Entertainment', description: 'Watch movies and shows.', sizeMB: 4.5 },
    { id: 'podcasts', name: 'Podcasts', icon: <PodcastsIcon />, component: PodcastsApp, defaultSize: { width: 750, height: 500 }, category: 'Entertainment', description: 'Listen to podcasts.', sizeMB: 3.1 },
    { id: 'audiobooks', name: 'Audiobooks', icon: <AudiobooksIcon />, component: AudiobooksApp, defaultSize: { width: 400, height: 600 }, category: 'Entertainment', description: 'Listen to your books.', sizeMB: 2.9 },
    { id: 'comics', name: 'Comics', icon: <ComicsIcon />, component: ComicsApp, defaultSize: { width: 600, height: 800 }, category: 'Entertainment', description: 'Read your favorite comics.', sizeMB: 4.8 },
    { id: 'news', name: 'News', icon: <NewsIcon />, component: NewsApp, defaultSize: { width: 900, height: 600 }, category: 'Entertainment', description: 'Stay up-to-date with the world.', sizeMB: 2.2 },
    { id: 'weather', name: 'Weather', icon: <WeatherIcon />, component: WeatherApp, defaultSize: { width: 400, height: 600 }, category: 'Entertainment', description: 'Check the weather forecast.', sizeMB: 0.9 },
    
    // Games
    { id: 'chess', name: 'Chess', icon: <ChessIcon />, component: ChessApp, defaultSize: { width: 420, height: 480 }, category: 'Games', description: 'The classic game of strategy.', sizeMB: 1.8 },
    { id: 'minesweeper', name: 'Minesweeper', icon: <MinesweeperIcon />, component: MinesweeperApp, defaultSize: { width: 500, height: 400 }, category: 'Games', description: 'Classic puzzle game.', sizeMB: 0.5 },
    { id: 'sudoku', name: 'Sudoku', icon: <SudokuIcon />, component: SudokuApp, defaultSize: { width: 500, height: 600 }, category: 'Games', description: 'Logic-based number puzzle.', sizeMB: 0.6 },
    { id: '2048', name: '2048', icon: <Game2048Icon />, component: Game2048App, defaultSize: { width: 450, height: 550 }, category: 'Games', description: 'Slide tiles to get to 2048.', sizeMB: 0.5 },
    { id: 'tetris', name: 'Tetris', icon: <TetrisIcon />, component: TetrisApp, defaultSize: { width: 450, height: 600 }, category: 'Games', description: 'Classic block-stacking game.', sizeMB: 0.7 },
    { id: 'wordle', name: 'Wordle', icon: <WordleIcon />, component: WordleApp, defaultSize: { width: 450, height: 650 }, category: 'Games', description: 'Guess the secret word.', sizeMB: 0.6 },
    { id: 'flappy_aura', name: 'Flappy Aura', icon: <FlappyAuraIcon />, component: FlappyAuraApp, defaultSize: { width: 420, height: 620 }, category: 'Games', description: 'Flap through the pipes.', sizeMB: 0.8 },
    { id: 'solitaire', name: 'Solitaire', icon: <SolitaireIcon />, component: SolitaireApp, defaultSize: { width: 700, height: 500 }, category: 'Games', description: 'Classic card game.', sizeMB: 1.1 },
    { id: 'pacman', name: 'Pac-Man', icon: <PacManIcon />, component: PacManApp, defaultSize: { width: 500, height: 550 }, category: 'Games', description: 'Eat all the pellets.', sizeMB: 0.9 },
    { id: 'nitro_racer', name: 'Nitro Racer', icon: <NitroRacerIcon />, component: NitroRacerApp, defaultSize: { width: 420, height: 620 }, category: 'Games', description: 'High-speed highway racing.', sizeMB: 1.3 },
    { id: 'chrono_quest', name: 'ChronoQuest', icon: <ChronoQuestIcon />, component: ChronoQuestApp, defaultSize: { width: 500, height: 700 }, category: 'Games', description: 'A text-based adventure.', sizeMB: 0.4 },
    { id: 'galaxy_strike', name: 'Galaxy Strike', icon: <GalaxyStrikeIcon />, component: GalaxyStrikeApp, defaultSize: { width: 520, height: 620 }, category: 'Games', description: 'Vertical space shooter.', sizeMB: 1.2 },
    { id: 'asteroids', name: 'Asteroids', icon: <AsteroidsIcon />, component: AsteroidsApp, defaultSize: { width: 620, height: 520 }, category: 'Games', description: 'Classic space shooter.', sizeMB: 1.0 },
    { id: 'super_jumper', name: 'Super Jumper', icon: <SuperJumperIcon />, component: SuperJumperApp, defaultSize: { width: 420, height: 620 }, category: 'Games', description: 'Jump as high as you can.', sizeMB: 0.9 },
    { id: 'logic_blocks', name: 'Logic Blocks', icon: <LogicBlocksIcon />, component: LogicBlocksApp, defaultSize: { width: 420, height: 520 }, category: 'Games', description: 'A block puzzle game.', sizeMB: 0.6 },
    { id: 'kingdoms', name: 'Kingdoms: Ascendancy', icon: <KingdomsIcon />, component: KingdomsAscendancyApp, defaultSize: { width: 1024, height: 768 }, category: 'Games', description: 'A 3D isometric real-time strategy game. Build your empire, command armies, and conquer your foes.', sizeMB: 15.5 },
    { id: 'aura_cards', name: 'Aura Cards', icon: <AuraCardsIcon />, component: AuraCardsApp, defaultSize: { width: 800, height: 700 }, category: 'Games', description: 'A strategic card game.', sizeMB: 1.4 },
    { id: 'mahjong', name: 'Mahjong', icon: <MahjongIcon />, component: MahjongApp, defaultSize: { width: 600, height: 500 }, category: 'Games', description: 'Classic tile-matching game.', sizeMB: 0.8 },
    { id: 'checkers', name: 'Checkers', icon: <CheckersIcon />, component: CheckersApp, defaultSize: { width: 450, height: 550 }, category: 'Games', description: 'Classic board game.', sizeMB: 0.7 },
    { id: 'brick_breaker', name: 'Brick Breaker', icon: <BrickBreakerIcon />, component: BrickBreakerApp, defaultSize: { width: 580, height: 500 }, category: 'Games', description: 'Break all the bricks.', sizeMB: 0.6 },
    { id: 'snake', name: 'Snake', icon: <SnakeIcon />, component: SnakeApp, defaultSize: { width: 440, height: 500 }, category: 'Games', description: 'A classic arcade game.', sizeMB: 0.4 },
    { id: 'tic_tac_toe', name: 'Tic-Tac-Toe', icon: <TicTacToeIcon />, component: TicTacToeApp, defaultSize: { width: 320, height: 420 }, category: 'Games', description: 'Play against a friend or AI.', sizeMB: 0.3 },
    { id: 'pong', name: 'Pong', icon: <PongIcon />, component: PongApp, defaultSize: { width: 620, height: 480 }, category: 'Games', description: 'The original arcade classic.', sizeMB: 0.4 },
    { id: 'void_wallow', name: 'Void Wallow', icon: <VoidWallowIcon />, component: VoidWallowApp, defaultSize: { width: 880, height: 560 }, category: 'Games', description: 'A deep survival and colony simulation game.', sizeMB: 3.2 },
    { id: 'weavers_gambit', name: 'Weaver\'s Gambit', icon: <WeaversGambitIcon />, component: WeaversGambitApp, defaultSize: { width: 840, height: 700 }, category: 'Games', description: 'A puzzle platformer where you bend the laws of physics.', sizeMB: 2.8 },
    { id: 'gilded_hollow', name: 'The Gilded Hollow', icon: <GildedHollowIcon />, component: GildedHollowApp, defaultSize: { width: 820, height: 620 }, category: 'Games', description: 'A beautiful, hand-drawn metroidvania adventure.', sizeMB: 25.0 },
    { id: 'rust_swarm', name: 'Rust Swarm', icon: <RustSwarmIcon />, component: RustSwarmApp, defaultSize: { width: 840, height: 700 }, category: 'Games', description: 'An RTS where you command thousands of units in a swarm.', sizeMB: 18.5 },
];