import React from 'react';

// --- App Icons ---
export const FinderIcon = () => (
    <svg viewBox="0 0 1024 1024" className="w-full h-full"><path d="M857.1 292.1c-4.2-11.4-14.3-19-26.6-19h-184c-13.2 0-24.5 9.1-27.2 21.6L512 800h371.7c13.4 0 25.2-9.4 27-22.5L857.1 292.1z" fill="#00A7F7"></path><path d="M492.4 294.6c-2.7-12.5-14-21.6-27.2-21.6h-184c-12.3 0-22.4 7.6-26.6 19L102.3 777.5c-1.8 13.1 10 24.5 23.4 24.5H512L492.4 294.6z" fill="#0079F7"></path><path d="M683.4 294.6L790.6 800H512L683.4 294.6z" fill="#0057D9"></path><path d="M512 800h-3.5L512 273.1 619.2 800H512z" fill="#00A7F7"></path><path d="M512 273.1c-13.4 0-13.4 0 0 0z" fill="#00C9F7"></path><path d="M640 457.1c0 70.7-57.3 128-128 128s-128-57.3-128-128 57.3-128 128-128 128 57.3 128 128z" fill="#383838"></path><path d="M621.7 457.1c0 61.7-50 111.7-111.7 111.7s-111.7-50-111.7-111.7 50-111.7 111.7-111.7 111.7 50 111.7 111.7z" fill="#545454"></path><path d="M512 562.2c-58.1 0-105.1-47-105.1-105.1S453.9 352 512 352s105.1 47 105.1 105.1-47.1 105.1-105.1 105.1z" fill="#383838"></path><path d="M448 457.1c0 35.3 28.7 64 64 64V393.1c-35.3 0-64 28.7-64 64z" fill="#00A7F7"></path><path d="M512 521.1c35.3 0 64-28.7 64-64h-64v64z" fill="#0079F7"></path><path d="M576 457.1c0-35.3-28.7-64-64-64v128c35.3 0 64-28.7 64-64z" fill="#0057D9"></path><path d="M470.9 416c-11.8 11.8-11.8 30.8 0 42.5 11.8 11.8 30.8 11.8 42.5 0 11.8-11.8 11.8-30.8 0-42.5-11.7-11.7-30.7-11.7-42.5 0z" fill="#FFFFFF"></path></svg>
);

export const AuraIcon = () => (
    <svg viewBox="0 0 100 100" className="w-full h-full"><radialGradient id="a" cx="33.84" cy="133.74" r="77.93" gradientTransform="matrix(1 0 0 .67 -2.57 -39.23)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#28c4f0"></stop><stop offset=".24" stop-color="#21bade"></stop><stop offset=".62" stop-color="#14a3be"></stop><stop offset=".88" stop-color="#0e97ab"></stop><stop offset="1" stop-color="#0c94a6"></stop></radialGradient><radialGradient id="b" cx="66.16" cy="133.74" r="77.93" gradientTransform="matrix(1 0 0 .67 -2.57 -39.23)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#d4349c"></stop><stop offset=".3" stop-color="#c93399"></stop><stop offset=".71" stop-color="#b23192"></stop><stop offset="1" stop-color="#a5308e"></stop></radialGradient><radialGradient id="c" cx="49.33" cy="116.03" r="79.91" gradientTransform="matrix(1 0 0 .67 -2.57 -39.23)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#a5308e"></stop><stop offset=".35" stop-color="#792e92"></stop><stop offset=".65" stop-color="#562c96"></stop><stop offset="1" stop-color="#3b2b99"></stop></radialGradient><circle cx="50" cy="50" r="45" fill="#1e1e1e"></circle><path fill="url(#a)" d="M72.5,50A22.5,22.5,0,0,1,50,72.5V50Z"></path><path fill="url(#b)" d="M50,27.5A22.5,22.5,0,0,1,72.5,50H50Z"></path><path fill="url(#c)" d="M27.5,50A22.5,22.5,0,0,1,50,27.5V50Z"></path><path fill="#0c94a6" d="M50,72.5A22.5,22.5,0,0,1,27.5,50H50Z"></path></svg>
);

export const NotesIcon = () => (
    <div className="w-full h-full rounded-[22%] bg-white shadow-md flex flex-col overflow-hidden">
        <div className="h-[20%] bg-[#f7d55f]"></div>
        <div className="flex-grow bg-[#fff] p-[10%] space-y-[10%]">
            <div className="w-full h-[8%] bg-gray-300 rounded-sm"></div>
            <div className="w-[80%] h-[8%] bg-gray-300 rounded-sm"></div>
            <div className="w-full h-[8%] bg-gray-300 rounded-sm"></div>
        </div>
    </div>
);

export const PhotosIcon = () => (
    <div className="w-full h-full flex items-center justify-center rounded-[22%] bg-white">
        <div className="relative w-[80%] h-[80%]">
             <svg viewBox="0 0 1024 1024" className="w-full h-full"><path d="M512 1024q-138.857 0-261.143-55.543t-210.857-150.857-150.857-210.857-55.543-261.143 55.543-261.143 150.857-210.857 210.857-150.857 261.143-55.543 261.143 55.543 210.857 150.857 150.857 210.857 55.543 261.143-55.543 261.143-150.857 210.857-210.857 150.857-261.143 55.543z" fill="#ffbd2e"></path><path d="M864 512q0-34.286-13.714-72.571t-36.571-70.286-56-61.143-70.286-44.571-78.286-21.143-78.286 21.143-70.286 44.571-56 61.143-36.571 70.286-13.714 72.571q0 34.286 13.714 72.571t36.571 70.286 56 61.143 70.286 44.571 78.286 21.143 78.286-21.143 70.286-44.571 56-61.143 36.571-70.286 13.714-72.571z" fill="#fff7e0"></path><path d="M512 1024q-212.571 0-362.286-149.714t-149.714-362.286 149.714-362.286 362.286-149.714 362.286 149.714 149.714 362.286-149.714 362.286-362.286 149.714z m0-822.857q-179.429 0-305.143 125.714t-125.714 305.143 125.714 305.143 305.143 125.714 305.143-125.714 125.714-305.143-125.714-305.143-305.143-125.714z" fill="#ff5e00"></path><path d="M950.857 512q0-34.286-13.714-72.571t-36.571-70.286-56-61.143-70.286-44.571-78.286-21.143-78.286 21.143-70.286 44.571-56 61.143-36.571 70.286-13.714 72.571q0 34.286 13.714 72.571t36.571 70.286 56 61.143 70.286 44.571 78.286 21.143 78.286-21.143 70.286-44.571 56-61.143 36.571-70.286 13.714-72.571z" fill="#ffac33"></path><path d="M950.857 512q0 73.143-26.286 142.857t-72.571 122.286-109.143 89.143-131.429 44.571-135.429-10.286-122.286-55.543-96-89.143-59.429-109.143-22.857-113.143 22.857-113.143 59.429-109.143 96-89.143 122.286-55.543 135.429-10.286 131.429 44.571 109.143 89.143 72.571 122.286 26.286 142.857z" fill="#ffd54f"></path><path d="M907.429 512q0-62.857-22.857-122.286t-62.286-104.571-93.714-76.571-113.143-38.286-116.571 9.714-104.571 48-82.286 76.571-51.429 93.714-19.429 96.571 19.429 96.571 51.429 93.714 82.286 76.571 104.571 48 116.571 9.714 113.143-38.286 93.714-76.571 62.286-104.571 22.857-122.286z" fill="#fffde7"></path><path d="M512 512m-91.429 0q0-38.286 26.857-65.143t64.571-26.857 64.571 26.857 26.857 65.143-26.857 65.143-64.571 26.857-64.571-26.857-26.857-65.143z" fill="#ff8f00"></path></svg>
        </div>
    </div>
);

export const AppStoreIcon = () => (
    <div className="w-full h-full rounded-[22%] bg-[#1a7efb] flex items-center justify-center">
        <div className="relative w-1/2 h-1/2">
            <div className="absolute w-full h-1 bg-white rounded-full top-1/2 -mt-0.5" style={{ transform: 'rotate(45deg)'}}></div>
            <div className="absolute w-full h-1 bg-white rounded-full top-1/2 -mt-0.5" style={{ transform: 'rotate(-45deg)'}}></div>
            <div className="absolute w-1 h-full bg-white rounded-full left-1/2 -ml-0.5"></div>
        </div>
    </div>
);

export const SettingsIcon = () => (
    <div className="w-full h-full rounded-[22%] bg-gradient-to-br from-gray-200 to-gray-300 flex items-center justify-center shadow-md">
        <div className="relative w-[70%] h-[70%]">
             <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M14.8341 19.3413L15.2536 15.2952C15.932 14.9961 16.5621 14.595 17.1189 14.1189L21.0118 15.6881L23.4996 11.5L19.9881 8.84301C20.0383 8.42398 20.0383 7.98976 19.9881 7.57073L23.4996 4.91375L21.0118 0.725513L17.1189 2.2947C16.5621 1.81864 15.932 1.41753 15.2536 1.1184L14.8341 -3.05176e-05H9.98818L9.56865 4.0461C8.8902 4.34522 8.26007 4.74633 7.70331 5.22239L3.81041 3.65318L1.3226 8L4.83411 10.657C4.78393 11.076 4.78393 11.5103 4.83411 11.9293L1.3226 14.5862L3.81041 18.7745L7.70331 17.2053C8.26007 17.6814 8.8902 18.0825 9.56865 18.3816L9.98818 22.4277H14.8341V19.3413Z" fill="#8A95A1"/>
                <circle cx="12.4114" cy="11.2137" r="3.73134" fill="#6C757D"/>
                <circle cx="12.4114" cy="11.2137" r="1.86567" fill="#ADB5BD"/>
            </svg>
        </div>
    </div>
);

export const BrowserIcon = () => (
    <div className="w-full h-full rounded-[22%] bg-white flex items-center justify-center shadow-md">
        <div className="w-[75%] h-[75%]">
            <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="50" cy="50" r="45" stroke="url(#g_paint0_radial_1_2)" strokeWidth="10"/>
                <circle cx="50" cy="50" r="30" stroke="url(#g_paint1_radial_1_2)" strokeWidth="4"/>
                <defs>
                <radialGradient id="g_paint0_radial_1_2" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(50 50) rotate(90) scale(50)">
                    <stop stopColor="#00A7F7"/>
                    <stop offset="1" stopColor="#0057D9"/>
                </radialGradient>
                <radialGradient id="g_paint1_radial_1_2" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(50 50) rotate(90) scale(32)">
                    <stop stopColor="#84FAB0"/>
                    <stop offset="1" stopColor="#8FD3F4"/>
                </radialGradient>
                </defs>
            </svg>
        </div>
    </div>
);

export const MailIcon = () => (
    <div className="w-full h-full rounded-[22%] bg-[#42a5f5] flex items-center justify-center shadow-md">
        <svg xmlns="http://www.w3.org/2000/svg" className="w-3/4 h-3/4 text-white" viewBox="0 0 24 24" fill="currentColor">
            <path d="M22 6c0-1.1-.9-2-2-2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6zm-2 0l-8 5-8-5h16zm0 12H4V8l8 5 8-5v10z"/>
        </svg>
    </div>
);

export const CalendarIcon = () => (
     <div className="w-full h-full rounded-[22%] bg-white shadow-md flex flex-col items-center justify-center text-center overflow-hidden">
        <div className="w-full bg-red-500 text-white font-bold text-[25%] py-[2%]">
            {new Date().toLocaleString('default', { month: 'short' }).toUpperCase()}
        </div>
        <div className="text-black font-bold text-[60%] leading-none">
            {new Date().getDate()}
        </div>
    </div>
);

export const MusicIcon = () => (
    <div className="w-full h-full rounded-[22%] bg-gradient-to-br from-pink-500 to-orange-400 flex items-center justify-center shadow-md">
        <svg xmlns="http://www.w3.org/2000/svg" className="w-3/5 h-3/5 text-white" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z"/>
        </svg>
    </div>
);

export const RemindersIcon = () => (
    <div className="w-full h-full rounded-[22%] bg-white flex items-center justify-center shadow-md p-2.5">
        <div className="w-full h-full flex flex-col space-y-1.5">
            <div className="flex items-center space-x-2"><div className="w-3 h-3 rounded-full border-2 border-orange-500"></div><div className="w-full h-2 bg-gray-300 rounded-full"></div></div>
            <div className="flex items-center space-x-2"><div className="w-3 h-3 rounded-full border-2 border-blue-500"></div><div className="w-4/5 h-2 bg-gray-300 rounded-full"></div></div>
            <div className="flex items-center space-x-2"><div className="w-3 h-3 rounded-full border-2 border-gray-400"></div><div className="w-full h-2 bg-gray-300 rounded-full"></div></div>
        </div>
    </div>
);

export const TVIcon = () => (
     <div className="w-full h-full rounded-[22%] bg-gray-900 flex items-center justify-center shadow-md p-2">
        <div className="w-full h-full border-2 border-gray-600 rounded-md bg-gray-800 flex flex-col items-center justify-center">
            <div className="w-4/5 h-1/2 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 rounded-sm"></div>
            <p className="text-white font-bold text-[20%] mt-1">TV</p>
        </div>
    </div>
);

export const CalculatorIcon = () => (
    <div className="w-full h-full rounded-[22%] bg-gray-200 flex items-center justify-center shadow-md text-3xl font-bold text-gray-800">
        <svg xmlns="http://www.w3.org/2000/svg" className="w-3/5 h-3/5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
            <path strokeLinecap="round" strokeLinejoin="round" d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 14h.01M12 17h.01M15 17h.01M4 7a2 2 0 012-2h12a2 2 0 012 2v10a2 2 0 01-2-2H6a2 2 0 01-2-2V7z" />
        </svg>
    </div>
);

export const TerminalIcon = () => (
    <div className="w-full h-full rounded-[22%] bg-[#1E1E1E] flex items-center justify-start shadow-md p-2">
       <div className="w-full h-full flex flex-col font-mono text-xs text-green-400">
           <div className="flex items-center">
                <span>&gt;</span>
                <div className="w-1.5 h-3 bg-green-400 animate-pulse ml-1"></div>
           </div>
       </div>
    </div>
);

export const ConnectSphereIcon = () => (
    <div className="w-full h-full rounded-[22%] bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center shadow-md">
        <svg xmlns="http://www.w3.org/2000/svg" className="w-3/5 h-3/5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
            <path strokeLinecap="round" strokeLinejoin="round" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
        </svg>
    </div>
);

// --- New App Icons ---
export const CodeEditorIcon = () => <div className="w-full h-full rounded-[22%] bg-[#2d3748] flex items-center justify-center text-green-400 font-mono text-xl shadow-md">{'</>'}</div>;
export const PodcastsIcon = () => <div className="w-full h-full rounded-[22%] bg-purple-600 flex items-center justify-center text-white shadow-md"><svg xmlns="http://www.w3.org/2000/svg" className="h-3/5 w-3/5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" /></svg></div>;
export const ContactsIcon = () => <div className="w-full h-full rounded-[22%] bg-gray-500 flex items-center justify-center text-white shadow-md"><svg xmlns="http://www.w3.org/2000/svg" className="h-3/5 w-3/5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M15 21a6 6 0 00-9-5.197M15 11a4 4 0 110-5.292M12 4.354a4 4 0 100 5.292" /></svg></div>;
export const WhiteboardIcon = () => <div className="w-full h-full rounded-[22%] bg-gray-100 flex items-center justify-center text-blue-500 shadow-md"><svg xmlns="http://www.w3.org/2000/svg" className="h-3/5 w-3/5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg></div>;
export const FileSharingIcon = () => <div className="w-full h-full rounded-[22%] bg-blue-400 flex items-center justify-center text-white shadow-md"><svg xmlns="http://www.w3.org/2000/svg" className="h-3/5 w-3/5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4" /></svg></div>;
export const HomeIcon = () => <div className="w-full h-full rounded-[22%] bg-orange-400 flex items-center justify-center text-white shadow-md"><svg xmlns="http://www.w3.org/2000/svg" className="h-3/5 w-3/5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg></div>;
export const PixelateIcon = () => (
    <div className="w-full h-full rounded-[22%] bg-gradient-to-br from-indigo-800 to-purple-800 flex items-center justify-center shadow-md">
        <svg xmlns="http://www.w3.org/2000/svg" className="w-3/5 h-3/5" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="1.5">
            <path d="M12 5C7.523 5 3.732 7.943 2.458 12c1.274 4.057 5.064 7 9.542 7 4.477 0 8.268-2.943 9.542-7C20.268 7.943 16.477 5 12 5z" />
            <path d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
            <path d="M12 9.5l-1-1-1 1 1 1 1-1zM10 12l-1-1-1 1 1 1 1-1zM12 14.5l-1-1-1 1 1 1 1-1zM14 12l-1-1-1 1 1 1 1-1z" fill="white" />
        </svg>
    </div>
);

export const AudiobooksIcon = () => <div className="w-full h-full rounded-[22%] bg-orange-500 flex items-center justify-center text-white shadow-md"><svg xmlns="http://www.w3.org/2000/svg" className="h-3/5 w-3/5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" /></svg></div>;
export const ComicsIcon = () => <div className="w-full h-full rounded-[22%] bg-yellow-400 flex items-center justify-center text-black font-bold text-lg shadow-md">💥</div>;
export const NewsIcon = () => <div className="w-full h-full rounded-[22%] bg-gray-100 flex items-center justify-center text-4xl shadow-md">📰</div>;
export const MapsIcon = () => <div className="w-full h-full rounded-[22%] bg-green-500 flex items-center justify-center text-4xl shadow-md">🗺️</div>;
export const WeatherIcon = () => <div className="w-full h-full rounded-[22%] bg-blue-400 flex items-center justify-center text-4xl shadow-md">🌦️</div>;
export const StocksIcon = () => <div className="w-full h-full rounded-[22%] bg-gray-800 flex items-center justify-center text-4xl shadow-md">📈</div>;
export const VoiceMemosIcon = () => <div className="w-full h-full rounded-[22%] bg-red-500 flex items-center justify-center text-4xl shadow-md">🎙️</div>;

// --- Game Icons ---
export const BrickBreakerIcon = () => <div className="w-full h-full rounded-[22%] bg-indigo-500 flex flex-col items-center justify-end p-2 space-y-1 shadow-md"><div className="w-full h-1 bg-white"></div><div className="grid grid-cols-4 gap-1 w-full"><div className="w-full h-2 bg-red-400"></div><div className="w-full h-2 bg-yellow-400"></div><div className="w-full h-2 bg-green-400"></div><div className="w-full h-2 bg-blue-400"></div></div></div>;
export const SnakeIcon = () => <div className="w-full h-full rounded-[22%] bg-green-500 flex items-center justify-center text-white shadow-md"><svg xmlns="http://www.w3.org/2000/svg" className="h-3/5 w-3/5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg></div>;
export const TicTacToeIcon = () => <div className="w-full h-full rounded-[22%] bg-gray-200 flex items-center justify-center text-gray-800 shadow-md"><svg xmlns="http://www.w3.org/2000/svg" className="h-3/5 w-3/5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 20l4-16m2 16l4-16M6 9h14M4 15h14" /></svg></div>;
export const PongIcon = () => <div className="w-full h-full rounded-[22%] bg-gray-800 flex items-center justify-between p-2 text-white shadow-md"><div className="w-1 h-6 bg-white rounded-full"></div><div className="w-1 h-6 bg-white rounded-full"></div></div>;
export const MinesweeperIcon = () => <div className="w-full h-full rounded-[22%] bg-gray-400 flex items-center justify-center text-4xl shadow-md">💣</div>;
export const SudokuIcon = () => <div className="w-full h-full rounded-[22%] bg-white grid grid-cols-3 grid-rows-3 p-1 gap-px border-2 border-gray-400 shadow-md">
    {[1,2,3,4,5,6,7,8,9].map(i => <div key={i} className="bg-blue-100 flex items-center justify-center text-blue-800 text-xs font-bold">{i}</div>)}
</div>;
export const Game2048Icon = () => <div className="w-full h-full rounded-[22%] bg-yellow-400 flex items-center justify-center text-white text-xl font-bold shadow-md">2048</div>;
export const TetrisIcon = () => <div className="w-full h-full rounded-[22%] bg-gray-900 flex items-center justify-center shadow-md p-2">
    <div className="grid grid-cols-3 gap-px w-3/4 h-1/2">
        <div className="bg-transparent"></div><div className="bg-purple-500"></div><div className="bg-transparent"></div>
        <div className="bg-purple-500"></div><div className="bg-purple-500"></div><div className="bg-purple-500"></div>
    </div>
</div>;
export const WordleIcon = () => <div className="w-full h-full rounded-[22%] bg-gray-800 flex flex-col items-center justify-center p-2 gap-1 shadow-md">
    <div className="flex gap-1 w-full"><div className="w-full h-2.5 bg-green-500"></div><div className="w-full h-2.5 bg-gray-600"></div><div className="w-full h-2.5 bg-yellow-500"></div><div className="w-full h-2.5 bg-gray-600"></div><div className="w-full h-2.5 bg-green-500"></div></div>
    <div className="flex gap-1 w-full"><div className="w-full h-2.5 bg-gray-600"></div><div className="w-full h-2.5 bg-yellow-500"></div><div className="w-full h-2.5 bg-gray-600"></div><div className="w-full h-2.5 bg-green-500"></div><div className="w-full h-2.5 bg-gray-600"></div></div>
</div>;
export const FlappyAuraIcon = () => <div className="w-full h-full rounded-[22%] bg-cyan-400 flex items-center justify-center text-white shadow-md"><svg viewBox="0 0 100 100" className="w-3/5 h-3/5"><radialGradient id="a_flappy_icon" cx="33.84" cy="133.74" r="77.93" gradientTransform="matrix(1 0 0 .67 -2.57 -39.23)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#28c4f0"></stop><stop offset=".24" stop-color="#21bade"></stop><stop offset=".62" stop-color="#14a3be"></stop><stop offset=".88" stop-color="#0e97ab"></stop><stop offset="1" stop-color="#0c94a6"></stop></radialGradient><radialGradient id="b_flappy_icon" cx="66.16" cy="133.74" r="77.93" gradientTransform="matrix(1 0 0 .67 -2.57 -39.23)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#d4349c"></stop><stop offset=".3" stop-color="#c93399"></stop><stop offset=".71" stop-color="#b23192"></stop><stop offset="1" stop-color="#a5308e"></stop></radialGradient><radialGradient id="c_flappy_icon" cx="49.33" cy="116.03" r="79.91" gradientTransform="matrix(1 0 0 .67 -2.57 -39.23)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#a5308e"></stop><stop offset=".35" stop-color="#792e92"></stop><stop offset=".65" stop-color="#562c96"></stop><stop offset="1" stop-color="#3b2b99"></stop></radialGradient><path fill="url(#a_flappy_icon)" d="M72.5,50A22.5,22.5,0,0,1,50,72.5V50Z"></path><path fill="url(#b_flappy_icon)" d="M50,27.5A22.5,22.5,0,0,1,72.5,50H50Z"></path><path fill="url(#c_flappy_icon)" d="M27.5,50A22.5,22.5,0,0,1,50,27.5V50Z"></path><path fill="#0c94a6" d="M50,72.5A22.5,22.5,0,0,1,27.5,50H50Z"></path></svg></div>;
export const SolitaireIcon = () => <div className="w-full h-full rounded-[22%] bg-green-700 flex items-center justify-center shadow-md p-2">
    <div className="relative w-full h-full">
        <div className="absolute w-3/4 h-3/4 bg-white rounded-md border-2 border-gray-400 top-0 left-0"></div>
        <div className="absolute w-3/4 h-3/4 bg-white rounded-md border-2 border-gray-400 top-1 left-1"></div>
        <div className="absolute w-3/4 h-3/4 bg-white rounded-md border-2 border-red-500 top-2 left-2 flex items-center justify-center text-red-500 font-bold text-lg">♥</div>
    </div>
</div>;
export const PacManIcon = () => <div className="w-full h-full rounded-[22%] bg-black flex items-center justify-center text-5xl text-yellow-400 shadow-md">ᗧ</div>;
export const NitroRacerIcon = () => <div className="w-full h-full rounded-[22%] bg-gray-600 flex items-center justify-center text-5xl shadow-md">🏎️</div>;
export const ChronoQuestIcon = () => <div className="w-full h-full rounded-[22%] bg-yellow-700 flex items-center justify-center text-4xl shadow-md">📜</div>;
export const GalaxyStrikeIcon = () => <div className="w-full h-full rounded-[22%] bg-indigo-900 flex items-center justify-center text-4xl shadow-md">🚀</div>;
export const AsteroidsIcon = () => <div className="w-full h-full rounded-[22%] bg-gray-800 flex items-center justify-center text-4xl shadow-md">☄️</div>;
export const SuperJumperIcon = () => <div className="w-full h-full rounded-[22%] bg-blue-300 flex items-center justify-center text-4xl shadow-md">🧗</div>;
export const LogicBlocksIcon = () => <div className="w-full h-full rounded-[22%] bg-gray-700 grid grid-cols-2 grid-rows-2 gap-1 p-2 shadow-md"><div className="bg-cyan-500 rounded-sm"></div><div className="bg-orange-500 rounded-sm"></div><div className="bg-green-500 rounded-sm"></div><div className="bg-yellow-500 rounded-sm"></div></div>;
export const KingdomsIcon = () => <div className="w-full h-full rounded-[22%] bg-green-600 flex items-center justify-center text-4xl shadow-md">🏰</div>;
export const AuraCardsIcon = () => <div className="w-full h-full rounded-[22%] bg-indigo-800 flex items-center justify-center text-4xl shadow-md">🃏</div>;
export const MahjongIcon = () => <div className="w-full h-full rounded-[22%] bg-green-800 flex items-center justify-center text-4xl shadow-md">🀄</div>;
export const CheckersIcon = () => <div className="w-full h-full rounded-[22%] bg-gray-400 grid grid-cols-2 grid-rows-2 shadow-md"><div className="bg-red-600"></div><div className="bg-black"></div><div className="bg-black"></div><div className="bg-red-600"></div></div>;
export const ChessIcon = () => <div className="w-full h-full rounded-[22%] bg-amber-800 flex items-center justify-center text-4xl text-white shadow-md">♞</div>;

export const VoidWallowIcon = () => <div className="w-full h-full rounded-[22%] bg-gray-700 flex items-center justify-center text-4xl shadow-md">⛏️</div>;
export const WeaversGambitIcon = () => <div className="w-full h-full rounded-[22%] bg-purple-800 flex items-center justify-center shadow-md"><svg xmlns="http://www.w3.org/2000/svg" className="h-3/5 w-3/5 text-purple-300" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 15l-2 5L9 9l-5 5M15 15l5-5l-5-5l-5 5" /></svg></div>;
export const GildedHollowIcon = () => <div className="w-full h-full rounded-[22%] bg-gray-800 flex items-center justify-center text-4xl shadow-md">🛡️</div>;
export const RustSwarmIcon = () => <div className="w-full h-full rounded-[22%] bg-orange-900 flex items-center justify-center shadow-md p-2">
    <div className="relative w-full h-full">
        <div className="absolute w-1.5 h-1.5 bg-orange-400 rounded-full top-[30%] left-[30%] animate-pulse"></div>
        <div className="absolute w-1.5 h-1.5 bg-orange-400 rounded-full top-[50%] left-[60%]" style={{animation: 'pulse 1s infinite .2s'}}></div>
        <div className="absolute w-1.5 h-1.5 bg-orange-400 rounded-full top-[60%] left-[20%]" style={{animation: 'pulse 1s infinite .4s'}}></div>
        <div className="absolute w-1.5 h-1.5 bg-orange-400 rounded-full top-[20%] left-[70%]" style={{animation: 'pulse 1s infinite .6s'}}></div>
    </div>
</div>;
