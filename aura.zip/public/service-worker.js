const CACHE_NAME = 'aura-os-cache-v2-full-offline';
const urlsToCache = [
  '/',
  '/index.html',
  // Core Dependencies
  'https://cdn.tailwindcss.com',
  "https://esm.sh/@google/genai@^1.12.0",
  "https://esm.sh/react-dom@^19.1.1/client",
  "https://esm.sh/react@^19.1.1",
  "https://esm.sh/react",
  "https://esm.sh/react-dom/",
  "https://esm.sh/react/",
  "https://esm.sh/uuid@^11.1.0",
  "https://esm.sh/@faker-js/faker@^8.4.1",
  "https://esm.sh/chess.js@^1.4.0",
  "https://esm.sh/react-chessboard@^5.2.1",
  // Wallpapers
  'https://images.unsplash.com/photo-1684784332026-100f2e32e43f?q=80&w=2670&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1667839353523-2de76abc31a3?q=80&w=2574&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1635777418762-835c55a5b1f5?q=80&w=2670&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1603815334224-9669538ef877?q=80&w=2670&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1574324734162-33d3957c5053?q=80&w=2670&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1542337809-507621a6475f?q=80&w=2574&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1647413695221-39e7638f362c?q=80&w=2670&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1558591710-4b4a1ae0f04d?q=80&w=2487&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1534796636912-3b95b3ab5986?q=80&w=2574&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1476842634003-7dcca8f832de?q=80&w=2670&auto=format&fit=crop',
  // Sample images for apps to ensure offline functionality
  'https://picsum.photos/seed/aura_photos_1/1200/800',
  'https://picsum.photos/seed/aura_photos_2/1200/800',
  'https://picsum.photos/seed/aura_connect_1/600/400',
  'https://picsum.photos/seed/news1/400/200',
  'https://picsum.photos/seed/news2/400/200',
  // App icons and manifest
  '/favicon.ico',
  '/manifest.json',
  '/icon-192.png',
  '/icon-512.png',
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Opened cache and caching assets for offline use.');
        // Use addAll with a catch to prevent install failure if one asset fails
        return Promise.all(
          urlsToCache.map(url => {
            return cache.add(url).catch(err => {
              console.warn(`Failed to cache ${url}:`, err);
            });
          })
        );
      })
  );
});

self.addEventListener('fetch', event => {
  const requestUrl = new URL(event.request.url);

  // Always go to network for Gemini API calls
  if (requestUrl.hostname.includes('generativelanguage.googleapis.com')) {
    event.respondWith(fetch(event.request));
    return;
  }
  
  // For other requests, use Cache-First strategy
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        // Cache hit - return response
        if (response) {
          return response;
        }

        // Not in cache - go to network
        return fetch(event.request).then(
          response => {
            // Check if we received a valid response
            if (!response || response.status !== 200 || (response.type !== 'basic' && response.type !== 'cors')) {
              return response;
            }

            // IMPORTANT: Clone the response.
            const responseToCache = response.clone();

            caches.open(CACHE_NAME)
              .then(cache => {
                // Cache the new resource
                cache.put(event.request, responseToCache);
              });

            return response;
          }
        ).catch(err => {
            console.log('Fetch failed; app is offline.', err);
            // Could return a generic offline fallback page if needed.
        });
      })
  );
});

self.addEventListener('activate', event => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});
