import React, { useState, useEffect, useCallback, useRef } from 'react';
import type { AppProps } from '../../types';

const GAME_WIDTH = 400;
const GAME_HEIGHT = 600;
const PLAYER_WIDTH = 50;
const PLAYER_HEIGHT = 80;
const OBSTACLE_WIDTH = 50;
const OBSTACLE_HEIGHT = 80;
const LANES = [50, 175, 300];

export const NitroRacerApp: React.FC<AppProps> = () => {
    const [playerLane, setPlayerLane] = useState(1);
    const [obstacles, setObstacles] = useState<{ id: number; lane: number; y: number }[]>([]);
    const [score, setScore] = useState(0);
    const [gameState, setGameState] = useState<'menu' | 'playing' | 'gameOver'>('menu');
    const gameLoopRef = useRef<number | null>(null);

    const resetGame = () => {
        setPlayerLane(1);
        setObstacles([]);
        setScore(0);
        setGameState('menu');
    };

    const startGame = () => {
        setGameState('playing');
        setObstacles([{ id: Date.now(), lane: Math.floor(Math.random() * 3), y: -OBSTACLE_HEIGHT }]);
    };

    const gameLoop = useCallback(() => {
        if (gameState !== 'playing') return;

        setObstacles(prev => {
            const speed = 2 + Math.floor(score / 500); // Speed increases with score
            const newObstacles = prev
                .map(o => ({ ...o, y: o.y + speed }))
                .filter(o => o.y < GAME_HEIGHT);

            // Add new obstacle
            const lastObstacle = newObstacles[newObstacles.length - 1];
            if (!lastObstacle || lastObstacle.y > 200) {
                newObstacles.push({ id: Date.now(), lane: Math.floor(Math.random() * 3), y: -OBSTACLE_HEIGHT });
            }

            // Check collision
            for (const o of newObstacles) {
                if (o.lane === playerLane && o.y + OBSTACLE_HEIGHT > GAME_HEIGHT - PLAYER_HEIGHT - 20 && o.y < GAME_HEIGHT - 20) {
                    setGameState('gameOver');
                }
            }

            return newObstacles;
        });

        setScore(prev => prev + 1);
        gameLoopRef.current = requestAnimationFrame(gameLoop);
    }, [gameState, playerLane, score]);

    useEffect(() => {
        if (gameState === 'playing') {
            gameLoopRef.current = requestAnimationFrame(gameLoop);
        }
        return () => {
            if (gameLoopRef.current) cancelAnimationFrame(gameLoopRef.current);
        };
    }, [gameState, gameLoop]);

    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            if (gameState !== 'playing') return;
            if (e.key === 'ArrowLeft') {
                setPlayerLane(prev => Math.max(0, prev - 1));
            } else if (e.key === 'ArrowRight') {
                setPlayerLane(prev => Math.min(2, prev + 1));
            }
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [gameState]);

    return (
        <div className="w-full h-full flex items-center justify-center bg-gray-700 select-none">
            <div className="relative overflow-hidden bg-gray-500 border-4 border-gray-800" style={{ width: GAME_WIDTH, height: GAME_HEIGHT }}>
                {/* Road markings */}
                <div className="absolute top-0 left-[125px] h-full w-2 bg-yellow-400" />
                <div className="absolute top-0 left-[275px] h-full w-2 bg-yellow-400" />

                {/* Player */}
                <div className="absolute text-5xl transition-all duration-100" style={{ left: LANES[playerLane], top: GAME_HEIGHT - PLAYER_HEIGHT - 20 }}>🏎️</div>

                {/* Obstacles */}
                {obstacles.map(o => (
                    <div key={o.id} className="absolute text-5xl" style={{ left: LANES[o.lane], top: o.y }}>🚓</div>
                ))}
                
                <div className="absolute top-4 left-4 bg-black/50 text-white p-2 rounded-lg font-mono">Score: {score}</div>
                
                {gameState !== 'playing' && (
                     <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center text-center text-white">
                        {gameState === 'menu' && (
                            <>
                                <h1 className="text-5xl font-bold">Nitro Racer</h1>
                                <button onClick={startGame} className="mt-8 px-6 py-3 bg-green-500 rounded-lg text-xl border-b-4 border-green-700 hover:bg-green-400">Start Game</button>
                            </>
                        )}
                         {gameState === 'gameOver' && (
                            <>
                                <h1 className="text-5xl font-bold text-red-500">Game Over</h1>
                                <p className="text-2xl mt-2">Final Score: {score}</p>
                                <button onClick={resetGame} className="mt-6 px-6 py-3 bg-blue-500 rounded-lg text-xl border-b-4 border-blue-700 hover:bg-blue-400">Try Again</button>
                            </>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
};