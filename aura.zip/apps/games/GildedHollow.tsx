import React, { useState, useEffect, useCallback, useRef } from 'react';
import type { AppProps } from '../../types';

const GAME_WIDTH = 800;
const GAME_HEIGHT = 600;
const PLAYER_WIDTH = 32;
const PLAYER_HEIGHT = 48;
const GRAVITY = 0.6;
const JUMP_FORCE = -12;
const MOVE_SPEED = 4;

interface Rect { x: number; y: number; width: number; height: number; }
interface Enemy { id: number; x: number; y: number; width: number; height: number; health: number; direction: -1 | 1; }

const levelLayout: Rect[] = [
    // Ground
    { x: 0, y: 550, width: 800, height: 50 },
    // Platforms
    { x: 200, y: 450, width: 150, height: 20 },
    { x: 450, y: 380, width: 200, height: 20 },
    { x: 100, y: 300, width: 100, height: 20 },
    { x: 0, y: 200, width: 80, height: 20 },
    { x: 600, y: 250, width: 150, height: 20 },
];

const initialEnemies: Enemy[] = [
    { id: 1, x: 500, y: 340, width: 40, height: 40, health: 100, direction: -1 },
    { id: 2, x: 220, y: 510, width: 40, height: 40, health: 100, direction: 1 },
];

export const GildedHollowApp: React.FC<AppProps> = () => {
    const [player, setPlayer] = useState({ x: 50, y: 500, vx: 0, vy: 0, health: 100, isAttacking: false, facing: 1 });
    const [enemies, setEnemies] = useState<Enemy[]>(initialEnemies);
    const [gameState, setGameState] = useState<'playing' | 'gameOver'>('playing');
    
    const gameLoopRef = useRef<number | null>(null);
    const keysPressed = useRef<{ [key: string]: boolean }>({});
    const attackTimeoutRef = useRef<number | null>(null);

    const resetGame = () => {
        setPlayer({ x: 50, y: 500, vx: 0, vy: 0, health: 100, isAttacking: false, facing: 1 });
        setEnemies(initialEnemies);
        setGameState('playing');
    };

    const gameLoop = useCallback(() => {
        if (gameState !== 'playing') return;

        setPlayer(p => {
            let { x, y, vx, vy, health, facing } = p;
            
            // Horizontal movement
            vx = 0;
            if (keysPressed.current['ArrowLeft']) { vx = -MOVE_SPEED; facing = -1; }
            if (keysPressed.current['ArrowRight']) { vx = MOVE_SPEED; facing = 1; }
            x += vx;
            x = Math.max(0, Math.min(x, GAME_WIDTH - PLAYER_WIDTH));

            // Gravity & Vertical movement
            vy += GRAVITY;
            y += vy;

            // Collision with platforms
            let onGround = false;
            for (const plat of levelLayout) {
                if (x + PLAYER_WIDTH > plat.x && x < plat.x + plat.width && y + PLAYER_HEIGHT > plat.y && y < plat.y + plat.height) {
                    if (vy > 0 && p.y + PLAYER_HEIGHT <= plat.y) {
                        y = plat.y - PLAYER_HEIGHT;
                        vy = 0;
                        onGround = true;
                    }
                }
            }
             if (keysPressed.current['ArrowUp'] && onGround) {
                vy = JUMP_FORCE;
            }

            return { ...p, x, y, vx, vy, facing };
        });

        // Enemy logic & collision
        setEnemies(es => es.map(e => {
            let newX = e.x + e.direction * 0.5;
            let newDirection = e.direction;
            if (newX < 0 || newX > GAME_WIDTH - e.width) newDirection *= -1;
            return {...e, x: newX, direction: newDirection };
        }));

        // Attack logic
        if(player.isAttacking) {
            const attackHitbox: Rect = {
                x: player.facing === 1 ? player.x + PLAYER_WIDTH : player.x - 40,
                y: player.y,
                width: 40,
                height: PLAYER_HEIGHT
            };

            setEnemies(es => es.map(e => {
                if(attackHitbox.x < e.x + e.width && attackHitbox.x + attackHitbox.width > e.x &&
                   attackHitbox.y < e.y + e.height && attackHitbox.y + attackHitbox.height > e.y) {
                    return {...e, health: e.health - 25}; // Deal 25 damage
                }
                return e;
            }).filter(e => e.health > 0));
        }


        gameLoopRef.current = requestAnimationFrame(gameLoop);
    }, [gameState, player.isAttacking, player.facing, player.x, player.y]);

    useEffect(() => {
        if (gameState === 'playing') gameLoopRef.current = requestAnimationFrame(gameLoop);
        return () => { if (gameLoopRef.current) cancelAnimationFrame(gameLoopRef.current); };
    }, [gameState, gameLoop]);

    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            keysPressed.current[e.key] = true;
            if (e.key === ' ' && !player.isAttacking) {
                setPlayer(p => ({ ...p, isAttacking: true }));
                attackTimeoutRef.current = window.setTimeout(() => {
                    setPlayer(p => ({ ...p, isAttacking: false }));
                }, 200);
            }
        };
        const handleKeyUp = (e: KeyboardEvent) => { keysPressed.current[e.key] = false; };

        window.addEventListener('keydown', handleKeyDown);
        window.addEventListener('keyup', handleKeyUp);
        return () => {
            window.removeEventListener('keydown', handleKeyDown);
            window.removeEventListener('keyup', handleKeyUp);
            if (attackTimeoutRef.current) clearTimeout(attackTimeoutRef.current);
        };
    }, [player.isAttacking]);
    
    return (
        <div className="w-full h-full bg-gray-800 flex flex-col items-center justify-center p-4 text-white font-mono select-none">
            <div className="relative overflow-hidden bg-gray-900 border-2 border-gray-600" style={{ width: GAME_WIDTH, height: GAME_HEIGHT }}>
                {/* Background */}
                <div className="absolute inset-0 bg-gradient-to-b from-indigo-900 to-black" />

                {/* Level */}
                {levelLayout.map((p, i) => <div key={i} className="absolute bg-gray-600 border-t border-gray-400" style={{ left: p.x, top: p.y, width: p.width, height: p.height }} />)}
                
                {/* Enemies */}
                {enemies.map(e => <div key={e.id} className="absolute bg-red-700 rounded-md" style={{ left: e.x, top: e.y, width: e.width, height: e.height }} />)}

                {/* Player */}
                <div className="absolute bg-blue-500" style={{ left: player.x, top: player.y, width: PLAYER_WIDTH, height: PLAYER_HEIGHT }}>
                    {player.isAttacking && (
                        <div className="absolute bg-yellow-300/50" style={{
                            top: 10, height: PLAYER_HEIGHT - 20, width: 40,
                            left: player.facing === 1 ? PLAYER_WIDTH : -40
                        }}/>
                    )}
                </div>

                {/* UI */}
                <div className="absolute top-2 left-2 bg-black/50 p-2 rounded">Health: {player.health}</div>
                
                 {gameState === 'gameOver' && (
                     <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center text-center">
                        <h1 className="text-5xl font-bold text-red-500">You Died</h1>
                        <button onClick={resetGame} className="mt-6 px-6 py-3 bg-blue-500 rounded-lg text-xl">Try Again</button>
                    </div>
                 )}
            </div>
        </div>
    );
};
