import React, { useState, useEffect, useCallback, useRef } from 'react';
import type { AppProps, GameState } from '../../types';
import { useSettings } from '../../context/SettingsContext';

const BOARD_SIZE = 20;
const TILE_SIZE = 20;
const INITIAL_SNAKE = [{ x: 8, y: 10 }, { x: 9, y: 10 }, { x: 10, y: 10 }];
const INITIAL_DIRECTION = { dx: -1, dy: 0 };

const GameOverlay: React.FC<{ gameState: GameState; score: number; onStart: () => void; onResume: () => void; onRestart: () => void; }> = ({ gameState, score, onStart, onResume, onRestart }) => (
    <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center text-white font-mono z-10">
        {gameState === 'menu' && (
            <>
                <h1 className="text-4xl font-bold">Snake</h1>
                <button onClick={onStart} className="mt-6 px-6 py-3 bg-green-500 rounded-lg text-xl border-b-4 border-green-700 hover:bg-green-400">Start Game</button>
            </>
        )}
        {gameState === 'paused' && (
            <>
                <h1 className="text-4xl font-bold">Paused</h1>
                <div className="flex gap-4 mt-6">
                    <button onClick={onResume} className="px-6 py-3 bg-blue-500 rounded-lg text-xl border-b-4 border-blue-700 hover:bg-blue-400">Resume</button>
                    <button onClick={onRestart} className="px-6 py-3 bg-gray-500 rounded-lg text-xl border-b-4 border-gray-700 hover:bg-gray-400">Restart</button>
                </div>
            </>
        )}
        {gameState === 'gameOver' && (
            <>
                <h1 className="text-4xl font-bold text-red-500">Game Over</h1>
                <p className="text-2xl mt-2">Final Score: {score}</p>
                <button onClick={onRestart} className="mt-6 px-6 py-3 bg-blue-500 rounded-lg text-xl border-b-4 border-blue-700 hover:bg-blue-400">Try Again</button>
            </>
        )}
    </div>
);


export const SnakeApp: React.FC<AppProps> = () => {
    const { addCoins } = useSettings();
    const [gameState, setGameState] = useState<GameState>('menu');
    const [snake, setSnake] = useState(INITIAL_SNAKE);
    const [food, setFood] = useState({ x: 5, y: 5 });
    const [direction, setDirection] = useState(INITIAL_DIRECTION);
    const [score, setScore] = useState(0);

    const generateFood = (currentSnake: {x:number, y:number}[]) => {
        let newFood;
        do {
            newFood = {
                x: Math.floor(Math.random() * BOARD_SIZE),
                y: Math.floor(Math.random() * BOARD_SIZE),
            };
        } while (currentSnake.some(segment => segment.x === newFood.x && segment.y === newFood.y));
        setFood(newFood);
    };

    const resetGame = () => {
        setSnake(INITIAL_SNAKE);
        setDirection(INITIAL_DIRECTION);
        generateFood(INITIAL_SNAKE);
        setScore(0);
    };
    
    const startGame = () => {
        resetGame();
        setGameState('playing');
    }

    const gameLoop = useCallback(() => {
        if (gameState !== 'playing') return;

        const newSnake = [...snake];
        const head = { x: newSnake[0].x + direction.dx, y: newSnake[0].y + direction.dy };

        // Wall collision
        if (head.x >= BOARD_SIZE || head.x < 0 || head.y >= BOARD_SIZE || head.y < 0) {
            setGameState('gameOver');
            addCoins(score);
            return;
        }

        // Self collision
        for (const segment of newSnake) {
            if (segment.x === head.x && segment.y === head.y) {
                setGameState('gameOver');
                addCoins(score);
                return;
            }
        }
        
        newSnake.unshift(head);
        
        // Food collision
        if (head.x === food.x && head.y === food.y) {
            setScore(s => s + 1);
            generateFood(newSnake);
        } else {
            newSnake.pop();
        }

        setSnake(newSnake);
    }, [snake, direction, food, gameState, score, addCoins]);
    
    useEffect(() => {
        const interval = setInterval(gameLoop, 150);
        return () => clearInterval(interval);
    }, [gameLoop]);

    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
             switch (e.key) {
                case 'ArrowUp': if (direction.dy === 0) setDirection({ dx: 0, dy: -1 }); break;
                case 'ArrowDown': if (direction.dy === 0) setDirection({ dx: 0, dy: 1 }); break;
                case 'ArrowLeft': if (direction.dx === 0) setDirection({ dx: -1, dy: 0 }); break;
                case 'ArrowRight': if (direction.dx === 0) setDirection({ dx: 1, dy: 0 }); break;
                case 'Escape': setGameState(gs => gs === 'playing' ? 'paused' : 'playing'); break;
            }
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [direction]);

    return (
        <div className="w-full h-full bg-gray-800 flex flex-col items-center justify-center select-none">
            <div className="text-white text-xl mb-2 font-mono">Score: {score}</div>
            <div className="relative bg-gray-900" style={{ width: BOARD_SIZE * TILE_SIZE, height: BOARD_SIZE * TILE_SIZE }}>
                 {gameState !== 'playing' && <GameOverlay gameState={gameState} score={score} onStart={startGame} onResume={() => setGameState('playing')} onRestart={startGame}/>}
                {snake.map((segment, i) => (
                    <div key={i} className="absolute bg-green-500" style={{ left: segment.x * TILE_SIZE, top: segment.y * TILE_SIZE, width: TILE_SIZE, height: TILE_SIZE }} />
                ))}
                <div className="absolute bg-red-500 rounded-full" style={{ left: food.x * TILE_SIZE, top: food.y * TILE_SIZE, width: TILE_SIZE, height: TILE_SIZE }} />
            </div>
        </div>
    );
};
