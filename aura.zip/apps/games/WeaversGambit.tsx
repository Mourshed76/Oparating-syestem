import React, { useState, useEffect, useCallback, useRef } from 'react';
import type { AppProps } from '../../types';

const GAME_WIDTH = 800;
const GAME_HEIGHT = 600;
const PLAYER_SIZE = 30;
const GRAVITY = 0.5;
const JUMP_FORCE = -10;
const MOVE_SPEED = 5;

interface Rect { x: number; y: number; width: number; height: number; }
const platforms: Rect[] = [
    { x: 0, y: 550, width: 200, height: 50 },
    { x: 300, y: 450, width: 200, height: 30 },
    { x: 100, y: 300, width: 150, height: 30 },
    { x: 600, y: 550, width: 200, height: 50 },
    { x: 650, y: 150, width: 150, height: 30 }, // Goal
];

export const WeaversGambitApp: React.FC<AppProps> = () => {
    const [player, setPlayer] = useState({ x: 50, y: 500, vx: 0, vy: 0 });
    const [fields, setFields] = useState<Rect[]>([]);
    const [isWeaving, setIsWeaving] = useState(false);
    const weaveStartPos = useRef<{ x: number, y: number } | null>(null);
    const [gameState, setGameState] = useState<'playing' | 'won'>('playing');
    
    const gameAreaRef = useRef<HTMLDivElement>(null);
    const keysPressed = useRef<{ [key: string]: boolean }>({});

    const gameLoop = useCallback(() => {
        if (gameState !== 'playing') return;

        setPlayer(p => {
            let { x, y, vx, vy } = p;
            
            // Horizontal movement
            vx = 0;
            if (keysPressed.current['ArrowLeft']) vx = -MOVE_SPEED;
            if (keysPressed.current['ArrowRight']) vx = MOVE_SPEED;
            x += vx;
            
            // Gravity
            let currentGravity = GRAVITY;
            const inField = fields.some(f => x + PLAYER_SIZE > f.x && x < f.x + f.width && y + PLAYER_SIZE > f.y && y < f.y + f.height);
            if (inField) {
                currentGravity = -GRAVITY * 0.8; // Anti-gravity, slightly weaker
            }
            vy += currentGravity;
            y += vy;
            
            // Collision
            let onGround = false;
            for (const plat of platforms) {
                 if (x + PLAYER_SIZE > plat.x && x < plat.x + plat.width && y + PLAYER_SIZE > plat.y && y < plat.y + plat.height) {
                    if (vy > 0 && p.y + PLAYER_SIZE <= plat.y) { // Landed on top
                        y = plat.y - PLAYER_SIZE;
                        vy = 0;
                        onGround = true;
                    }
                }
            }

            // Jump
            if (keysPressed.current['ArrowUp'] && onGround) {
                vy = JUMP_FORCE;
            }

            // Win condition
            const goalPlatform = platforms[4];
            if(x + PLAYER_SIZE > goalPlatform.x && x < goalPlatform.x + goalPlatform.width && y + PLAYER_SIZE > goalPlatform.y && y < goalPlatform.y + goalPlatform.height) {
                setGameState('won');
            }

            return { x, y, vx, vy };
        });
        
        requestAnimationFrame(gameLoop);
    }, [fields, gameState]);

    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => { keysPressed.current[e.key] = true; };
        const handleKeyUp = (e: KeyboardEvent) => { keysPressed.current[e.key] = false; };
        window.addEventListener('keydown', handleKeyDown);
        window.addEventListener('keyup', handleKeyUp);
        requestAnimationFrame(gameLoop);
        return () => {
            window.removeEventListener('keydown', handleKeyDown);
            window.removeEventListener('keyup', handleKeyUp);
        };
    }, [gameLoop]);

    const getMousePos = (e: React.MouseEvent) => {
        const rect = gameAreaRef.current?.getBoundingClientRect();
        if (!rect) return { x: 0, y: 0 };
        return { x: e.clientX - rect.left, y: e.clientY - rect.top };
    };
    
    const handleMouseDown = (e: React.MouseEvent) => {
        setIsWeaving(true);
        weaveStartPos.current = getMousePos(e);
        setFields([]); // Only one field at a time for simplicity
    };
    
    const handleMouseMove = (e: React.MouseEvent) => {
        if (!isWeaving || !weaveStartPos.current) return;
        const pos = getMousePos(e);
        const newField = {
            x: Math.min(pos.x, weaveStartPos.current.x),
            y: Math.min(pos.y, weaveStartPos.current.y),
            width: Math.abs(pos.x - weaveStartPos.current.x),
            height: Math.abs(pos.y - weaveStartPos.current.y)
        };
        setFields([newField]);
    };
    
    const handleMouseUp = () => {
        setIsWeaving(false);
        weaveStartPos.current = null;
    };

    return (
        <div className="w-full h-full bg-gray-900 flex flex-col items-center justify-center p-4 select-none">
            <h1 className="text-white text-xl mb-2">Weaver's Gambit - Reach the top right platform!</h1>
             <div ref={gameAreaRef} onMouseDown={handleMouseDown} onMouseMove={handleMouseMove} onMouseUp={handleMouseUp} className="relative overflow-hidden bg-gray-800" style={{ width: GAME_WIDTH, height: GAME_HEIGHT }}>
                {platforms.map((p, i) => <div key={i} className={`absolute ${i === 4 ? 'bg-yellow-500' : 'bg-gray-500'}`} style={{ left: p.x, top: p.y, width: p.width, height: p.height }} />)}
                {fields.map((f, i) => <div key={i} className="absolute bg-purple-500/30 border-2 border-dashed border-purple-400" style={{ left: f.x, top: f.y, width: f.width, height: f.height }} />)}
                <div className="absolute bg-cyan-400" style={{ left: player.x, top: player.y, width: PLAYER_SIZE, height: PLAYER_SIZE }} />
                {gameState === 'won' && <div className="absolute inset-0 bg-black/70 flex items-center justify-center text-4xl font-bold text-yellow-400">YOU WIN!</div>}
             </div>
        </div>
    );
};
