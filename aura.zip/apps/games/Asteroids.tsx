import React, { useState, useEffect, useCallback, useRef } from 'react';
import type { AppProps } from '../../types';

const GAME_WIDTH = 600;
const GAME_HEIGHT = 500;

interface Entity { id: number; x: number; y: number; dx: number; dy: number; angle: number; size: number; }
interface Player extends Entity { isThrusting: boolean; }
interface Asteroid extends Entity {}
interface Bullet extends Entity { life: number; }

export const AsteroidsApp: React.FC<AppProps> = () => {
    const [player, setPlayer] = useState<Player>({ id: 0, x: GAME_WIDTH / 2, y: GAME_HEIGHT / 2, dx: 0, dy: 0, angle: 0, size: 20, isThrusting: false });
    const [asteroids, setAsteroids] = useState<Asteroid[]>([]);
    const [bullets, setBullets] = useState<Bullet[]>([]);
    const [score, setScore] = useState(0);
    const [lives, setLives] = useState(3);
    const [gameState, setGameState] = useState<'menu' | 'playing' | 'gameOver'>('menu');
    const keysPressed = useRef<{ [key: string]: boolean }>({});
    const gameLoopRef = useRef<number | null>(null);

    const createAsteroids = (count: number) => {
        const newAsteroids: Asteroid[] = [];
        for (let i = 0; i < count; i++) {
            newAsteroids.push({
                id: Date.now() + i,
                x: Math.random() > 0.5 ? 0 : GAME_WIDTH, 
                y: Math.random() > 0.5 ? 0 : GAME_HEIGHT,
                dx: Math.random() * 2 - 1, dy: Math.random() * 2 - 1,
                angle: 0, size: 50,
            });
        }
        setAsteroids(newAsteroids);
    };

    const resetGame = () => {
        setPlayer({ id: 0, x: GAME_WIDTH / 2, y: GAME_HEIGHT / 2, dx: 0, dy: 0, angle: 0, size: 20, isThrusting: false });
        setBullets([]);
        setAsteroids([]);
        setScore(0);
        setLives(3);
        setGameState('menu');
    };

    const startGame = () => {
        resetGame();
        setLives(3);
        setScore(0);
        createAsteroids(5);
        setGameState('playing');
    };

    const gameTick = useCallback(() => {
        if (gameState !== 'playing') return;

        // --- MOVEMENT ---
        setPlayer(p => {
            let newAngle = p.angle;
            if (keysPressed.current['ArrowLeft']) newAngle -= 5;
            if (keysPressed.current['ArrowRight']) newAngle += 5;

            let newDx = p.dx;
            let newDy = p.dy;
            const isThrusting = !!keysPressed.current['ArrowUp'];
            if (isThrusting) {
                newDx += Math.cos(p.angle * Math.PI / 180) * 0.1;
                newDy += Math.sin(p.angle * Math.PI / 180) * 0.1;
            }
            
            newDx *= 0.99;
            newDy *= 0.99;
            
            let newX = (p.x + newDx + GAME_WIDTH) % GAME_WIDTH;
            let newY = (p.y + newDy + GAME_HEIGHT) % GAME_HEIGHT;
            
            return { ...p, x: newX, y: newY, dx: newDx, dy: newDy, angle: newAngle, isThrusting };
        });

        setBullets(bs => bs.map(b => ({ ...b, x: (b.x + b.dx + GAME_WIDTH) % GAME_WIDTH, y: (b.y + b.dy + GAME_HEIGHT) % GAME_HEIGHT, life: b.life - 1 })).filter(b => b.life > 0));
        setAsteroids(as => as.map(a => ({ ...a, x: (a.x + a.dx + GAME_WIDTH) % GAME_WIDTH, y: (a.y + a.dy + GAME_HEIGHT) % GAME_HEIGHT })));
        
        // --- COLLISIONS ---
        const checkCollision = (o1: Entity, o2: Entity) => {
            const dx = o1.x - o2.x;
            const dy = o1.y - o2.y;
            const distance = Math.sqrt(dx * dx + dy * dy);
            return distance < (o1.size / 2 + o2.size / 2);
        };
        
        setAsteroids(prevAsteroids => {
            let newAsteroids = [...prevAsteroids];
            let playerHit = false;

            // Player-Asteroid Collision
            for (let i = newAsteroids.length - 1; i >= 0; i--) {
                if(checkCollision(player, newAsteroids[i])) {
                    playerHit = true;
                    newAsteroids.splice(i, 1);
                    break;
                }
            }
            if (playerHit) {
                setLives(l => {
                    const newLives = l - 1;
                    if(newLives <= 0) setGameState('gameOver');
                    return newLives;
                });
                setPlayer(p => ({ ...p, x: GAME_WIDTH / 2, y: GAME_HEIGHT / 2, dx: 0, dy: 0 }));
            }

            // Bullet-Asteroid Collision
            setBullets(prevBullets => {
                 let remainingBullets = [...prevBullets];
                 let scoreToAdd = 0;
                 const newlySplitAsteroids: Asteroid[] = [];

                 for (let i = newAsteroids.length - 1; i >= 0; i--) {
                     for (let j = remainingBullets.length - 1; j >= 0; j--) {
                         if(checkCollision(newAsteroids[i], remainingBullets[j])) {
                            scoreToAdd += newAsteroids[i].size === 50 ? 20 : 50;
                             if(newAsteroids[i].size > 20) {
                                 newlySplitAsteroids.push({ ...newAsteroids[i], id: Date.now() + Math.random(), size: newAsteroids[i].size/2, dx: Math.random()*2-1 });
                                 newlySplitAsteroids.push({ ...newAsteroids[i], id: Date.now() + Math.random(), size: newAsteroids[i].size/2, dx: Math.random()*2-1 });
                             }
                             newAsteroids.splice(i, 1);
                             remainingBullets.splice(j, 1);
                             break;
                         }
                     }
                 }
                 
                 if (scoreToAdd > 0) setScore(s => s + scoreToAdd);
                 if(newlySplitAsteroids.length > 0) newAsteroids.push(...newlySplitAsteroids);
                 
                 return remainingBullets.length !== prevBullets.length ? remainingBullets : prevBullets;
            });
            
            return newAsteroids.length !== prevAsteroids.length ? newAsteroids : prevAsteroids;
        });

    }, [gameState, player, lives]);
    
    useEffect(() => {
        if(gameState === 'playing') {
            gameLoopRef.current = requestAnimationFrame(gameTick);
        }
        return () => {
            if (gameLoopRef.current) {
                cancelAnimationFrame(gameLoopRef.current);
            }
        }
    }, [gameState, gameTick]);
    
    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            keysPressed.current[e.key] = true;
            if (e.key === ' ' && gameState === 'playing' && bullets.length < 5) {
                 e.preventDefault();
                 setBullets(bs => [...bs, {
                    id: Date.now(),
                    x: player.x, y: player.y,
                    dx: Math.cos(player.angle * Math.PI / 180) * 5,
                    dy: Math.sin(player.angle * Math.PI / 180) * 5,
                    angle: 0, size: 5, life: 60 // 1 second lifetime
                 }]);
            }
        };
        const handleKeyUp = (e: KeyboardEvent) => { keysPressed.current[e.key] = false; };
        window.addEventListener('keydown', handleKeyDown);
        window.addEventListener('keyup', handleKeyUp);
        return () => {
            window.removeEventListener('keydown', handleKeyDown);
            window.removeEventListener('keyup', handleKeyUp);
        };
    }, [player, bullets, gameState]);


    return (
        <div className="w-full h-full bg-black flex items-center justify-center select-none">
            <div className="relative overflow-hidden bg-gray-900 border-2 border-gray-500" style={{ width: GAME_WIDTH, height: GAME_HEIGHT }}>
                {/* Player Ship */}
                {lives > 0 && <div style={{ transform: `translate(${player.x - player.size / 2}px, ${player.y - player.size / 2}px) rotate(${player.angle}deg)`, width: player.size, height: player.size }} className="absolute">
                    <svg viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2"><path d="M12 2L3 22l9-5 9 5-9-20z"/></svg>
                </div>}
                 {/* Thrust */}
                 {lives > 0 && player.isThrusting && (
                    <div style={{ transform: `translate(${player.x-10}px, ${player.y-5}px) rotate(${player.angle}deg) translate(-10px, 0px)`, width: '10px', height: '10px' }} className="absolute text-yellow-400">🔥</div>
                 )}

                {/* Asteroids */}
                {asteroids.map(a => <div key={a.id} className="absolute border-2 border-white rounded-full" style={{ left: a.x - a.size/2, top: a.y - a.size/2, width: a.size, height: a.size}}/>)}

                {/* Bullets */}
                {bullets.map(b => <div key={b.id} className="absolute bg-white rounded-full" style={{ left: b.x - b.size/2, top: b.y-b.size/2, width: b.size, height: b.size}} />)}

                 {/* UI */}
                <div className="absolute top-4 left-4 text-white font-mono">Score: {score}</div>
                <div className="absolute top-4 right-4 text-white font-mono">Lives: {'▲'.repeat(lives)}</div>
                 {gameState !== 'playing' && (
                     <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center text-center text-white">
                        {gameState === 'menu' && <>
                            <h1 className="text-5xl font-bold">Asteroids</h1>
                            <button onClick={startGame} className="mt-8 px-6 py-3 bg-indigo-500 rounded-lg text-xl">Start Game</button>
                        </>}
                         {gameState === 'gameOver' && <>
                            <h1 className="text-5xl font-bold text-red-500">Game Over</h1>
                             <p className="text-2xl mt-2">Final Score: {score}</p>
                            <button onClick={startGame} className="mt-6 px-6 py-3 bg-blue-500 rounded-lg text-xl">Play Again</button>
                         </>}
                    </div>
                )}
            </div>
        </div>
    );
};