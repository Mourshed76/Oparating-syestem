import React, { useState, useEffect, useCallback, useRef } from 'react';
import type { AppProps } from '../../types';

const BOARD_WIDTH = 40;
const BOARD_HEIGHT = 30;
const TILE_SIZE = 16;

type Tile = { type: 'air' | 'dirt' | 'stone'; };
type Board = Tile[][];
type Position = { x: number; y: number; };

const generateWorld = (): Board => {
    const board: Board = [];
    for (let y = 0; y < BOARD_HEIGHT; y++) {
        const row: Tile[] = [];
        for (let x = 0; x < BOARD_WIDTH; x++) {
            if (y < 5) {
                row.push({ type: 'air' });
            } else if (y < 15) {
                row.push({ type: y > 5 + Math.random() * 5 ? 'stone' : 'dirt' });
            } else {
                 row.push({ type: 'stone' });
            }
        }
        board.push(row);
    }
    // Carve out a starting area
    board[5][Math.floor(BOARD_WIDTH / 2)] = { type: 'air' };
    return board;
};

const TileComponent: React.FC<{ tile: Tile }> = React.memo(({ tile }) => {
    if (tile.type === 'dirt') return <div className="text-yellow-700">#</div>;
    if (tile.type === 'stone') return <div className="text-gray-500">▓</div>;
    return <div> </div>;
});

export const VoidWallowApp: React.FC<AppProps> = () => {
    const [board, setBoard] = useState<Board>(generateWorld);
    const [playerPos, setPlayerPos] = useState<Position>({ x: Math.floor(BOARD_WIDTH / 2), y: 5 });
    const [hunger, setHunger] = useState(100);
    const [gameState, setGameState] = useState<'playing' | 'gameOver'>('playing');
    const [log, setLog] = useState<string[]>(['You awaken in the deep. Survive.']);
    
    const addLog = (message: string) => setLog(prev => [message, ...prev.slice(0, 4)]);

    const movePlayer = useCallback((dx: number, dy: number) => {
        if (gameState !== 'playing') return;

        const newPos = { x: playerPos.x + dx, y: playerPos.y + dy };
        if (newPos.x < 0 || newPos.x >= BOARD_WIDTH || newPos.y < 0 || newPos.y >= BOARD_HEIGHT) return;
        
        const targetTile = board[newPos.y][newPos.x];
        if (targetTile.type === 'air') {
            setPlayerPos(newPos);
        } else {
            addLog(`You dig through the ${targetTile.type}.`);
            const newBoard = board.map(r => [...r]);
            newBoard[newPos.y][newPos.x] = { type: 'air' };
            setBoard(newBoard);
            setPlayerPos(newPos);
        }
    }, [playerPos, board, gameState]);

    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            switch (e.key) {
                case 'ArrowUp': movePlayer(0, -1); break;
                case 'ArrowDown': movePlayer(0, 1); break;
                case 'ArrowLeft': movePlayer(-1, 0); break;
                case 'ArrowRight': movePlayer(1, 0); break;
            }
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [movePlayer]);
    
    useEffect(() => {
        if (gameState !== 'playing') return;
        const hungerInterval = setInterval(() => {
            setHunger(h => {
                if (h <= 1) {
                    setGameState('gameOver');
                    addLog("You have succumbed to the void.");
                    return 0;
                }
                return h - 1;
            });
        }, 1000);
        return () => clearInterval(hungerInterval);
    }, [gameState]);

    return (
        <div className="w-full h-full bg-black text-white font-mono flex select-none p-4 gap-4">
            <main className="flex-grow flex items-center justify-center">
                 <div className="grid relative" style={{ gridTemplateColumns: `repeat(${BOARD_WIDTH}, ${TILE_SIZE}px)`, gridTemplateRows: `repeat(${BOARD_HEIGHT}, ${TILE_SIZE}px)`}}>
                    {board.map((row, y) => row.map((tile, x) => (
                        <div key={`${x}-${y}`} className="flex items-center justify-center"><TileComponent tile={tile} /></div>
                    )))}
                    <div className="absolute text-cyan-400" style={{ left: playerPos.x * TILE_SIZE, top: playerPos.y * TILE_SIZE }}>@</div>
                </div>
            </main>
            <aside className="w-64 bg-gray-900/50 p-4 flex-shrink-0 flex flex-col">
                <h2 className="text-xl font-bold mb-4">Void Wallow</h2>
                <div className="mb-4">
                    <p>STATUS</p>
                    <p className="text-red-500">Hunger: {hunger}/100</p>
                </div>
                <div>
                    <p>LOG</p>
                    {log.map((msg, i) => <p key={i} className="text-gray-400 text-sm">- {msg}</p>)}
                </div>
                {gameState === 'gameOver' && (
                    <div className="mt-auto text-center">
                        <p className="text-2xl font-bold text-red-600">GAME OVER</p>
                    </div>
                )}
            </aside>
        </div>
    );
};
