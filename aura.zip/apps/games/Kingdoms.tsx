import React, { useState, useEffect, useCallback, useReducer, useRef } from 'react';
import type { AppProps, KingdomsAscendancyState, KingdomsResources, PlacedBuilding, GameUnit, ResourceNode, ResourceId } from '../../types';
import { useSettings } from '../../context/SettingsContext';
import { v4 as uuidv4 } from 'uuid';

// --- GAME CONFIGURATION ---
const TILE_SIZE = 24;
const MAP_WIDTH_TILES = 50;
const MAP_HEIGHT_TILES = 50;
const UNIT_SPEED = 50; // pixels per second

const BUILDING_DEFS: Record<string, any> = {
    town_hall: { name: 'Town Hall', size: 3, cost: { wood: 200, stone: 100 }, provides: { maxPopulation: 10 }, maxHealth: 1500, trains: ['villager'] },
    house: { name: 'House', size: 2, cost: { wood: 50 }, provides: { maxPopulation: 5 }, maxHealth: 250 },
    lumber_mill: { name: 'Lumber Mill', size: 2, cost: { wood: 80 }, maxHealth: 400 },
    mine: { name: 'Mine', size: 2, cost: { wood: 100, stone: 20 }, maxHealth: 500 },
    farm: { name: 'Farm', size: 2, cost: { wood: 60 }, maxHealth: 150 },
    barracks: { name: 'Barracks', size: 3, cost: { wood: 150, stone: 50 }, maxHealth: 800, trains: ['swordsman', 'archer'] },
};

const UNIT_DEFS: Record<string, any> = {
    villager: { name: 'Villager', cost: { food: 50 }, time: 10, maxHealth: 50, damage: 5, attackRate: 2, canBuild: true },
    swordsman: { name: 'Swordsman', cost: { food: 60, gold: 20 }, time: 15, maxHealth: 100, damage: 10, attackRate: 1.5 },
    archer: { name: 'Archer', cost: { food: 40, wood: 20 }, time: 12, maxHealth: 70, damage: 8, attackRate: 1.2 },
};

// --- HELPER FUNCTIONS ---
const distance = (x1: number, y1: number, x2: number, y2: number) => Math.hypot(x2 - x1, y2 - y1);
const generateMap = (): { nodes: ResourceNode[], playerStart: {x:number, y:number}, enemyStart: {x:number, y:number} } => {
    const nodes: ResourceNode[] = [];
    const MAP_W = MAP_WIDTH_TILES * TILE_SIZE; const MAP_H = MAP_HEIGHT_TILES * TILE_SIZE;
    for(let i=0; i < 50; i++) nodes.push({ id: uuidv4(), type: 'wood', amount: 250, x: Math.random() * MAP_W, y: Math.random() * MAP_H });
    for(let i=0; i < 20; i++) nodes.push({ id: uuidv4(), type: 'gold', amount: 1000, x: Math.random() * MAP_W, y: Math.random() * MAP_H });
    for(let i=0; i < 30; i++) nodes.push({ id: uuidv4(), type: 'stone', amount: 500, x: Math.random() * MAP_W, y: Math.random() * MAP_H });
    return { nodes, playerStart: { x: 100, y: MAP_H - 150}, enemyStart: {x: MAP_W - 150, y: 100} };
};

// --- UI COMPONENTS ---
const ControlPanel: React.FC<{ selected: any, onCommand: (cmd: string, arg?: any) => void }> = ({ selected, onCommand }) => {
    const def = selected ? (BUILDING_DEFS[selected.type] || UNIT_DEFS[selected.type]) : null;
    return (
        <footer className="h-40 bg-black/50 flex-shrink-0 border-t-2 border-yellow-700/50 flex p-2 z-10">
            <div className="w-1/3 p-2">
                {selected && def && <div>
                    <h3 className="font-bold text-lg">{def.name}</h3>
                    {'health' in selected && <p>Health: {Math.ceil(selected.health)} / {selected.maxHealth}</p>}
                    {'trainingQueue' in selected && selected.trainingQueue.length > 0 && 
                        <p>Training: {UNIT_DEFS[selected.trainingQueue[0].unitType].name} ({Math.round(selected.trainingQueue[0].progress * 100)}%)</p>}
                </div>}
            </div>
            <div className="w-2/3 grid grid-cols-4 gap-2">
                {selected && def?.trains?.map((unitType: string) => (
                    <button key={unitType} onClick={() => onCommand('train_unit', unitType)} className="bg-gray-700 hover:bg-gray-600 rounded flex flex-col items-center justify-center p-1 text-xs">
                        <span className="text-2xl">{UNIT_DEFS[unitType].name[0]}</span>
                        <span>{UNIT_DEFS[unitType].name}</span>
                        <span className="text-yellow-400">F:{UNIT_DEFS[unitType].cost.food}</span>
                    </button>
                ))}
            </div>
        </footer>
    );
};

// --- GAME LOGIC (useReducer) ---
// This is a simplified game loop. A production game would separate logic further.
const gameReducer = (state: KingdomsAscendancyState, action: any): KingdomsAscendancyState => {
    // This reducer would be massive. To keep the file size reasonable while delivering functionality,
    // we'll handle complex logic via helper functions.
    // In a real scenario, this would contain all pure state transitions.
    switch (action.type) {
        case 'SET_INITIAL_STATE': return action.payload;
        case 'UPDATE_STATE': return { ...state, ...action.payload, lastUpdated: Date.now() };
        default: return state;
    }
}


export const KingdomsAscendancyApp: React.FC<AppProps> = () => {
    const { kingdomsState, setKingdomsState } = useSettings();
    const [gameState, dispatch] = useReducer(gameReducer, kingdomsState);
    const [isLoading, setIsLoading] = useState(true);
    const [selectedIds, setSelectedIds] = useState<string[]>([]);
    const gameAreaRef = useRef<HTMLDivElement>(null);

    const initializeGame = useCallback(() => {
        const { nodes, playerStart, enemyStart } = generateMap();
        const initialPlayerTownHall: PlacedBuilding = {
            id: 'player_th', type: 'town_hall', x: playerStart.x, y: playerStart.y, level: 1, owner: 'player', 
            health: BUILDING_DEFS.town_hall.maxHealth, maxHealth: BUILDING_DEFS.town_hall.maxHealth,
            isConstructing: false, constructionProgress: 100, trainingQueue: []
        };
        const initialEnemyTownHall: PlacedBuilding = {
            id: 'enemy_th', type: 'town_hall', x: enemyStart.x, y: enemyStart.y, level: 1, owner: 'enemy',
            health: BUILDING_DEFS.town_hall.maxHealth, maxHealth: BUILDING_DEFS.town_hall.maxHealth,
            isConstructing: false, constructionProgress: 100, trainingQueue: []
        };
        const initialState: KingdomsAscendancyState = {
            resources: { wood: 200, gold: 100, food: 150, stone: 50, population: 0, maxPopulation: 10 },
            enemyResources: { wood: 200, gold: 100, food: 150, stone: 50, population: 0, maxPopulation: 10 },
            buildings: [initialPlayerTownHall, initialEnemyTownHall],
            units: [
                { id: uuidv4(), type: 'villager', owner: 'player', x: playerStart.x + 80, y: playerStart.y + 80, health: 50, maxHealth: 50, task: { type: 'idle' }, resourceAmount: 0, attackCooldown: 0 },
                { id: uuidv4(), type: 'villager', owner: 'player', x: playerStart.x + 90, y: playerStart.y + 90, health: 50, maxHealth: 50, task: { type: 'idle' }, resourceAmount: 0, attackCooldown: 0 },
                 { id: uuidv4(), type: 'villager', owner: 'enemy', x: enemyStart.x + 80, y: enemyStart.y + 80, health: 50, maxHealth: 50, task: { type: 'idle' }, resourceAmount: 0, attackCooldown: 0 },
            ],
            resourceNodes: nodes,
            researchedTechs: [],
            currentAge: 'Stone Age',
            lastUpdated: Date.now(),
            gameSpeed: 1,
            aiState: { attackWaveCooldown: 60, state: 'expanding', scoutTarget: playerStart },
            notifications: [],
        };
        dispatch({ type: 'SET_INITIAL_STATE', payload: initialState });
        setIsLoading(false);
    }, []);

    useEffect(initializeGame, []);
    
    // THE GAME LOOP
    useEffect(() => {
        if (isLoading || gameState.units === undefined) return;
        
        let animationFrameId: number;
        const loop = (timestamp: number) => {
            const deltaTime = Math.min(0.1, (timestamp - gameState.lastUpdated) / 1000) * gameState.gameSpeed;
            if (deltaTime <= 0) {
                animationFrameId = requestAnimationFrame(loop);
                return;
            }

            const newState: KingdomsAscendancyState = JSON.parse(JSON.stringify(gameState));

            // --- UNIT LOGIC ---
            newState.units.forEach(unit => {
                // Task execution
                if (unit.task.type === 'move' && unit.task.targetPosition) {
                    const target = unit.task.targetPosition;
                    const dx = target.x - unit.x;
                    const dy = target.y - unit.y;
                    const dist = Math.hypot(dx, dy);
                    if (dist < 5) {
                        unit.task = { type: 'idle' };
                    } else {
                        unit.x += (dx / dist) * UNIT_SPEED * deltaTime;
                        unit.y += (dy / dist) * UNIT_SPEED * deltaTime;
                    }
                }
                // ... More tasks like gather, attack, build would go here
            });
            
            // --- BUILDING LOGIC ---
            newState.buildings.forEach(b => {
                if (b.trainingQueue.length > 0) {
                    const item = b.trainingQueue[0];
                    const def = UNIT_DEFS[item.unitType];
                    item.progress += deltaTime / def.time;
                    if(item.progress >= 1) {
                         const newUnit: GameUnit = {
                            id: uuidv4(), type: item.unitType as any, owner: b.owner,
                            x: b.x + (BUILDING_DEFS[b.type].size * TILE_SIZE), y: b.y + (BUILDING_DEFS[b.type].size * TILE_SIZE),
                            health: def.maxHealth, maxHealth: def.maxHealth, task: { type: 'idle' }, resourceAmount: 0, attackCooldown: 0
                        };
                        newState.units.push(newUnit);
                        b.trainingQueue.shift();
                    }
                }
            });

            // --- AI LOGIC ---
            const enemyUnits = newState.units.filter(u => u.owner === 'enemy');
            const enemyTH = newState.buildings.find(b => b.owner === 'enemy' && b.type === 'town_hall');
            if(enemyTH && enemyUnits.filter(u => u.type === 'villager').length < 5) {
                if (newState.enemyResources.food >= 50 && enemyTH.trainingQueue.length === 0) {
                     enemyTH.trainingQueue.push({unitType: 'villager', progress: 0, id: uuidv4()});
                     newState.enemyResources.food -= 50;
                }
            }
            // Simple AI: idle villagers gather wood
            enemyUnits.forEach(u => {
                if(u.type === 'villager' && u.task.type === 'idle') {
                     const closestTree = newState.resourceNodes.filter(n => n.type === 'wood').sort((a,b) => distance(u.x, u.y, a.x, a.y) - distance(u.x, u.y, b.x, b.y))[0];
                     if(closestTree) u.task = { type: 'move', targetPosition: {x: closestTree.x, y: closestTree.y }};
                }
            });
            

            dispatch({ type: 'UPDATE_STATE', payload: newState });
            animationFrameId = requestAnimationFrame(loop);
        };
        animationFrameId = requestAnimationFrame(loop);
        return () => cancelAnimationFrame(animationFrameId);
    }, [isLoading, gameState.gameSpeed]); // Note: gameState dependency removed to avoid re-triggering loop
    
    const handleCommand = (cmd: string, arg?: any) => {
        const newState = JSON.parse(JSON.stringify(gameState));
        if (cmd === 'train_unit') {
            const selectedBuilding = newState.buildings.find((b: PlacedBuilding) => b.id === selectedIds[0]);
            if(selectedBuilding && selectedBuilding.owner === 'player') {
                const def = UNIT_DEFS[arg];
                if(newState.resources.food >= def.cost.food && newState.resources.population < newState.resources.maxPopulation) {
                    newState.resources.food -= def.cost.food;
                    newState.resources.population++;
                    selectedBuilding.trainingQueue.push({unitType: arg, progress: 0, id: uuidv4()});
                }
            }
        }
         dispatch({ type: 'UPDATE_STATE', payload: newState });
    };

    const handleRightClick = (e: React.MouseEvent) => {
        e.preventDefault();
        const rect = gameAreaRef.current?.getBoundingClientRect();
        if(!rect) return;
        const targetPos = { x: e.clientX - rect.left, y: e.clientY - rect.top };
        
        const newState = JSON.parse(JSON.stringify(gameState));
        newState.units.forEach((u: GameUnit) => {
            if(selectedIds.includes(u.id)) {
                u.task = { type: 'move', targetPosition: targetPos };
            }
        });
        dispatch({type: 'UPDATE_STATE', payload: newState});
    };

    if (isLoading || gameState.units === undefined) return <div className="w-full h-full bg-gray-900 flex items-center justify-center text-white">Generating Kingdom...</div>;
    const selectedEntity = gameState.buildings.find(b => b.id === selectedIds[0]) || gameState.units.find(u => u.id === selectedIds[0]);
    
    return (
        <div className="w-full h-full bg-gray-800 text-white flex flex-col font-mono select-none overflow-hidden">
            {/* Top Resource Bar */}
            <header className="flex-shrink-0 bg-black/30 p-2 flex justify-between items-center gap-4 text-xs md:text-sm z-10">
                <div className="flex items-center gap-4">
                    {Object.entries(gameState.resources).map(([key, value]) => (
                        <span key={key}>{key.charAt(0).toUpperCase()}: {Math.floor(value as number)}</span>
                    ))}
                </div>
                <button onClick={initializeGame} className="px-3 py-1 bg-gray-600 hover:bg-gray-500 rounded text-xs font-bold">
                    Restart Game
                </button>
            </header>
            
            {/* Game World */}
            <div ref={gameAreaRef} onContextMenu={handleRightClick}
                className="flex-grow relative bg-green-800 cursor-pointer overflow-auto">
                <div className="absolute bg-green-700" style={{ width: MAP_WIDTH_TILES * TILE_SIZE, height: MAP_HEIGHT_TILES * TILE_SIZE }}>
                    {/* Resource Nodes */}
                    {gameState.resourceNodes.map(node => (
                        <div key={node.id} className="absolute text-xl" style={{left: node.x, top: node.y}}>
                            {node.type === 'wood' && '🌳'}
                            {node.type === 'gold' && '💰'}
                            {node.type === 'stone' && '🪨'}
                        </div>
                    ))}
                    {/* Buildings */}
                    {gameState.buildings.map(b => {
                        const def = BUILDING_DEFS[b.type];
                        const size = def.size * TILE_SIZE;
                        const borderColor = b.owner === 'player' ? 'border-blue-500' : 'border-red-500';
                        return <div key={b.id} onClick={() => setSelectedIds([b.id])}
                            className={`absolute flex items-center justify-center text-4xl border-2 ${selectedIds.includes(b.id) ? 'border-yellow-400' : borderColor}`}
                            style={{ left: b.x, top: b.y, width: size, height: size, background: 'rgba(0,0,0,0.4)' }}>
                                {def.name[0]}
                            </div>
                    })}
                    {/* Units */}
                    {gameState.units.map(u => (
                        <div key={u.id} onClick={() => setSelectedIds([u.id])}
                            className="absolute flex items-center justify-center"
                            style={{ left: u.x - 10, top: u.y - 10, width: 20, height: 20 }}>
                            <div className={`w-4 h-4 rounded-full ${u.owner === 'player' ? 'bg-blue-500' : 'bg-red-500'}`}/>
                            {selectedIds.includes(u.id) && <div className="absolute -bottom-1 w-4 h-1 bg-yellow-400 rounded-full"/>}
                        </div>
                    ))}
                </div>
            </div>
            
            {/* Control Panel */}
            <ControlPanel selected={selectedEntity} onCommand={handleCommand} />
        </div>
    );
};