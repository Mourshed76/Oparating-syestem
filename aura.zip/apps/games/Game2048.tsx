import React, { useState, useEffect, useCallback } from 'react';
import type { AppProps } from '../../types';

type Board = (number | null)[][];
type Direction = 'UP' | 'DOWN' | 'LEFT' | 'RIGHT';

const BOARD_SIZE = 4;

const TILE_COLORS: { [key: number]: string } = {
  2: 'bg-gray-200 text-gray-800', 4: 'bg-yellow-200 text-gray-800', 8: 'bg-orange-400 text-white',
  16: 'bg-orange-500 text-white', 32: 'bg-red-500 text-white', 64: 'bg-red-600 text-white',
  128: 'bg-yellow-400 text-white', 256: 'bg-yellow-500 text-white', 512: 'bg-yellow-600 text-white',
  1024: 'bg-purple-500 text-white', 2048: 'bg-purple-700 text-white', 4096: 'bg-indigo-700 text-white',
};

const getInitialBoard = (): Board => {
  const board = Array.from({ length: BOARD_SIZE }, () => Array(BOARD_SIZE).fill(null));
  addRandomTile(board);
  addRandomTile(board);
  return board;
};

const addRandomTile = (board: Board): boolean => {
  const emptyCells: { r: number; c: number }[] = [];
  for (let r = 0; r < BOARD_SIZE; r++) {
    for (let c = 0; c < BOARD_SIZE; c++) {
      if (board[r][c] === null) emptyCells.push({ r, c });
    }
  }
  if (emptyCells.length === 0) return false;
  const { r, c } = emptyCells[Math.floor(Math.random() * emptyCells.length)];
  board[r][c] = Math.random() < 0.9 ? 2 : 4;
  return true;
};

// Helper functions for board transformations
const slide = (row: (number | null)[]): (number | null)[] => {
  const arr = row.filter(val => val);
  const missing = row.length - arr.length;
  const zeros = Array(missing).fill(null);
  return arr.concat(zeros);
};

const combine = (row: (number | null)[]): { newRow: (number | null)[], score: number } => {
  let score = 0;
  for (let i = 0; i < row.length - 1; i++) {
    if (row[i] !== null && row[i] === row[i + 1]) {
      row[i] *= 2;
      score += row[i]!;
      row[i + 1] = null;
    }
  }
  return { newRow: row, score };
};

const rotateRight = (board: Board): Board => {
  const newBoard = Array.from({ length: BOARD_SIZE }, () => Array(BOARD_SIZE).fill(null));
  for (let r = 0; r < BOARD_SIZE; r++) {
    for (let c = 0; c < BOARD_SIZE; c++) {
      newBoard[c][BOARD_SIZE - 1 - r] = board[r][c];
    }
  }
  return newBoard;
};

export const Game2048App: React.FC<AppProps> = () => {
    const [board, setBoard] = useState<Board>(() => getInitialBoard());
    const [score, setScore] = useState(0);
    const [gameOver, setGameOver] = useState(false);

    const move = useCallback((dir: Direction) => {
        let currentBoard = JSON.parse(JSON.stringify(board));
        let tempScore = 0;
        let rotations = 0;

        if (dir === 'UP') { rotations = 1; }
        else if (dir === 'RIGHT') { rotations = 2; }
        else if (dir === 'DOWN') { rotations = 3; }

        for (let i = 0; i < rotations; i++) {
            currentBoard = rotateRight(currentBoard);
        }

        for (let r = 0; r < BOARD_SIZE; r++) {
            let row = currentBoard[r];
            row = slide(row);
            const result = combine(row);
            row = result.newRow;
            tempScore += result.score;
            row = slide(row);
            currentBoard[r] = row;
        }

        for (let i = 0; i < rotations; i++) {
            currentBoard = rotateRight(rotateRight(rotateRight(currentBoard))); // Rotate left
        }
        
        const changed = JSON.stringify(board) !== JSON.stringify(currentBoard);

        if (changed) {
            addRandomTile(currentBoard);
            setBoard(currentBoard);
            setScore(s => s + tempScore);
        }
    }, [board]);
    
    const isGameOver = () => {
        for (let r = 0; r < BOARD_SIZE; r++) {
            for (let c = 0; c < BOARD_SIZE; c++) {
                if (board[r][c] === null) return false; // empty cell
                if (r < BOARD_SIZE - 1 && board[r][c] === board[r+1][c]) return false; // can move down
                if (c < BOARD_SIZE - 1 && board[r][c] === board[r][c+1]) return false; // can move right
            }
        }
        return true;
    }

    useEffect(() => {
      const handleKeyDown = (e: KeyboardEvent) => {
        if (gameOver) return;
        switch (e.key) {
          case 'ArrowUp': move('UP'); break;
          case 'ArrowDown': move('DOWN'); break;
          case 'ArrowLeft': move('LEFT'); break;
          case 'ArrowRight': move('RIGHT'); break;
        }
      };
      window.addEventListener('keydown', handleKeyDown);
      return () => window.removeEventListener('keydown', handleKeyDown);
    }, [move, gameOver]);

    useEffect(() => {
        if(isGameOver()) setGameOver(true);
    }, [board]);
    
    const restartGame = () => {
        setBoard(getInitialBoard());
        setScore(0);
        setGameOver(false);
    }
    
    return (
        <div className="w-full h-full bg-[#faf8ef] flex flex-col items-center justify-center p-4 select-none">
             <header className="w-full max-w-sm flex justify-between items-center mb-4">
                <h1 className="text-4xl font-bold text-[#776e65]">2048</h1>
                <div className="flex gap-2">
                    <div className="bg-[#bbada0] p-2 rounded text-white text-center"><div className="text-xs font-bold">SCORE</div><div className="text-xl font-bold">{score}</div></div>
                    <button onClick={restartGame} className="bg-[#8f7a66] p-3 rounded text-white font-bold hover:bg-[#9f8b77]">New Game</button>
                </div>
            </header>
            <main className="bg-[#bbada0] p-3 rounded-lg relative">
                <div className="grid grid-cols-4 gap-3">
                    {board.flat().map((_, i) => (
                         <div key={i} className="w-20 h-20 md:w-24 md:h-24 bg-[rgba(238,228,218,0.35)] rounded-md"></div>
                    ))}
                </div>
                 <div className="absolute inset-3 grid grid-cols-4 gap-3">
                    {board.map((row, r) => row.map((value, c) => (
                        <div key={`${r}-${c}`} className={`w-20 h-20 md:w-24 md:h-24 rounded-md flex items-center justify-center text-3xl md:text-5xl font-bold transition-all duration-300 ${TILE_COLORS[value!] || ''}`}>
                            {value}
                        </div>
                    )))}
                 </div>
                 {gameOver && (
                     <div className="absolute inset-0 bg-white/70 flex flex-col items-center justify-center text-center">
                         <h2 className="text-5xl font-bold text-[#776e65]">Game Over!</h2>
                         <button onClick={restartGame} className="mt-4 bg-[#8f7a66] p-3 rounded text-white font-bold hover:bg-[#9f8b77]">Try Again</button>
                     </div>
                 )}
            </main>
        </div>
    );
};
