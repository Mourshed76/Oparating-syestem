import React, { useState } from 'react';
import type { AppProps } from '../../types';

interface Card {
    id: number;
    name: string;
    attack: number;
    defense: number;
    description: string;
    icon: string;
}

const createRandomCard = (id: number): Card => {
    const names = ['Goblin', 'Knight', 'Dragon', 'Mage', 'Elf Archer'];
    const icons = ['👺', '🐴', '🐲', '🧙', '🧝'];
    const name = names[Math.floor(Math.random() * names.length)];
    return {
        id, name,
        attack: Math.floor(Math.random() * 8) + 1,
        defense: Math.floor(Math.random() * 8) + 1,
        description: 'A powerful creature of Aura.',
        icon: icons[names.indexOf(name)]
    };
};

const CardComponent: React.FC<{ card: Card, onClick?: () => void, isBoardCard?: boolean }> = ({ card, onClick, isBoardCard = false }) => (
    <div onClick={onClick} className={`w-32 h-44 bg-gray-700 border-2 border-gray-500 rounded-lg p-2 flex flex-col justify-between text-white cursor-pointer hover:border-yellow-400 hover:-translate-y-2 transition-all ${isBoardCard ? 'hover:transform-none' : ''}`}>
        <div className="text-center">
            <p className="font-bold text-sm truncate">{card.name}</p>
        </div>
        <div className="text-4xl text-center my-2">{card.icon}</div>
        <div className="flex justify-between text-sm font-mono">
            <span className="text-red-400">{card.attack}</span>
            <span className="text-blue-400">{card.defense}</span>
        </div>
    </div>
);

export const AuraCardsApp: React.FC<AppProps> = () => {
    const [hand, setHand] = useState<Card[]>(() => Array.from({ length: 5 }, (_, i) => createRandomCard(i)));
    const [playerBoard, setPlayerBoard] = useState<(Card | null)[]>(Array(5).fill(null));
    const [opponentBoard, setOpponentBoard] = useState<(Card | null)[]>(() => [createRandomCard(10), createRandomCard(11), null, null, null]);

    const playCard = (card: Card, index: number) => {
        const emptySlotIndex = playerBoard.findIndex(slot => slot === null);
        if (emptySlotIndex !== -1) {
            const newBoard = [...playerBoard];
            newBoard[emptySlotIndex] = card;
            setPlayerBoard(newBoard);
            setHand(h => h.filter(c => c.id !== card.id));
        }
    };
    
    return (
        <div className="w-full h-full bg-cover bg-center flex flex-col p-4" style={{backgroundImage: 'url(https://picsum.photos/seed/cards_bg/1200/800)'}}>
            <div className="w-full bg-black/50 backdrop-blur-sm rounded-lg p-2 flex flex-col flex-grow">
                {/* Opponent Side */}
                <div className="h-1/3 flex items-center justify-center gap-4">
                    {opponentBoard.map((card, index) => card ? <CardComponent key={card.id} card={card} isBoardCard/> : <div key={index} className="w-32 h-44 bg-black/30 rounded-lg"/>)}
                </div>

                {/* Player Side */}
                <div className="h-1/3 border-y-2 border-yellow-400/50 my-4 flex items-center justify-center gap-4">
                    {playerBoard.map((card, index) => card ? <CardComponent key={card.id} card={card} isBoardCard/> : <div key={index} className="w-32 h-44 bg-black/30 rounded-lg"/>)}
                </div>

                {/* Hand */}
                <div className="h-1/3 flex items-center justify-center gap-2">
                    {hand.map((card, index) => <CardComponent key={card.id} card={card} onClick={() => playCard(card, index)} />)}
                </div>
            </div>
        </div>
    );
};
