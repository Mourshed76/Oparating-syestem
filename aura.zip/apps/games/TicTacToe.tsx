import React, { useState, useEffect } from 'react';
import type { AppProps } from '../../types';
import { useSettings } from '../../context/SettingsContext';

type Player = 'X' | 'O';
type Square = Player | null;

const calculateWinner = (squares: Square[]): Player | null => {
    const lines = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8],
        [0, 3, 6], [1, 4, 7], [2, 5, 8],
        [0, 4, 8], [2, 4, 6],
    ];
    for (let i = 0; i < lines.length; i++) {
        const [a, b, c] = lines[i];
        if (squares[a] && squares[a] === squares[b] && squares[a] === squares[c]) {
            return squares[a];
        }
    }
    return null;
};

export const TicTacToeApp: React.FC<AppProps> = () => {
    const { addCoins } = useSettings();
    const [board, setBoard] = useState<Square[]>(Array(9).fill(null));
    const [isXNext, setIsXNext] = useState(true);
    const [status, setStatus] = useState("Your turn (X)");
    const winner = calculateWinner(board);
    const isDraw = !winner && board.every(Boolean);

    const handleClick = (i: number) => {
        if (winner || board[i]) return;
        const newBoard = [...board];
        newBoard[i] = 'X';
        setBoard(newBoard);
        setIsXNext(false);
    };
    
    // AI move
    useEffect(() => {
        if (!isXNext && !winner && !isDraw) {
            const emptySquares = board.map((sq, idx) => sq === null ? idx : null).filter(val => val !== null) as number[];
            const randomIndex = Math.floor(Math.random() * emptySquares.length);
            const aiMove = emptySquares[randomIndex];
            
            setTimeout(() => {
                const newBoard = [...board];
                newBoard[aiMove] = 'O';
                setBoard(newBoard);
                setIsXNext(true);
            }, 500);
        }
    }, [isXNext, board, winner, isDraw]);

    useEffect(() => {
        if (winner) {
            setStatus(`Winner: ${winner}`);
            if(winner === 'X') addCoins(5);
        } else if (isDraw) {
            setStatus("It's a draw!");
            addCoins(1);
        } else {
            setStatus(`Next player: ${isXNext ? 'X' : 'O'}`);
        }
    }, [winner, isDraw, isXNext, addCoins]);

    const resetGame = () => {
        setBoard(Array(9).fill(null));
        setIsXNext(true);
    };

    const SquareComponent: React.FC<{ value: Square, onClick: () => void }> = ({ value, onClick }) => (
        <button
            onClick={onClick}
            className="w-24 h-24 bg-gray-700 border border-gray-500 text-5xl font-bold flex items-center justify-center
                       hover:bg-gray-600 disabled:cursor-not-allowed"
            disabled={!!value || !!winner}
        >
            {value === 'X' && <span className="text-cyan-400">X</span>}
            {value === 'O' && <span className="text-yellow-400">O</span>}
        </button>
    );

    return (
        <div className="w-full h-full bg-gray-800 text-white flex flex-col items-center justify-center p-4">
            <h1 className="text-3xl font-bold mb-4">Tic-Tac-Toe</h1>
            <div className="grid grid-cols-3">
                {board.map((_, i) => (
                    <SquareComponent key={i} value={board[i]} onClick={() => handleClick(i)} />
                ))}
            </div>
            <p className="mt-4 text-xl">{status}</p>
            {(winner || isDraw) && (
                <button onClick={resetGame} className="mt-4 px-4 py-2 bg-blue-500 rounded-lg hover:bg-blue-600">
                    Play Again
                </button>
            )}
        </div>
    );
};
