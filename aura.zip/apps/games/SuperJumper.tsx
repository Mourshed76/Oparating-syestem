import React, { useState, useEffect, useCallback, useRef } from 'react';
import type { AppProps } from '../../types';

const GAME_WIDTH = 400;
const GAME_HEIGHT = 600;
const PLAYER_WIDTH = 40;
const PLAYER_HEIGHT = 40;
const GRAVITY = 0.3;
const JUMP_FORCE = -10;
const PLATFORM_HEIGHT = 15;
const PLATFORM_WIDTH = 80;

interface Platform { id: number; x: number; y: number; }

export const SuperJumperApp: React.FC<AppProps> = () => {
    const [player, setPlayer] = useState({ x: GAME_WIDTH / 2 - 20, y: GAME_HEIGHT - 50, dy: 0 });
    const [platforms, setPlatforms] = useState<Platform[]>([]);
    const [score, setScore] = useState(0);
    const [gameState, setGameState] = useState<'menu' | 'playing' | 'gameOver'>('menu');
    
    const gameLoopRef = useRef<number | null>(null);
    const keysPressed = useRef<{ [key: string]: boolean }>({});

    const resetGame = () => {
        setPlayer({ x: GAME_WIDTH / 2 - 20, y: GAME_HEIGHT - 50, dy: 0 });
        setPlatforms([
            { id: 0, x: GAME_WIDTH / 2 - 40, y: GAME_HEIGHT - 20 },
            { id: 1, x: 200, y: 500 }, { id: 2, x: 100, y: 400 },
            { id: 3, x: 250, y: 300 }, { id: 4, x: 50, y: 200 }
        ]);
        setScore(0);
        setGameState('menu');
    };

    useEffect(resetGame, []);

    const gameLoop = useCallback(() => {
        // Player movement
        let newPlayerX = player.x;
        if (keysPressed.current['ArrowLeft']) newPlayerX -= 4;
        if (keysPressed.current['ArrowRight']) newPlayerX += 4;
        newPlayerX = (newPlayerX + GAME_WIDTH) % GAME_WIDTH; // Wrap around

        // Player gravity
        let newPlayerDy = player.dy + GRAVITY;
        let newPlayerY = player.y + newPlayerDy;

        // Platform collision (only when moving down)
        if (newPlayerDy > 0) {
            for (const p of platforms) {
                if (newPlayerX < p.x + PLATFORM_WIDTH && newPlayerX + PLAYER_WIDTH > p.x &&
                    player.y + PLAYER_HEIGHT <= p.y && newPlayerY + PLAYER_HEIGHT >= p.y) {
                    newPlayerDy = JUMP_FORCE;
                }
            }
        }
        
        // Game over
        if (newPlayerY > GAME_HEIGHT) {
            setGameState('gameOver');
            return;
        }

        // Camera scroll and new platforms
        let newPlatforms = [...platforms];
        let scoreToAdd = 0;
        if (newPlayerY < GAME_HEIGHT / 2) {
             scoreToAdd = Math.floor(GAME_HEIGHT / 2 - newPlayerY);
             newPlayerY = GAME_HEIGHT / 2;
             newPlatforms = platforms.map(p => ({ ...p, y: p.y + scoreToAdd })).filter(p => p.y < GAME_HEIGHT);
             
             const highestPlatform = newPlatforms.reduce((min, p) => p.y < min ? p.y : min, GAME_HEIGHT);
             if (highestPlatform > 100) {
                newPlatforms.push({ id: Date.now(), x: Math.random() * (GAME_WIDTH - PLATFORM_WIDTH), y: Math.random() * 50 });
             }
        }
        
        setScore(s => s + scoreToAdd);
        setPlatforms(newPlatforms);
        setPlayer({ x: newPlayerX, y: newPlayerY, dy: newPlayerDy });

        gameLoopRef.current = requestAnimationFrame(gameLoop);
    }, [player, platforms]);

    useEffect(() => {
        if (gameState === 'playing') gameLoopRef.current = requestAnimationFrame(gameLoop);
        return () => { if (gameLoopRef.current) cancelAnimationFrame(gameLoopRef.current); };
    }, [gameState, gameLoop]);

    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => { keysPressed.current[e.key] = true; };
        const handleKeyUp = (e: KeyboardEvent) => { keysPressed.current[e.key] = false; };
        window.addEventListener('keydown', handleKeyDown);
        window.addEventListener('keyup', handleKeyUp);
        return () => {
            window.removeEventListener('keydown', handleKeyDown);
            window.removeEventListener('keyup', handleKeyUp);
        };
    }, []);

    return (
        <div className="w-full h-full bg-blue-200 flex items-center justify-center select-none">
            <div className="relative overflow-hidden bg-blue-100" style={{ width: GAME_WIDTH, height: GAME_HEIGHT, backgroundImage: 'linear-gradient(to bottom, #a1c4fd, #c2e9fb)' }}>
                {platforms.map(p => <div key={p.id} className="absolute bg-green-500 border-2 border-green-700 rounded-md" style={{ left: p.x, top: p.y, width: PLATFORM_WIDTH, height: PLATFORM_HEIGHT }} />)}
                <div className="absolute bg-red-500 rounded-md" style={{ left: player.x, top: player.y, width: PLAYER_WIDTH, height: PLAYER_HEIGHT }}></div>
                
                <div className="absolute top-4 left-4 text-xl font-bold">Score: {score}</div>

                 {gameState !== 'playing' && (
                     <div className="absolute inset-0 bg-black/50 flex flex-col items-center justify-center text-white text-center">
                        {gameState === 'menu' && (
                            <>
                                <h1 className="text-4xl font-bold">Super Jumper</h1>
                                <button onClick={() => setGameState('playing')} className="mt-6 p-4 bg-green-500 rounded-lg text-lg">Start Game</button>
                            </>
                        )}
                        {gameState === 'gameOver' && (
                             <>
                                <h1 className="text-4xl font-bold">Game Over</h1>
                                <p className="text-2xl mt-2">Score: {score}</p>
                                <button onClick={resetGame} className="mt-6 p-4 bg-blue-500 rounded-lg text-lg">Play Again</button>
                            </>
                        )}
                    </div>
                 )}
            </div>
        </div>
    );
};
