import React, { useState, useEffect, useCallback } from 'react';
import type { AppProps } from '../../types';

const WORD_LIST = ['REACT', 'AURA', 'APPLE', 'FRAME', 'AGENT', 'QUERY', 'STYLE', 'BUILD', 'CLOUD', 'DRIVE'];
const getSolution = () => WORD_LIST[Math.floor(Math.random() * WORD_LIST.length)];

type GameState = 'playing' | 'won' | 'lost';
type KeyState = 'correct' | 'present' | 'absent' | 'default';

const KEYBOARD_LAYOUT = [
  ['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P'],
  ['A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L'],
  ['ENTER', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', '«'],
];

export const WordleApp: React.FC<AppProps> = () => {
  const [solution, setSolution] = useState(getSolution());
  const [guesses, setGuesses] = useState<string[]>(Array(6).fill(''));
  const [currentGuessIndex, setCurrentGuessIndex] = useState(0);
  const [gameState, setGameState] = useState<GameState>('playing');
  const [message, setMessage] = useState('');
  const [keyStates, setKeyStates] = useState<Record<string, KeyState>>({});

  const handleKeyPress = useCallback((key: string) => {
    if (gameState !== 'playing') return;

    if (key === 'ENTER') {
      if (guesses[currentGuessIndex].length !== 5) {
        setMessage('Not enough letters');
        setTimeout(() => setMessage(''), 2000);
        return;
      }
      
      const newGuesses = [...guesses];
      const guess = newGuesses[currentGuessIndex];

      // Update key states
      const newKeyStates = { ...keyStates };
      for (let i = 0; i < guess.length; i++) {
          const char = guess[i];
          if (solution[i] === char) {
              newKeyStates[char] = 'correct';
          } else if (solution.includes(char)) {
              newKeyStates[char] = newKeyStates[char] !== 'correct' ? 'present' : 'correct';
          } else {
              newKeyStates[char] = 'absent';
          }
      }
      setKeyStates(newKeyStates);
      
      if (guess === solution) {
        setGameState('won');
        setMessage('You won!');
      } else if (currentGuessIndex === 5) {
        setGameState('lost');
        setMessage(`You lost! The word was ${solution}`);
      }
      setCurrentGuessIndex(prev => prev + 1);

    } else if (key === '«' || key === 'Backspace') {
      const newGuesses = [...guesses];
      newGuesses[currentGuessIndex] = newGuesses[currentGuessIndex].slice(0, -1);
      setGuesses(newGuesses);
    } else if (guesses[currentGuessIndex].length < 5 && /^[A-Z]$/.test(key)) {
      const newGuesses = [...guesses];
      newGuesses[currentGuessIndex] += key;
      setGuesses(newGuesses);
    }
  }, [guesses, currentGuessIndex, gameState, solution, keyStates]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => handleKeyPress(e.key.toUpperCase());
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyPress]);
  
  const startNewGame = () => {
    setSolution(getSolution());
    setGuesses(Array(6).fill(''));
    setCurrentGuessIndex(0);
    setGameState('playing');
    setMessage('');
    setKeyStates({});
  };

  const getTileClass = (char: string, index: number, guessIndex: number): string => {
    if (guessIndex >= currentGuessIndex || !char) return 'border-gray-400';
    if (solution[index] === char) return 'bg-green-500 text-white border-green-500';
    if (solution.includes(char)) return 'bg-yellow-500 text-white border-yellow-500';
    return 'bg-gray-500 text-white border-gray-500';
  };

  const getKeyClass = (key: string): string => {
      switch (keyStates[key]) {
          case 'correct': return 'bg-green-500 text-white';
          case 'present': return 'bg-yellow-500 text-white';
          case 'absent': return 'bg-gray-700 text-white';
          default: return 'bg-gray-300 hover:bg-gray-400';
      }
  };

  return (
    <div className="w-full h-full bg-gray-900 text-white flex flex-col items-center justify-between p-4 select-none">
      <header className="flex justify-between items-center w-full max-w-sm">
          <h1 className="text-3xl font-bold tracking-wider">WORDLE</h1>
          <button onClick={startNewGame} className="text-2xl">🔄</button>
      </header>

      <main className="flex flex-col gap-1.5 my-4">
        {guesses.map((guess, guessIndex) => (
          <div key={guessIndex} className="grid grid-cols-5 gap-1.5">
            {Array.from({ length: 5 }).map((_, charIndex) => {
              const char = guess[charIndex] || '';
              return (
                <div key={charIndex} className={`w-14 h-14 border-2 flex items-center justify-center text-3xl font-bold uppercase transition-all duration-500 ${getTileClass(char, charIndex, guessIndex)}`}>
                  {char}
                </div>
              );
            })}
          </div>
        ))}
      </main>
      
      <div className="h-10 text-center font-bold">{message}</div>

      <footer className="w-full max-w-lg">
        {KEYBOARD_LAYOUT.map((row, rowIndex) => (
          <div key={rowIndex} className="flex justify-center gap-1.5 mb-1.5">
            {row.map(key => (
              <button
                key={key}
                onClick={() => handleKeyPress(key)}
                className={`h-12 rounded font-bold uppercase flex-grow transition-colors ${getKeyClass(key)} ${key.length > 1 ? 'px-3 text-xs' : 'px-4'}`}
              >
                {key === '«' ? 'DEL' : key}
              </button>
            ))}
          </div>
        ))}
      </footer>
    </div>
  );
};
