import React, { useState, useMemo, useEffect } from 'react';
import type { AppProps } from '../../types';
import { Chess } from 'chess.js';
import { Chessboard } from 'react-chessboard';
import { useSettings } from '../../context/SettingsContext';

export const ChessApp: React.FC<AppProps> = () => {
    const { addCoins } = useSettings();
    const [game, setGame] = useState(new Chess());
    const [fen, setFen] = useState(game.fen());
    const [status, setStatus] = useState('');
    const [gameOver, setGameOver] = useState(false);

    const makeRandomMove = () => {
        const possibleMoves = game.moves();
        if (game.isGameOver() || game.isDraw() || possibleMoves.length === 0) {
            updateStatus();
            return;
        }
        const randomIndex = Math.floor(Math.random() * possibleMoves.length);
        game.move(possibleMoves[randomIndex]);
        setFen(game.fen());
        updateStatus();
    };
    
    const onDrop = (sourceSquare: string, targetSquare: string) => {
        const gameCopy = new Chess(game.fen());
        try {
            const move = gameCopy.move({
                from: sourceSquare,
                to: targetSquare,
                promotion: 'q', // auto-promote to queen
            });
            
            if(move === null) return;

            setGame(gameCopy);
            setFen(gameCopy.fen());

            if (!gameCopy.isGameOver()) {
                setTimeout(makeRandomMove, 500);
            } else {
                updateStatus();
            }
        } catch (error) {
            return;
        }
    };
    
    const updateStatus = () => {
        let newStatus = '';
        const turn = game.turn() === 'w' ? 'White' : 'Black';

        if (game.isCheckmate()) {
            newStatus = `Checkmate! ${turn === 'White' ? 'Black' : 'White'} wins.`;
            addCoins(50);
            setGameOver(true);
        } else if (game.isDraw()) {
            newStatus = 'Draw!';
            addCoins(10);
            setGameOver(true);
        } else {
            newStatus = `${turn}'s turn.`;
            if (game.inCheck()) {
                newStatus += ' In check!';
            }
        }
        setStatus(newStatus);
    };

    const resetGame = () => {
        const newGame = new Chess();
        setGame(newGame);
        setFen(newGame.fen());
        setStatus("White's turn.");
        setGameOver(false);
    };

    useEffect(() => {
        updateStatus();
    }, [fen]);


    return (
        <div className="w-full h-full bg-gray-200 flex flex-col items-center justify-center p-4">
            <div className="w-full max-w-[400px]">
                <Chessboard onDrop={onDrop as any} boardWidth={380} position={fen} />
            </div>
            <div className="mt-4 text-center">
                <p className="text-lg font-semibold">{status}</p>
                {gameOver && (
                     <button onClick={resetGame} className="mt-2 px-4 py-2 bg-blue-500 text-white font-semibold rounded-lg hover:bg-blue-600">
                        Play Again
                    </button>
                )}
            </div>
        </div>
    );
};