import React, { useState, useEffect } from 'react';
import type { AppProps } from '../../types';

type Suit = 'H' | 'D' | 'C' | 'S';
type Rank = 'A' | '2' | '3' | '4' | '5' | '6' | '7' | '8' | '9' | '10' | 'J' | 'Q' | 'K';

interface Card {
  rank: Rank;
  suit: Suit;
  isFaceUp: boolean;
}

const SUITS: Suit[] = ['H', 'D', 'C', 'S'];
const RANKS: Rank[] = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];

const createDeck = (): Card[] => {
  const deck: Card[] = [];
  SUITS.forEach(suit => {
    RANKS.forEach(rank => {
      deck.push({ rank, suit, isFaceUp: false });
    });
  });
  // Fisher-Yates Shuffle
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
  return deck;
};

const CardComponent: React.FC<{ card: Card | null }> = ({ card }) => {
    if (!card) return <div className="w-20 h-28 rounded-lg bg-black/10 border-2 border-dashed border-white/30" />;
    
    if (!card.isFaceUp) return <div className="w-20 h-28 rounded-lg bg-blue-700 border-2 border-blue-900" />;

    const color = (card.suit === 'H' || card.suit === 'D') ? 'text-red-500' : 'text-black';
    const suitIcon = { H: '♥', D: '♦', C: '♣', S: '♠' }[card.suit];

    return (
        <div className={`w-20 h-28 rounded-lg bg-white border border-gray-400 p-1 flex flex-col justify-between text-lg font-bold ${color}`}>
            <span>{card.rank}{suitIcon}</span>
            <span className="self-end rotate-180">{card.rank}{suitIcon}</span>
        </div>
    );
};


export const SolitaireApp: React.FC<AppProps> = () => {
  const [stock, setStock] = useState<Card[]>([]);
  const [waste, setWaste] = useState<Card[]>([]);
  const [foundations, setFoundations] = useState<Card[][]>([[], [], [], []]);
  const [tableau, setTableau] = useState<Card[][]>([[], [], [], [], [], [], []]);
  const [isWin, setIsWin] = useState(false);

  const startGame = () => {
    const deck = createDeck();
    
    // Deal tableau
    const newTableau: Card[][] = Array.from({ length: 7 }, () => []);
    for (let i = 0; i < 7; i++) {
      for (let j = i; j < 7; j++) {
        newTableau[j].push(deck.pop()!);
      }
    }
    newTableau.forEach(pile => pile[pile.length - 1].isFaceUp = true);
    
    setTableau(newTableau);
    setFoundations([[], [], [], []]);
    setWaste([]);
    setStock(deck);
    setIsWin(false);
  };

  useEffect(startGame, []);

  const drawFromStock = () => {
    if (stock.length > 0) {
      const newStock = [...stock];
      const drawnCard = newStock.pop()!;
      drawnCard.isFaceUp = true;
      setWaste(prev => [drawnCard, ...prev]);
      setStock(newStock);
    } else {
      // Reset stock from waste
      const newStock = [...waste].reverse().map(c => ({...c, isFaceUp: false}));
      setStock(newStock);
      setWaste([]);
    }
  };
  
  // Drag and drop is complex to implement without a library.
  // This will be a simplified click-to-move implementation.
  // A real implementation would use onDragStart, onDragOver, onDrop events.

  return (
    <div className="w-full h-full bg-green-800 p-4 select-none">
      <header className="flex justify-between mb-4">
        <div className="flex gap-4">
          <div onClick={drawFromStock} className="cursor-pointer"><CardComponent card={stock[stock.length - 1] || null}/></div>
          <div className="cursor-pointer"><CardComponent card={waste[0] || null}/></div>
        </div>
        <div className="flex gap-4">
            {foundations.map((pile, index) => (
                <div key={index}><CardComponent card={pile[pile.length - 1] || null}/></div>
            ))}
        </div>
      </header>
      <main className="flex justify-between">
        {tableau.map((pile, pileIndex) => (
          <div key={pileIndex} className="relative">
            {pile.map((card, cardIndex) => (
                <div key={cardIndex} className="absolute" style={{ top: `${cardIndex * 25}px` }}>
                    <CardComponent card={card}/>
                </div>
            ))}
          </div>
        ))}
      </main>
      <footer className="absolute bottom-4 left-4">
        <button onClick={startGame} className="px-4 py-2 bg-white/30 text-white rounded-lg hover:bg-white/50">New Game</button>
      </footer>
    </div>
  );
};
