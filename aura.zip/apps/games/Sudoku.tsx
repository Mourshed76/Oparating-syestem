import React, { useState, useMemo, useEffect } from 'react';
import type { AppProps } from '../../types';

type SudokuGrid = (number | null)[][];

const initialPuzzle: SudokuGrid = [
  [5, 3, null, null, 7, null, null, null, null],
  [6, null, null, 1, 9, 5, null, null, null],
  [null, 9, 8, null, null, null, null, 6, null],
  [8, null, null, null, 6, null, null, null, 3],
  [4, null, null, 8, null, 3, null, null, 1],
  [7, null, null, null, 2, null, null, null, 6],
  [null, 6, null, null, null, null, 2, 8, null],
  [null, null, null, 4, 1, 9, null, null, 5],
  [null, null, null, null, 8, null, null, 7, 9],
];

export const SudokuApp: React.FC<AppProps> = () => {
    const [grid, setGrid] = useState<SudokuGrid>(JSON.parse(JSON.stringify(initialPuzzle)));
    const [selectedCell, setSelectedCell] = useState<{ row: number; col: number } | null>(null);
    const [isComplete, setIsComplete] = useState(false);

    const handleInputChange = (row: number, col: number, value: string) => {
        const num = value === '' ? null : parseInt(value, 10);
        if (num !== null && (isNaN(num) || num < 1 || num > 9)) return;

        const newGrid = grid.map(r => [...r]);
        newGrid[row][col] = num;
        setGrid(newGrid);
    };

    const isCellValid = (row: number, col: number): boolean => {
        const value = grid[row][col];
        if (value === null) return true;

        // Check row
        for (let c = 0; c < 9; c++) {
            if (c !== col && grid[row][c] === value) return false;
        }
        // Check column
        for (let r = 0; r < 9; r++) {
            if (r !== row && grid[r][col] === value) return false;
        }
        // Check 3x3 box
        const startRow = Math.floor(row / 3) * 3;
        const startCol = Math.floor(col / 3) * 3;
        for (let r = startRow; r < startRow + 3; r++) {
            for (let c = startCol; c < startCol + 3; c++) {
                if ((r !== row || c !== col) && grid[r][c] === value) return false;
            }
        }
        return true;
    };
    
    useEffect(() => {
      const isFilled = grid.every(row => row.every(cell => cell !== null));
      const isValid = grid.every((row, r) => row.every((_, c) => isCellValid(r, c)));
      setIsComplete(isFilled && isValid);
    }, [grid]);

    const solvePuzzle = () => {
        const solution: SudokuGrid = [
            [5, 3, 4, 6, 7, 8, 9, 1, 2],
            [6, 7, 2, 1, 9, 5, 3, 4, 8],
            [1, 9, 8, 3, 4, 2, 5, 6, 7],
            [8, 5, 9, 7, 6, 1, 4, 2, 3],
            [4, 2, 6, 8, 5, 3, 7, 9, 1],
            [7, 1, 3, 9, 2, 4, 8, 5, 6],
            [9, 6, 1, 5, 3, 7, 2, 8, 4],
            [2, 8, 7, 4, 1, 9, 6, 3, 5],
            [3, 4, 5, 2, 8, 6, 1, 7, 9],
        ];
        setGrid(solution);
    };
    
    const resetPuzzle = () => {
        setGrid(JSON.parse(JSON.stringify(initialPuzzle)));
        setIsComplete(false);
    };

    return (
        <div className="w-full h-full bg-gray-100 flex flex-col items-center justify-center p-4">
            <h1 className="text-2xl font-bold mb-4">Sudoku</h1>
            <div className="bg-white shadow-lg p-2 rounded-lg grid grid-cols-9 gap-px bg-gray-400 border-2 border-gray-400">
                {grid.map((row, r) =>
                    row.map((cell, c) => {
                        const isInitial = initialPuzzle[r][c] !== null;
                        const isSelected = selectedCell?.row === r || selectedCell?.col === c;
                        const inSameBox = selectedCell && Math.floor(selectedCell.row / 3) === Math.floor(r / 3) && Math.floor(selectedCell.col / 3) === Math.floor(c / 3);
                        const isValid = isCellValid(r, c);

                        return (
                            <div key={`${r}-${c}`} className={`w-10 h-10 md:w-12 md:h-12 flex items-center justify-center bg-white 
                                ${r % 3 === 2 && r !== 8 ? 'border-b-2 border-gray-400' : ''}
                                ${c % 3 === 2 && c !== 8 ? 'border-r-2 border-gray-400' : ''}
                                ${(isSelected || inSameBox) ? 'bg-blue-50' : ''}
                            `}>
                                <input
                                    type="text"
                                    inputMode="numeric"
                                    pattern="[1-9]"
                                    maxLength={1}
                                    value={cell || ''}
                                    readOnly={isInitial}
                                    onFocus={() => setSelectedCell({row: r, col: c})}
                                    onChange={(e) => handleInputChange(r, c, e.target.value)}
                                    className={`w-full h-full text-center text-xl md:text-2xl font-mono focus:outline-none bg-transparent
                                        ${isInitial ? 'text-gray-800 font-bold' : 'text-blue-600'}
                                        ${!isValid ? 'text-red-500' : ''}
                                        ${selectedCell?.row === r && selectedCell?.col === c ? 'bg-blue-100' : ''}
                                    `}
                                />
                            </div>
                        )
                    })
                )}
            </div>
             {isComplete && <p className="text-green-600 font-bold text-xl mt-4">Congratulations! You solved it!</p>}
             <div className="mt-4 flex space-x-4">
                <button onClick={resetPuzzle} className="px-4 py-2 bg-gray-500 text-white font-semibold rounded-lg hover:bg-gray-600">Reset</button>
                <button onClick={solvePuzzle} className="px-4 py-2 bg-blue-500 text-white font-semibold rounded-lg hover:bg-blue-600">Solve</button>
            </div>
        </div>
    );
};
