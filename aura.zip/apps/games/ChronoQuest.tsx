import React, { useState } from 'react';
import type { AppProps } from '../../types';

interface Scene {
    text: string;
    options: { text: string; nextScene: string; effect?: (stats: any) => any }[];
    image: string;
}

const scenes: Record<string, Scene> = {
    start: {
        image: 'https://picsum.photos/seed/quest_start/400/200',
        text: 'You awaken in a forest clearing, unsure of how you got here. A path leads north into the woods, and you see smoke rising from the east.',
        options: [
            { text: 'Follow the path north', nextScene: 'path_north' },
            { text: 'Investigate the smoke', nextScene: 'smoke_east' },
        ],
    },
    path_north: {
        image: 'https://picsum.photos/seed/quest_path/400/200',
        text: 'The path is dark and overgrown. You hear a rustling in the bushes.',
        options: [
            { text: 'Continue forward', nextScene: 'monster' },
            { text: 'Turn back', nextScene: 'start' },
        ],
    },
    smoke_east: {
        image: 'https://picsum.photos/seed/quest_camp/400/200',
        text: 'You find a small, abandoned campsite with a still-smoldering fire. A half-eaten apple sits on a log.',
        options: [
            { text: 'Eat the apple', nextScene: 'eat_apple', effect: stats => ({ ...stats, hp: Math.min(stats.maxHp, stats.hp + 5) }) },
            { text: 'Search the camp', nextScene: 'search_camp' },
            { text: 'Return to the clearing', nextScene: 'start' },
        ],
    },
    monster: {
        image: 'https://picsum.photos/seed/quest_monster/400/200',
        text: 'A fearsome goblin jumps out! It looks angry.',
        options: [{ text: 'Game Over. Restart?', nextScene: 'start' }],
    },
    eat_apple: {
        image: 'https://picsum.photos/seed/quest_apple/400/200',
        text: 'You eat the apple. It\'s delicious and you feel refreshed! (HP +5)',
        options: [{ text: 'Continue exploring', nextScene: 'start' }],
    },
    search_camp: {
        image: 'https://picsum.photos/seed/quest_search/400/200',
        text: 'You find a small wooden sword tucked under a blanket.',
        options: [{ text: 'Take the sword and go back', nextScene: 'start' }],
    }
};

export const ChronoQuestApp: React.FC<AppProps> = () => {
    const [currentScene, setCurrentScene] = useState('start');
    const [stats, setStats] = useState({ hp: 20, maxHp: 20, attack: 5 });

    const handleOptionClick = (option: { text: string; nextScene: string; effect?: (stats: any) => any }) => {
        if (option.effect) {
            setStats(option.effect(stats));
        }
        setCurrentScene(option.nextScene);
    };
    
    const scene = scenes[currentScene];

    return (
        <div className="w-full h-full bg-gray-800 text-gray-200 flex flex-col font-serif">
            <header className="flex-shrink-0 p-2 bg-black/30 text-center font-bold text-lg">
                Chrono Quest
            </header>
            <main className="flex-grow flex flex-col p-4">
                <img src={scene.image} alt="Scene" className="w-full h-48 object-cover rounded-lg mb-4"/>
                <div className="bg-black/20 p-4 rounded-lg flex-grow">
                    <p className="text-lg leading-relaxed">{scene.text}</p>
                </div>
                <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-3">
                    {scene.options.map((option, index) => (
                        <button key={index} onClick={() => handleOptionClick(option)} className="p-3 bg-gray-700 hover:bg-gray-600 rounded-lg transition-colors text-left">
                           › {option.text}
                        </button>
                    ))}
                </div>
            </main>
             <footer className="flex-shrink-0 p-2 bg-black/30 text-center text-sm">
                HP: {stats.hp} / {stats.maxHp} | ATK: {stats.attack}
            </footer>
        </div>
    );
};
