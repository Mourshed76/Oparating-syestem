import React, { useState, useEffect, useCallback, useRef } from 'react';
import type { AppProps } from '../../types';

const GAME_WIDTH = 500;
const GAME_HEIGHT = 600;

interface GameObject { id: number; x: number; y: number; }
interface Player extends GameObject { width: number; height: number; }
interface Bullet extends GameObject { width: number; height: number; }
interface Enemy extends GameObject { width: number; height: number; type: '👽' | '👾' | '🛸'; }

export const GalaxyStrikeApp: React.FC<AppProps> = () => {
    const [player, setPlayer] = useState<Player>({ id: 0, x: GAME_WIDTH / 2 - 25, y: GAME_HEIGHT - 60, width: 50, height: 30 });
    const [bullets, setBullets] = useState<Bullet[]>([]);
    const [enemies, setEnemies] = useState<Enemy[]>([]);
    const [score, setScore] = useState(0);
    const [lives, setLives] = useState(3);
    const [gameState, setGameState] = useState<'menu' | 'playing' | 'gameOver'>('menu');
    
    const gameLoopRef = useRef<number | null>(null);
    const keysPressed = useRef<{ [key: string]: boolean }>({});

    const resetGame = () => {
        setPlayer({ id: 0, x: GAME_WIDTH / 2 - 25, y: GAME_HEIGHT - 60, width: 50, height: 30 });
        setBullets([]);
        setEnemies([]);
        setScore(0);
        setLives(3);
        setGameState('menu');
    };

    const gameLoop = useCallback(() => {
        if (gameState !== 'playing') return;

        // Player movement
        setPlayer(p => {
            let newX = p.x;
            if (keysPressed.current['ArrowLeft']) newX -= 5;
            if (keysPressed.current['ArrowRight']) newX += 5;
            return { ...p, x: Math.max(0, Math.min(newX, GAME_WIDTH - p.width)) };
        });

        // Bullet movement
        setBullets(bs => bs.map(b => ({ ...b, y: b.y - 10 })).filter(b => b.y > -b.height));

        // Enemy movement & creation
        setEnemies(es => {
            let newEnemies = es.map(e => ({ ...e, y: e.y + 1 })).filter(e => e.y < GAME_HEIGHT);
            if (Math.random() < 0.02) {
                const enemyTypes: Enemy['type'][] = ['👽', '👾', '🛸'];
                newEnemies.push({
                    id: Date.now(),
                    x: Math.random() * (GAME_WIDTH - 40),
                    y: -40,
                    width: 40,
                    height: 30,
                    type: enemyTypes[Math.floor(Math.random() * enemyTypes.length)]
                });
            }
            return newEnemies;
        });

        // Collision detection
        setBullets(bs => {
            const hitBullets = new Set<number>();
            const hitEnemies = new Set<number>();

            for (const b of bs) {
                for (const e of enemies) {
                    if (b.x < e.x + e.width && b.x + b.width > e.x && b.y < e.y + e.height && b.y + b.height > e.y) {
                        hitBullets.add(b.id);
                        hitEnemies.add(e.id);
                        setScore(s => s + 100);
                    }
                }
            }
            
            if (hitEnemies.size > 0) {
                setEnemies(es => es.filter(e => !hitEnemies.has(e.id)));
            }
            
            return bs.filter(b => !hitBullets.has(b.id));
        });
        
        // Player-Enemy collision
        setEnemies(es => {
            const remainingEnemies = [];
            for(const e of es) {
                if (player.x < e.x + e.width && player.x + player.width > e.x && player.y < e.y + e.height && player.y + player.height > e.y) {
                    setLives(l => l - 1);
                    if (lives - 1 <= 0) {
                         setGameState('gameOver');
                    }
                } else {
                    remainingEnemies.push(e);
                }
            }
            return remainingEnemies;
        });

        gameLoopRef.current = requestAnimationFrame(gameLoop);
    }, [gameState, enemies, lives, player]);

    useEffect(() => {
        if (gameState === 'playing') {
            gameLoopRef.current = requestAnimationFrame(gameLoop);
        }
        return () => { if (gameLoopRef.current) cancelAnimationFrame(gameLoopRef.current); };
    }, [gameState, gameLoop]);

    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            keysPressed.current[e.key] = true;
            if (e.key === ' ' && gameState === 'playing') {
                setBullets(bs => [...bs, { id: Date.now(), x: player.x + player.width / 2 - 2.5, y: player.y, width: 5, height: 10 }]);
            }
        };
        const handleKeyUp = (e: KeyboardEvent) => {
            keysPressed.current[e.key] = false;
        };
        window.addEventListener('keydown', handleKeyDown);
        window.addEventListener('keyup', handleKeyUp);
        return () => {
            window.removeEventListener('keydown', handleKeyDown);
            window.removeEventListener('keyup', handleKeyUp);
        };
    }, [player, gameState]);

    return (
        <div className="w-full h-full bg-black flex items-center justify-center select-none">
            <div className="relative overflow-hidden bg-gray-900 border-2 border-indigo-500" style={{ width: GAME_WIDTH, height: GAME_HEIGHT, backgroundImage: 'radial-gradient(circle, #000 0%, #111 80%)' }}>
                {/* Game Objects */}
                <div className="absolute text-3xl" style={{ left: player.x, top: player.y }}>🚀</div>
                {bullets.map(b => <div key={b.id} className="absolute bg-yellow-400 w-1 h-3 rounded-full" style={{ left: b.x, top: b.y }} />)}
                {enemies.map(e => <div key={e.id} className="absolute text-3xl" style={{ left: e.x, top: e.y }}>{e.type}</div>)}

                {/* UI */}
                <div className="absolute top-4 left-4 text-white font-mono">Score: {score}</div>
                <div className="absolute top-4 right-4 text-white font-mono">Lives: {'❤️'.repeat(lives)}</div>
                
                 {gameState !== 'playing' && (
                     <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center text-center text-white">
                        {gameState === 'menu' && (
                            <>
                                <h1 className="text-5xl font-bold">Galaxy Strike</h1>
                                <button onClick={() => setGameState('playing')} className="mt-8 px-6 py-3 bg-indigo-500 rounded-lg text-xl border-b-4 border-indigo-700 hover:bg-indigo-400">Start Game</button>
                            </>
                        )}
                         {gameState === 'gameOver' && (
                            <>
                                <h1 className="text-5xl font-bold text-red-500">Game Over</h1>
                                <p className="text-2xl mt-2">Final Score: {score}</p>
                                <button onClick={resetGame} className="mt-6 px-6 py-3 bg-blue-500 rounded-lg text-xl border-b-4 border-blue-700 hover:bg-blue-400">Try Again</button>
                            </>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
};
