import React, { useState, useEffect } from 'react';
import type { AppProps } from '../../types';

interface Tile { id: number; symbol: string; isSelected: boolean; isMatched: boolean; }

const SYMBOLS = ['🀄', '🀄', '🀄', '🀄', '🀧', '🀧', '🀧', '🀧', '🀨', '🀨', '🀨', '🀨', '🀩', '🀩', '🀩', '🀩', '🌸', '🌸', '🌸', '🌸', '🎋', '🎋', '🎋', '🎋'];

const generateTiles = (): Tile[] => {
    return [...SYMBOLS, ...SYMBOLS]
        .sort(() => Math.random() - 0.5)
        .map((symbol, id) => ({ id, symbol, isSelected: false, isMatched: false }));
};

export const MahjongApp: React.FC<AppProps> = () => {
    const [tiles, setTiles] = useState<Tile[]>(() => generateTiles());
    const [selected, setSelected] = useState<Tile | null>(null);
    const [isWin, setIsWin] = useState(false);

    useEffect(() => {
        if (tiles.every(t => t.isMatched)) {
            setIsWin(true);
        }
    }, [tiles]);

    const handleTileClick = (tile: Tile) => {
        if (tile.isMatched || tile.isSelected) return;

        if (!selected) {
            setSelected(tile);
            setTiles(ts => ts.map(t => t.id === tile.id ? { ...t, isSelected: true } : t));
        } else {
            if (selected.symbol === tile.symbol && selected.id !== tile.id) {
                // Match found
                setTiles(ts => ts.map(t => (t.id === selected.id || t.id === tile.id) ? { ...t, isMatched: true, isSelected: false } : t));
            } else {
                // No match
                setTiles(ts => ts.map(t => t.id === selected.id ? { ...t, isSelected: false } : t));
            }
            setSelected(null);
        }
    };
    
    const resetGame = () => {
        setTiles(generateTiles());
        setSelected(null);
        setIsWin(false);
    };

    return (
        <div className="w-full h-full bg-green-800 flex flex-col items-center justify-center p-4">
            <h1 className="text-2xl font-bold text-white mb-4">Mahjong Solitaire</h1>
            {isWin ? (
                 <div className="text-center text-white">
                    <p className="text-3xl font-bold text-yellow-300">You Win!</p>
                    <button onClick={resetGame} className="mt-4 px-4 py-2 bg-blue-500 rounded-lg">Play Again</button>
                 </div>
            ) : (
                <div className="grid grid-cols-8 gap-2 bg-green-700 p-2 rounded-lg">
                    {tiles.map(tile => (
                        <button key={tile.id} onClick={() => handleTileClick(tile)}
                            className={`w-12 h-16 rounded-md text-3xl flex items-center justify-center transition-all
                                ${tile.isMatched ? 'opacity-0' : 'bg-ivory-100 border-2 border-gray-600 shadow-md'}
                                ${tile.isSelected ? 'bg-yellow-300 transform -translate-y-1' : ''}
                            `}
                            disabled={tile.isMatched}>
                            {tile.symbol}
                        </button>
                    ))}
                </div>
            )}
             <style>{`.bg-ivory-100 { background-color: #FFFFF0; }`}</style>
        </div>
    );
};
