import React, { useState, useEffect } from 'react';
import type { AppProps } from '../../types';

type Cell = {
  isMine: boolean;
  isRevealed: boolean;
  isFlagged: boolean;
  adjacentMines: number;
};

type GameState = 'playing' | 'won' | 'lost' | 'menu';
type Difficulty = 'easy' | 'medium' | 'hard';

const DIFFICULTIES = {
  easy: { rows: 9, cols: 9, mines: 10 },
  medium: { rows: 16, cols: 16, mines: 40 },
  hard: { rows: 16, cols: 30, mines: 99 },
};

const generateBoard = (rows: number, cols: number, mines: number): Cell[][] => {
  // 1. Create blank board
  const board: Cell[][] = Array.from({ length: rows }, () =>
    Array.from({ length: cols }, () => ({
      isMine: false,
      isRevealed: false,
      isFlagged: false,
      adjacentMines: 0,
    }))
  );

  // 2. Place mines randomly
  let minesPlaced = 0;
  while (minesPlaced < mines) {
    const r = Math.floor(Math.random() * rows);
    const c = Math.floor(Math.random() * cols);
    if (!board[r][c].isMine) {
      board[r][c].isMine = true;
      minesPlaced++;
    }
  }

  // 3. Calculate adjacent mines
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      if (board[r][c].isMine) continue;
      let count = 0;
      for (let dr = -1; dr <= 1; dr++) {
        for (let dc = -1; dc <= 1; dc++) {
          const nr = r + dr;
          const nc = c + dc;
          if (nr >= 0 && nr < rows && nc >= 0 && nc < cols && board[nr][nc].isMine) {
            count++;
          }
        }
      }
      board[r][c].adjacentMines = count;
    }
  }

  return board;
};


export const MinesweeperApp: React.FC<AppProps> = () => {
  const [difficulty, setDifficulty] = useState<Difficulty>('easy');
  const [board, setBoard] = useState<Cell[][]>(() => generateBoard(DIFFICULTIES.easy.rows, DIFFICULTIES.easy.cols, DIFFICULTIES.easy.mines));
  const [gameState, setGameState] = useState<GameState>('playing');
  const [flags, setFlags] = useState(DIFFICULTIES.easy.mines);

  const { rows, cols, mines } = DIFFICULTIES[difficulty];

  useEffect(() => {
    resetGame(difficulty);
  }, [difficulty]);

  const resetGame = (newDifficulty: Difficulty) => {
    const { rows, cols, mines } = DIFFICULTIES[newDifficulty];
    setBoard(generateBoard(rows, cols, mines));
    setGameState('playing');
    setFlags(mines);
  };
  
  const revealCell = (r: number, c: number) => {
    if (gameState !== 'playing' || board[r][c].isRevealed || board[r][c].isFlagged) return;

    const newBoard = JSON.parse(JSON.stringify(board)); // Deep copy

    if (newBoard[r][c].isMine) {
      setGameState('lost');
      // Reveal all mines on loss
      for (let row = 0; row < rows; row++) {
        for (let col = 0; col < cols; col++) {
          if (newBoard[row][col].isMine) newBoard[row][col].isRevealed = true;
        }
      }
      setBoard(newBoard);
      return;
    }
    
    // Recursive reveal for empty cells
    const reveal = (r: number, c: number) => {
        if (r < 0 || r >= rows || c < 0 || c >= cols || newBoard[r][c].isRevealed) return;
        newBoard[r][c].isRevealed = true;

        if (newBoard[r][c].adjacentMines === 0) {
            for (let dr = -1; dr <= 1; dr++) {
                for (let dc = -1; dc <= 1; dc++) {
                    reveal(r + dr, c + dc);
                }
            }
        }
    };
    reveal(r, c);

    // Check for win condition
    const revealedCount = newBoard.flat().filter(cell => cell.isRevealed).length;
    if (revealedCount === rows * cols - mines) {
        setGameState('won');
    }

    setBoard(newBoard);
  };
  
  const flagCell = (e: React.MouseEvent, r: number, c: number) => {
    e.preventDefault();
    if (gameState !== 'playing' || board[r][c].isRevealed) return;

    const newBoard = JSON.parse(JSON.stringify(board));
    const cell = newBoard[r][c];

    if (cell.isFlagged) {
        cell.isFlagged = false;
        setFlags(prev => prev + 1);
    } else if (flags > 0) {
        cell.isFlagged = true;
        setFlags(prev => prev - 1);
    }
    setBoard(newBoard);
  };
  
  const CellComponent: React.FC<{ cell: Cell; r: number; c: number }> = ({ cell, r, c }) => {
    const numberColors = ['text-blue-500', 'text-green-500', 'text-red-500', 'text-purple-700', 'text-maroon-700', 'text-teal-500', 'text-black', 'text-gray-500'];
    
    if (!cell.isRevealed) {
      return <button onClick={() => revealCell(r, c)} onContextMenu={(e) => flagCell(e, r, c)} className="w-6 h-6 bg-gray-400 border-2 border-r-gray-200 border-b-gray-200 border-l-gray-500 border-t-gray-500 flex items-center justify-center text-red-500 font-bold">{cell.isFlagged ? '🚩' : ''}</button>;
    }
    if (cell.isMine) {
      return <div className="w-6 h-6 bg-red-500 flex items-center justify-center">💣</div>;
    }
    return <div className={`w-6 h-6 bg-gray-300 flex items-center justify-center font-bold ${numberColors[cell.adjacentMines - 1]}`}>{cell.adjacentMines > 0 ? cell.adjacentMines : ''}</div>;
  };
  
  return (
    <div className="w-full h-full bg-gray-300 flex flex-col items-center justify-center p-4">
      <header className="w-full max-w-max bg-gray-400 p-2 mb-4 flex justify-between items-center border-2 border-l-gray-200 border-t-gray-200 border-r-gray-500 border-b-gray-500">
        <select value={difficulty} onChange={(e) => setDifficulty(e.target.value as Difficulty)} className="bg-gray-200 border-gray-500 border p-1 font-mono">
            <option value="easy">Easy</option>
            <option value="medium">Medium</option>
            <option value="hard">Hard</option>
        </select>
        <div className="font-mono text-2xl text-red-600 bg-black px-2">{String(flags).padStart(3, '0')}</div>
        <button onClick={() => resetGame(difficulty)} className="text-2xl">{gameState === 'playing' ? '🙂' : gameState === 'won' ? '😎' : '😵'}</button>
      </header>
      <main className="bg-gray-400 p-2 border-2 border-l-gray-200 border-t-gray-200 border-r-gray-500 border-b-gray-500">
         <div className="grid gap-px bg-gray-500" style={{ gridTemplateColumns: `repeat(${cols}, 1fr)` }}>
            {board.map((row, r) => row.map((cell, c) => <CellComponent key={`${r}-${c}`} cell={cell} r={r} c={c} />))}
        </div>
      </main>
    </div>
  );
};
