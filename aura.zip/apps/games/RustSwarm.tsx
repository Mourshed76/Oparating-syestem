import React, { useState, useEffect, useCallback, useRef } from 'react';
import type { AppProps } from '../../types';

const GAME_WIDTH = 800;
const GAME_HEIGHT = 600;
const UNIT_SIZE = 5;
const CORE_SIZE = 40;
const SWARM_SIZE = 100;

interface Unit { id: number; x: number; y: number; }
interface Core { x: number; y: number; health: number; }

export const RustSwarmApp: React.FC<AppProps> = () => {
    const [playerSwarm, setPlayerSwarm] = useState<Unit[]>([]);
    const [enemySwarm, setEnemySwarm] = useState<Unit[]>([]);
    const [playerCore, setPlayerCore] = useState<Core>({ x: 50, y: GAME_HEIGHT / 2, health: 1000 });
    const [enemyCore, setEnemyCore] = useState<Core>({ x: GAME_WIDTH - 50, y: GAME_HEIGHT / 2, health: 1000 });
    const [playerTarget, setPlayerTarget] = useState<{ x: number, y: number } | null>(null);
    const [gameState, setGameState] = useState<'menu' | 'playing' | 'won' | 'lost'>('menu');
    
    const gameLoopRef = useRef<number | null>(null);

    const resetGame = () => {
        setPlayerSwarm(Array.from({ length: SWARM_SIZE }, (_, i) => ({ id: i, x: 70 + Math.random() * 50, y: GAME_HEIGHT / 2 - 50 + Math.random() * 100 })));
        setEnemySwarm(Array.from({ length: SWARM_SIZE }, (_, i) => ({ id: i, x: GAME_WIDTH - 70 - Math.random() * 50, y: GAME_HEIGHT / 2 - 50 + Math.random() * 100 })));
        setPlayerCore({ x: 50, y: GAME_HEIGHT / 2, health: 1000 });
        setEnemyCore({ x: GAME_WIDTH - 50, y: GAME_HEIGHT / 2, health: 1000 });
        setPlayerTarget(null);
        setGameState('menu');
    };

    useEffect(resetGame, []);

    const gameLoop = useCallback(() => {
        if (gameState !== 'playing') return;

        const moveSwarm = (swarm: Unit[], target: {x:number, y:number} | null, isPlayer: boolean) => {
            if (!target) return swarm;
            return swarm.map(unit => {
                const angle = Math.atan2(target.y - unit.y, target.x - unit.x);
                const speed = 1.5;
                const newX = unit.x + Math.cos(angle) * speed + (Math.random() - 0.5);
                const newY = unit.y + Math.sin(angle) * speed + (Math.random() - 0.5);
                return { ...unit, x: newX, y: newY };
            });
        };
        
        // Enemy AI
        const enemyTarget = playerTarget && Math.hypot(playerTarget.x - enemyCore.x, playerTarget.y - enemyCore.y) < 300 ? playerTarget : { x: playerCore.x, y: playerCore.y };

        setPlayerSwarm(swarm => moveSwarm(swarm, playerTarget, true));
        setEnemySwarm(swarm => moveSwarm(swarm, enemyTarget, false));

        // Combat & Damage
        const newPlayerSwarm = [...playerSwarm];
        const newEnemySwarm = [...enemySwarm];
        let playerHealth = playerCore.health;
        let enemyHealth = enemyCore.health;

        for (let i = newPlayerSwarm.length - 1; i >= 0; i--) {
            const pUnit = newPlayerSwarm[i];
            // Player vs Enemy Unit
            for (let j = newEnemySwarm.length - 1; j >= 0; j--) {
                const eUnit = newEnemySwarm[j];
                if (Math.hypot(pUnit.x - eUnit.x, pUnit.y - eUnit.y) < UNIT_SIZE * 2) {
                    if (Math.random() < 0.1) newPlayerSwarm.splice(i, 1);
                    if (Math.random() < 0.1) newEnemySwarm.splice(j, 1);
                    break;
                }
            }
             // Player vs Enemy Core
            if (Math.hypot(pUnit.x - enemyCore.x, pUnit.y - enemyCore.y) < CORE_SIZE) {
                enemyHealth -= 1;
                newPlayerSwarm.splice(i, 1);
            }
        }
        
        for (let i = newEnemySwarm.length - 1; i >= 0; i--) {
            const eUnit = newEnemySwarm[i];
            // Enemy vs Player Core
            if (Math.hypot(eUnit.x - playerCore.x, eUnit.y - playerCore.y) < CORE_SIZE) {
                playerHealth -= 1;
                newEnemySwarm.splice(i, 1);
            }
        }
        
        setPlayerSwarm(newPlayerSwarm);
        setEnemySwarm(newEnemySwarm);
        setPlayerCore(c => ({...c, health: playerHealth}));
        setEnemyCore(c => ({...c, health: enemyHealth}));

        if (playerHealth <= 0) setGameState('lost');
        if (enemyHealth <= 0) setGameState('won');

        gameLoopRef.current = requestAnimationFrame(gameLoop);
    }, [gameState, playerTarget, playerCore, enemyCore, playerSwarm, enemySwarm]);

    useEffect(() => {
        if (gameState === 'playing') gameLoopRef.current = requestAnimationFrame(gameLoop);
        return () => { if (gameLoopRef.current) cancelAnimationFrame(gameLoopRef.current); };
    }, [gameState, gameLoop]);
    
    const handleMouseClick = (e: React.MouseEvent) => {
        if (gameState !== 'playing') return;
        const rect = e.currentTarget.getBoundingClientRect();
        setPlayerTarget({ x: e.clientX - rect.left, y: e.clientY - rect.top });
    };

    return (
        <div className="w-full h-full bg-gray-900 text-white flex flex-col items-center justify-center p-4 font-mono select-none">
            <div className="w-full max-w-4xl flex justify-between items-center mb-2">
                <div>Player Units: {playerSwarm.length}</div>
                <div>Enemy Units: {enemySwarm.length}</div>
            </div>
            <div onClick={handleMouseClick} className="relative bg-gray-800 border-2 border-orange-800" style={{ width: GAME_WIDTH, height: GAME_HEIGHT }}>
                {/* Cores */}
                <div className="absolute rounded-full bg-blue-700" style={{ left: playerCore.x - CORE_SIZE/2, top: playerCore.y - CORE_SIZE/2, width: CORE_SIZE, height: CORE_SIZE }} />
                <div className="absolute rounded-full bg-red-700" style={{ left: enemyCore.x - CORE_SIZE/2, top: enemyCore.y - CORE_SIZE/2, width: CORE_SIZE, height: CORE_SIZE }} />
                
                {/* Swarms */}
                {playerSwarm.map(u => <div key={u.id} className="absolute rounded-full bg-blue-400" style={{ left: u.x - UNIT_SIZE/2, top: u.y - UNIT_SIZE/2, width: UNIT_SIZE, height: UNIT_SIZE }}/>)}
                {enemySwarm.map(u => <div key={u.id} className="absolute rounded-full bg-red-400" style={{ left: u.x - UNIT_SIZE/2, top: u.y - UNIT_SIZE/2, width: UNIT_SIZE, height: UNIT_SIZE }}/>)}

                {/* Game State Overlay */}
                 {gameState !== 'playing' && (
                     <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center text-center">
                        {gameState === 'menu' && <>
                            <h1 className="text-5xl font-bold">Rust Swarm</h1>
                            <p className="mt-2">Command your swarm. Destroy the enemy core.</p>
                            <button onClick={() => setGameState('playing')} className="mt-8 px-6 py-3 bg-orange-600 rounded-lg text-xl">Start Battle</button>
                        </>}
                         {(gameState === 'won' || gameState === 'lost') && <>
                            <h1 className={`text-5xl font-bold ${gameState === 'won' ? 'text-green-500' : 'text-red-500'}`}>{gameState === 'won' ? 'Victory!' : 'Defeat!'}</h1>
                            <button onClick={resetGame} className="mt-6 px-6 py-3 bg-blue-500 rounded-lg text-xl">Play Again</button>
                         </>}
                    </div>
                )}
            </div>
            <div className="w-full max-w-4xl flex justify-between items-center mt-2">
                <div className="w-1/3 bg-blue-900 rounded-full h-4"><div className="bg-blue-400 h-4 rounded-full" style={{width: `${Math.max(0, playerCore.health / 10)}%`}}/></div>
                <div className="w-1/3 bg-red-900 rounded-full h-4 text-right"><div className="bg-red-400 h-4 rounded-full" style={{width: `${Math.max(0, enemyCore.health / 10)}%`}}/></div>
            </div>
        </div>
    );
};
