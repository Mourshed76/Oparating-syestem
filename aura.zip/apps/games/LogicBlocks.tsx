import React, { useState, useMemo } from 'react';
import type { AppProps } from '../../types';

const BOARD_SIZE = 10;
const SHAPES = {
    I: { points: [[0,0],[0,1],[0,2],[0,3]], color: 'bg-cyan-500' },
    L: { points: [[0,0],[0,1],[0,2],[1,2]], color: 'bg-orange-500' },
    T: { points: [[0,0],[0,1],[0,2],[-1,1]], color: 'bg-purple-500' },
    S: { points: [[0,0],[1,0],[1,1],[2,1]], color: 'bg-green-500' },
    O: { points: [[0,0],[0,1],[1,0],[1,1]], color: 'bg-yellow-500' },
    dot: { points: [[0,0]], color: 'bg-red-500' },
};
type ShapeKey = keyof typeof SHAPES;

const getRandomShape = (): ShapeKey => {
    const keys = Object.keys(SHAPES) as ShapeKey[];
    return keys[Math.floor(Math.random() * keys.length)];
};

export const LogicBlocksApp: React.FC<AppProps> = () => {
    const [board, setBoard] = useState<(ShapeKey | null)[][]>(() => Array.from({ length: BOARD_SIZE }, () => Array(BOARD_SIZE).fill(null)));
    const [availableShapes, setAvailableShapes] = useState<ShapeKey[]>(() => [getRandomShape(), getRandomShape(), getRandomShape()]);
    const [selectedShapeIndex, setSelectedShapeIndex] = useState<number | null>(null);
    const [score, setScore] = useState(0);

    const placeShape = (row: number, col: number) => {
        if (selectedShapeIndex === null) return;
        
        const shapeKey = availableShapes[selectedShapeIndex];
        const shape = SHAPES[shapeKey];
        const newBoard = board.map(r => [...r]);
        
        // Check if placement is valid
        for (const p of shape.points) {
            const r = row + p[1];
            const c = col + p[0];
            if (r < 0 || r >= BOARD_SIZE || c < 0 || c >= BOARD_SIZE || newBoard[r][c] !== null) {
                return; // Invalid placement
            }
        }
        
        // Place the shape
        for (const p of shape.points) {
            newBoard[row + p[1]][col + p[0]] = shapeKey;
        }

        // Clear full lines
        let linesCleared = 0;
        const boardWithoutClearedLines = newBoard.filter(r => !r.every(cell => cell !== null));
        linesCleared += BOARD_SIZE - boardWithoutClearedLines.length;
        
        let transposed = boardWithoutClearedLines[0].map((_, colIndex) => boardWithoutClearedLines.map(row => row[colIndex]));
        const transposedWithoutCleared = transposed.filter(c => !c.every(cell => cell !== null));
        linesCleared += BOARD_SIZE - transposedWithoutCleared.length;

        let finalBoard = Array.from({ length: BOARD_SIZE }, () => Array(BOARD_SIZE).fill(null));
        if(transposedWithoutCleared.length > 0) {
            finalBoard = transposedWithoutCleared[0].map((_, colIndex) => transposedWithoutCleared.map(row => row[colIndex]));
        }

        setBoard(finalBoard);
        setScore(s => s + shape.points.length + linesCleared * 10);
        
        // Update available shapes
        const newAvailableShapes = [...availableShapes];
        newAvailableShapes[selectedShapeIndex] = 'I'; // Placeholder
        if (newAvailableShapes.every(s => s === 'I')) {
             setAvailableShapes([getRandomShape(), getRandomShape(), getRandomShape()]);
        } else {
            newAvailableShapes[selectedShapeIndex] = getRandomShape();
            setAvailableShapes(newAvailableShapes);
        }
        setSelectedShapeIndex(null);
    };

    return (
        <div className="w-full h-full bg-gray-800 text-white flex flex-col items-center justify-center p-4 select-none">
            <h1 className="text-2xl font-bold mb-2">Logic Blocks</h1>
            <p className="mb-4">Score: {score}</p>
            <div className={`grid gap-1 bg-gray-700 p-1 border-2 border-gray-600`} style={{gridTemplateColumns: `repeat(${BOARD_SIZE}, 1fr)`}}>
                {board.map((row, r) => row.map((cell, c) => (
                    <div key={`${r}-${c}`} onMouseUp={() => placeShape(r, c)} onDragOver={e => e.preventDefault()} className="w-8 h-8 flex items-center justify-center border border-gray-600">
                         {cell && <div className={`w-full h-full ${SHAPES[cell].color}`} />}
                    </div>
                )))}
            </div>
            <div className="mt-6 flex gap-4">
                {availableShapes.map((shapeKey, index) => (
                    <div key={index} onMouseDown={() => setSelectedShapeIndex(index)} className={`p-2 bg-gray-700 rounded-lg cursor-grab ${selectedShapeIndex === index ? 'ring-2 ring-yellow-400' : ''}`}>
                         <div className="grid grid-cols-4 gap-1">
                            {SHAPES[shapeKey].points.map(([x,y]) => <div key={`${x}-${y}`} className={`w-4 h-4 ${SHAPES[shapeKey].color}`} style={{gridColumn: x+1, gridRow: y+1}}></div>)}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};
