import React, { useState, useEffect, useRef, useCallback } from 'react';
import type { AppProps, GameState } from '../../types';
import { useSettings } from '../../context/SettingsContext';

const GAME_WIDTH = 560;
const GAME_HEIGHT = 480;
const PADDLE_WIDTH = 100;
const PADDLE_HEIGHT = 15;
const BALL_RADIUS = 8;
const BRICK_ROWS = 5;
const BRICK_COLS = 10;
const BRICK_WIDTH = 50;
const BRICK_HEIGHT = 20;

const GameOverlay: React.FC<{ gameState: GameState; score: number; onStart: () => void; onResume: () => void; onRestart: () => void; }> = ({ gameState, score, onStart, onResume, onRestart }) => (
    <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center text-white font-mono z-10">
        {gameState === 'menu' && (
            <>
                <h1 className="text-4xl font-bold">Brick Breaker</h1>
                <button onClick={onStart} className="mt-6 px-6 py-3 bg-green-500 rounded-lg text-xl border-b-4 border-green-700 hover:bg-green-400">Start Game</button>
            </>
        )}
        {gameState === 'paused' && (
            <>
                <h1 className="text-4xl font-bold">Paused</h1>
                <div className="flex gap-4 mt-6">
                    <button onClick={onResume} className="px-6 py-3 bg-blue-500 rounded-lg text-xl border-b-4 border-blue-700 hover:bg-blue-400">Resume</button>
                    <button onClick={onRestart} className="px-6 py-3 bg-gray-500 rounded-lg text-xl border-b-4 border-gray-700 hover:bg-gray-400">Restart</button>
                </div>
            </>
        )}
        {gameState === 'gameOver' && (
            <>
                <h1 className="text-4xl font-bold text-red-500">Game Over</h1>
                <p className="text-2xl mt-2">Final Score: {score}</p>
                <button onClick={onRestart} className="mt-6 px-6 py-3 bg-blue-500 rounded-lg text-xl border-b-4 border-blue-700 hover:bg-blue-400">Try Again</button>
            </>
        )}
        {gameState === 'won' && (
            <>
                <h1 className="text-4xl font-bold text-yellow-400">You Win!</h1>
                <p className="text-2xl mt-2">Final Score: {score}</p>
                <button onClick={onRestart} className="mt-6 px-6 py-3 bg-blue-500 rounded-lg text-xl border-b-4 border-blue-700 hover:bg-blue-400">Play Again</button>
            </>
        )}
    </div>
);

export const BrickBreakerApp: React.FC<AppProps> = () => {
    const { addCoins } = useSettings();
    const [gameState, setGameState] = useState<GameState>('menu');
    const paddleX = useRef(GAME_WIDTH / 2 - PADDLE_WIDTH / 2);
    const ball = useRef({ x: GAME_WIDTH / 2, y: GAME_HEIGHT - 50, dx: 3, dy: -3 });
    const [bricks, setBricks] = useState<({ x: number, y: number, alive: boolean })[]>([]);
    const [score, setScore] = useState(0);
    const [lives, setLives] = useState(3);

    const resetGame = useCallback(() => {
        paddleX.current = GAME_WIDTH / 2 - PADDLE_WIDTH / 2;
        ball.current = { x: GAME_WIDTH / 2, y: GAME_HEIGHT - 50, dx: 3, dy: -3 };
        const newBricks = [];
        for (let r = 0; r < BRICK_ROWS; r++) {
            for (let c = 0; c < BRICK_COLS; c++) {
                newBricks.push({ x: c * (BRICK_WIDTH + 5) + 30, y: r * (BRICK_HEIGHT + 5) + 30, alive: true });
            }
        }
        setBricks(newBricks);
        setScore(0);
        setLives(3);
    }, []);

    const startGame = () => {
        resetGame();
        setGameState('playing');
    };

    const gameLoop = useCallback(() => {
        if (gameState !== 'playing') return;

        // Ball movement
        ball.current.x += ball.current.dx;
        ball.current.y += ball.current.dy;

        // Wall collision
        if (ball.current.x + BALL_RADIUS > GAME_WIDTH || ball.current.x - BALL_RADIUS < 0) ball.current.dx *= -1;
        if (ball.current.y - BALL_RADIUS < 0) ball.current.dy *= -1;

        // Paddle collision
        if (ball.current.y + BALL_RADIUS > GAME_HEIGHT - PADDLE_HEIGHT && ball.current.x > paddleX.current && ball.current.x < paddleX.current + PADDLE_WIDTH) {
            ball.current.dy *= -1;
        }

        // Bottom wall (lose life)
        if (ball.current.y + BALL_RADIUS > GAME_HEIGHT) {
            setLives(l => l - 1);
            if (lives - 1 <= 0) {
                setGameState('gameOver');
                addCoins(Math.floor(score / 10));
            } else {
                ball.current = { x: GAME_WIDTH / 2, y: GAME_HEIGHT - 50, dx: 3, dy: -3 };
            }
        }

        // Brick collision
        setBricks(prevBricks => {
            const newBricks = [...prevBricks];
            let changed = false;
            for (const brick of newBricks) {
                if (brick.alive && ball.current.x > brick.x && ball.current.x < brick.x + BRICK_WIDTH && ball.current.y > brick.y && ball.current.y < brick.y + BRICK_HEIGHT) {
                    ball.current.dy *= -1;
                    brick.alive = false;
                    setScore(s => s + 10);
                    changed = true;
                }
            }
            if (newBricks.every(b => !b.alive)) {
                setGameState('won');
                addCoins(Math.floor(score / 10) + 50); // Win bonus
            }
            return changed ? newBricks : prevBricks;
        });

        // Force re-render
        if(canvasRef.current) {
            const ctx = canvasRef.current.getContext('2d');
            draw(ctx!);
        }
        requestAnimationFrame(gameLoop);
    }, [gameState, lives, score, addCoins]);

    const canvasRef = useRef<HTMLCanvasElement>(null);

    const draw = (ctx: CanvasRenderingContext2D) => {
        ctx.clearRect(0, 0, GAME_WIDTH, GAME_HEIGHT);
        // Draw paddle
        ctx.fillStyle = '#0095DD';
        ctx.fillRect(paddleX.current, GAME_HEIGHT - PADDLE_HEIGHT, PADDLE_WIDTH, PADDLE_HEIGHT);
        // Draw ball
        ctx.beginPath();
        ctx.arc(ball.current.x, ball.current.y, BALL_RADIUS, 0, Math.PI * 2);
        ctx.fillStyle = '#0095DD';
        ctx.fill();
        ctx.closePath();
        // Draw bricks
        bricks.forEach(brick => {
            if (brick.alive) {
                ctx.beginPath();
                ctx.rect(brick.x, brick.y, BRICK_WIDTH, BRICK_HEIGHT);
                ctx.fillStyle = '#DD9500';
                ctx.fill();
                ctx.closePath();
            }
        });
    };

    useEffect(() => {
        const canvas = canvasRef.current;
        const ctx = canvas?.getContext('2d');
        if (!ctx) return;
        
        const handleMouseMove = (e: MouseEvent) => {
            const rect = canvas.getBoundingClientRect();
            const relativeX = e.clientX - rect.left;
            if (relativeX > 0 && relativeX < GAME_WIDTH) {
                paddleX.current = Math.min(relativeX - PADDLE_WIDTH / 2, GAME_WIDTH - PADDLE_WIDTH);
            }
        };

        const handleKeyDown = (e: KeyboardEvent) => {
            if (e.key === 'Escape') {
                setGameState(gs => gs === 'playing' ? 'paused' : 'playing');
            }
        };

        window.addEventListener('keydown', handleKeyDown);
        canvas.addEventListener('mousemove', handleMouseMove);
        
        const animationFrameId = requestAnimationFrame(gameLoop);

        return () => {
            cancelAnimationFrame(animationFrameId);
            window.removeEventListener('keydown', handleKeyDown);
            canvas?.removeEventListener('mousemove', handleMouseMove);
        };
    }, [gameLoop]);


    return (
        <div className="w-full h-full bg-gray-900 flex flex-col items-center justify-center select-none">
            <div className="flex justify-between w-full max-w-[560px] text-white p-2 font-mono">
                <span>Score: {score}</span>
                <span>Lives: {'❤️'.repeat(lives)}</span>
            </div>
            <div className="relative">
                 {gameState !== 'playing' && <GameOverlay gameState={gameState} score={score} onStart={startGame} onResume={() => setGameState('playing')} onRestart={startGame}/>}
                <canvas ref={canvasRef} width={GAME_WIDTH} height={GAME_HEIGHT} className="bg-black" />
            </div>
        </div>
    );
};
