import React, { useState, useEffect, useCallback } from 'react';
import type { AppProps } from '../../types';

const BOARD_SIZE = 21;
const CELL_SIZE = 20;

// 0: empty, 1: wall, 2: pellet, 3: power pellet
const MAZE_LAYOUT = [
  [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
  [1,2,2,2,2,2,2,2,2,2,1,2,2,2,2,2,2,2,2,2,1],
  [1,3,1,1,2,1,1,1,1,2,1,2,1,1,1,1,2,1,1,3,1],
  [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
  [1,2,1,1,2,1,2,1,1,1,1,1,1,1,2,1,2,1,1,2,1],
  [1,2,2,2,2,1,2,2,2,2,1,2,2,2,2,1,2,2,2,2,1],
  [1,1,1,1,2,1,1,1,1,0,1,0,1,1,1,1,2,1,1,1,1],
  [0,0,0,1,2,1,0,0,0,0,0,0,0,0,0,1,2,1,0,0,0],
  [1,1,1,1,2,1,0,1,1,0,0,0,1,1,0,1,2,1,1,1,1],
  [2,2,2,2,2,0,0,1,0,0,0,0,0,1,0,0,2,2,2,2,2],
  [1,1,1,1,2,1,0,1,1,1,1,1,1,1,0,1,2,1,1,1,1],
  [0,0,0,1,2,1,0,0,0,0,0,0,0,0,0,1,2,1,0,0,0],
  [1,1,1,1,2,1,0,1,1,1,1,1,1,1,0,1,2,1,1,1,1],
  [1,2,2,2,2,2,2,2,2,2,1,2,2,2,2,2,2,2,2,2,1],
  [1,2,1,1,2,1,1,1,1,2,1,2,1,1,1,1,2,1,1,2,1],
  [1,3,2,2,2,2,2,1,2,2,2,2,2,1,2,2,2,2,2,3,1],
  [1,1,2,1,1,2,1,1,2,1,1,1,2,1,1,2,1,1,2,1,1],
  [1,2,2,2,1,2,2,2,2,2,1,2,2,2,2,2,1,2,2,2,1],
  [1,2,1,2,2,2,1,1,1,2,1,2,1,1,1,2,2,2,1,2,1],
  [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
  [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
];

type Position = { x: number; y: number };
type Direction = 'UP' | 'DOWN' | 'LEFT' | 'RIGHT' | 'STOP';

export const PacManApp: React.FC<AppProps> = () => {
  const [board, setBoard] = useState(MAZE_LAYOUT);
  const [pacman, setPacman] = useState<Position>({ x: 10, y: 17 });
  const [direction, setDirection] = useState<Direction>('STOP');
  const [score, setScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);

  const move = useCallback(() => {
    if (gameOver) return;

    let { x, y } = pacman;
    let newX = x, newY = y;
    if (direction === 'LEFT') newX--;
    if (direction === 'RIGHT') newX++;
    if (direction === 'UP') newY--;
    if (direction === 'DOWN') newY++;

    // Teleportation tunnels
    if(newX < 0) newX = BOARD_SIZE -1;
    if(newX >= BOARD_SIZE) newX = 0;

    if (board[newY] && board[newY][newX] !== 1) {
      setPacman({ x: newX, y: newY });
      const newBoard = [...board];
      if (newBoard[newY][newX] === 2) {
        newBoard[newY][newX] = 0;
        setScore(s => s + 10);
        setBoard(newBoard);
      } else if (newBoard[newY][newX] === 3) {
        newBoard[newY][newX] = 0;
        setScore(s => s + 50);
        setBoard(newBoard);
      }
    }
  }, [pacman, direction, board, gameOver]);
  
  useEffect(() => {
      const handleKeyDown = (e: KeyboardEvent) => {
          e.preventDefault();
          switch(e.key) {
              case 'ArrowUp': setDirection('UP'); break;
              case 'ArrowDown': setDirection('DOWN'); break;
              case 'ArrowLeft': setDirection('LEFT'); break;
              case 'ArrowRight': setDirection('RIGHT'); break;
          }
      }
      window.addEventListener('keydown', handleKeyDown);
      return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  useEffect(() => {
    const gameInterval = setInterval(move, 200);
    return () => clearInterval(gameInterval);
  }, [move]);

  const getCell = (cellType: number) => {
      switch(cellType) {
          case 1: return <div className="w-full h-full bg-blue-700"></div>;
          case 2: return <div className="w-full h-full flex items-center justify-center"><div className="w-2 h-2 bg-yellow-200 rounded-full"></div></div>;
          case 3: return <div className="w-full h-full flex items-center justify-center"><div className="w-3 h-3 bg-yellow-200 rounded-full animate-pulse"></div></div>;
          default: return <div className="w-full h-full bg-black"></div>;
      }
  };

  return (
    <div className="w-full h-full bg-black flex flex-col items-center justify-center p-4 text-white font-mono select-none">
      <div className="w-full max-w-md flex justify-between mb-2">
        <span>SCORE: {score}</span>
        <span>LIVES: 3</span>
      </div>
      <div className="relative bg-black" style={{ width: BOARD_SIZE * CELL_SIZE, height: BOARD_SIZE * CELL_SIZE }}>
        <div className="grid" style={{ gridTemplateColumns: `repeat(${BOARD_SIZE}, 1fr)`}}>
          {board.map((row, y) => row.map((cell, x) => (
            <div key={`${y}-${x}`} style={{ width: CELL_SIZE, height: CELL_SIZE }}>{getCell(cell)}</div>
          )))}
        </div>
        <div className="absolute w-5 h-5 bg-yellow-400 rounded-full" style={{ left: pacman.x * CELL_SIZE, top: pacman.y * CELL_SIZE }} />
      </div>
    </div>
  );
};
