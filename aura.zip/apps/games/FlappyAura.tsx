import React, { useState, useEffect, useRef, useCallback } from 'react';
import type { AppProps, GameState } from '../../types';
import { useSettings } from '../../context/SettingsContext';

const GAME_WIDTH = 400;
const GAME_HEIGHT = 540;
const BIRD_SIZE = 35;
const GRAVITY = 0.5;
const JUMP_FORCE = -8;
const PIPE_WIDTH = 60;
const PIPE_GAP = 150;
const PIPE_SPEED = 2.5;

const AuraBirdIcon = () => <svg viewBox="0 0 100 100" className="w-full h-full"><radialGradient id="a_flappy" cx="33.84" cy="133.74" r="77.93" gradientTransform="matrix(1 0 0 .67 -2.57 -39.23)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#28c4f0"></stop><stop offset=".24" stop-color="#21bade"></stop><stop offset=".62" stop-color="#14a3be"></stop><stop offset=".88" stop-color="#0e97ab"></stop><stop offset="1" stop-color="#0c94a6"></stop></radialGradient><radialGradient id="b_flappy" cx="66.16" cy="133.74" r="77.93" gradientTransform="matrix(1 0 0 .67 -2.57 -39.23)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#d4349c"></stop><stop offset=".3" stop-color="#c93399"></stop><stop offset=".71" stop-color="#b23192"></stop><stop offset="1" stop-color="#a5308e"></stop></radialGradient><radialGradient id="c_flappy" cx="49.33" cy="116.03" r="79.91" gradientTransform="matrix(1 0 0 .67 -2.57 -39.23)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#a5308e"></stop><stop offset=".35" stop-color="#792e92"></stop><stop offset=".65" stop-color="#562c96"></stop><stop offset="1" stop-color="#3b2b99"></stop></radialGradient><path fill="url(#a_flappy)" d="M72.5,50A22.5,22.5,0,0,1,50,72.5V50Z"></path><path fill="url(#b_flappy)" d="M50,27.5A22.5,22.5,0,0,1,72.5,50H50Z"></path><path fill="url(#c_flappy)" d="M27.5,50A22.5,22.5,0,0,1,50,27.5V50Z"></path><path fill="#0c94a6" d="M50,72.5A22.5,22.5,0,0,1,27.5,50H50Z"></path></svg>;

const GameOverlay: React.FC<{ gameState: GameState; score: number; onStart: () => void; onRestart: () => void; }> = ({ gameState, score, onStart, onRestart }) => (
    <div className="absolute inset-0 bg-black/50 flex flex-col items-center justify-center text-center text-white font-bold p-4 rounded-lg z-10">
        {gameState === 'menu' && (
             <>
                <h1 className="text-5xl" style={{WebkitTextStroke: '2px black'}}>Flappy Aura</h1>
                <p className="mt-4" style={{textShadow: '2px 2px 4px #00000080'}}>Click or Press Space to Jump</p>
                <button onClick={(e) => { e.stopPropagation(); onStart(); }} className="mt-6 px-6 py-3 bg-green-500 rounded-lg text-xl border-b-4 border-green-700 hover:bg-green-400">Start Game</button>
            </>
        )}
        {gameState === 'gameOver' && (
            <>
                <h2 className="text-5xl" style={{WebkitTextStroke: '2px black'}}>Game Over</h2>
                <p className="text-3xl mt-2" style={{WebkitTextStroke: '1px black'}}>Score: {score}</p>
                <button onClick={(e) => { e.stopPropagation(); onRestart(); }} className="mt-6 px-6 py-3 bg-blue-500 rounded-lg text-xl border-b-4 border-blue-700 hover:bg-blue-400">Try Again</button>
            </>
        )}
    </div>
);


export const FlappyAuraApp: React.FC<AppProps> = () => {
  const { addCoins } = useSettings();
  const [birdPos, setBirdPos] = useState(GAME_HEIGHT / 2);
  const [birdVel, setBirdVel] = useState(0);
  const [pipes, setPipes] = useState<{x: number, topHeight: number, scored?: boolean}[]>([]);
  const [score, setScore] = useState(0);
  const [gameState, setGameState] = useState<GameState>('menu');
  
  const gameLoopRef = useRef<number | null>(null);

  const resetGame = useCallback(() => {
    setBirdPos(GAME_HEIGHT / 2);
    setBirdVel(0);
    setPipes([]);
    setScore(0);
    setGameState('menu');
  }, []);
  
  const startGame = useCallback(() => {
    setGameState('playing');
    setBirdVel(JUMP_FORCE);
    setPipes([{ x: GAME_WIDTH, topHeight: Math.random() * (GAME_HEIGHT - PIPE_GAP - 100) + 50 }]);
  }, []);

  const jump = useCallback(() => {
    if (gameState === 'playing') {
      setBirdVel(JUMP_FORCE);
    }
  }, [gameState]);

  const gameLoop = useCallback(() => {
    // Bird physics
    let newBirdVel = birdVel + GRAVITY;
    let newBirdPos = birdPos + newBirdVel;
    setBirdVel(newBirdVel);
    setBirdPos(newBirdPos);

    // Ground and ceiling collision
    if (newBirdPos > GAME_HEIGHT - BIRD_SIZE || newBirdPos < 0) {
      setGameState('gameOver');
      addCoins(score);
      return;
    }

    // Pipe logic
    const newPipes = pipes.map(pipe => ({ ...pipe, x: pipe.x - PIPE_SPEED })).filter(pipe => pipe.x > -PIPE_WIDTH);
    
    // Add new pipe
    const lastPipe = newPipes[newPipes.length - 1];
    if (newPipes.length === 0 || lastPipe.x < GAME_WIDTH - 220) {
        newPipes.push({ x: GAME_WIDTH, topHeight: Math.random() * (GAME_HEIGHT - PIPE_GAP - 150) + 75 });
    }
    
    // Check collision with the first relevant pipe
    const currentPipe = newPipes.find(p => p.x + PIPE_WIDTH > 50 && p.x < 50 + BIRD_SIZE);
    if (currentPipe) {
        const birdTop = newBirdPos;
        const birdBottom = newBirdPos + BIRD_SIZE;
        if (birdTop < currentPipe.topHeight || birdBottom > currentPipe.topHeight + PIPE_GAP) {
            setGameState('gameOver');
            addCoins(score);
        }
    }
    
    // Score
    const pipeToScore = newPipes.find(p => !p.scored && p.x + PIPE_WIDTH < 50);
    if (pipeToScore) {
      setScore(s => s + 1);
      pipeToScore.scored = true;
    }

    setPipes(newPipes);
    gameLoopRef.current = requestAnimationFrame(gameLoop);
  }, [birdVel, birdPos, pipes, score, addCoins]);

  useEffect(() => {
    if (gameState === 'playing') {
      gameLoopRef.current = requestAnimationFrame(gameLoop);
    } else {
        if(gameLoopRef.current) cancelAnimationFrame(gameLoopRef.current);
    }
    return () => {
      if (gameLoopRef.current) cancelAnimationFrame(gameLoopRef.current);
    };
  }, [gameState, gameLoop]);

   useEffect(() => {
        const handleInteraction = (e: Event) => {
            if (e instanceof KeyboardEvent && e.key !== ' ' && e.key !== 'Enter') return;
            e.preventDefault();
            if (gameState === 'playing') {
                jump();
            } else if (gameState === 'menu') {
                startGame();
            } else if (gameState === 'gameOver') {
                resetGame();
            }
        };

        window.addEventListener('keydown', handleInteraction);
        const gameContainer = document.getElementById(`flappy-aura-container`);
        gameContainer?.addEventListener('click', handleInteraction);

        return () => {
            window.removeEventListener('keydown', handleInteraction);
            gameContainer?.removeEventListener('click', handleInteraction);
        };
  }, [gameState, jump, startGame, resetGame]);
  
  return (
    <div id="flappy-aura-container" className="w-full h-full flex items-center justify-center bg-cyan-400 select-none">
      <div className="relative overflow-hidden bg-cyan-400" style={{ width: GAME_WIDTH, height: GAME_HEIGHT, background: 'linear-gradient(to bottom, #87ceeb, #f0f8ff)' }}>
        
        {gameState !== 'playing' && <GameOverlay gameState={gameState} score={score} onStart={startGame} onRestart={resetGame} />}

        {/* Bird */}
        <div style={{ top: birdPos, left: 50, width: BIRD_SIZE, height: BIRD_SIZE, transition: 'transform 0.1s linear', transform: `rotate(${Math.min(90, Math.max(-30, birdVel * 4))}deg)` }} className="absolute drop-shadow-lg">
          <AuraBirdIcon />
        </div>
        
        {/* Pipes */}
        {pipes.map((pipe, i) => (
          <React.Fragment key={i}>
            <div style={{ left: pipe.x, top: 0, height: pipe.topHeight, width: PIPE_WIDTH }} className="absolute bg-green-500 border-2 border-green-700 rounded-t-lg" />
            <div style={{ left: pipe.x, top: pipe.topHeight + PIPE_GAP, height: GAME_HEIGHT - pipe.topHeight - PIPE_GAP, width: PIPE_WIDTH }} className="absolute bg-green-500 border-2 border-green-700 rounded-b-lg" />
          </React.Fragment>
        ))}
        
        <div className="absolute top-10 left-1/2 -translate-x-1/2 text-white text-6xl font-black" style={{WebkitTextStroke: '2px black'}}>{score}</div>
      </div>
    </div>
  );
};
