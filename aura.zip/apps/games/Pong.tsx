import React, { useState, useEffect, useRef, useCallback } from 'react';
import type { AppProps, GameState } from '../../types';
import { useSettings } from '../../context/SettingsContext';

const GAME_WIDTH = 600;
const GAME_HEIGHT = 460;
const PADDLE_WIDTH = 15;
const PADDLE_HEIGHT = 80;
const BALL_SIZE = 15;
const WINNING_SCORE = 5;

const GameOverlay: React.FC<{ gameState: GameState; scores: { player: number, ai: number }; onStart: () => void; onResume: () => void; onRestart: () => void; }> = ({ gameState, scores, onStart, onResume, onRestart }) => (
    <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center text-white font-mono z-10">
        {gameState === 'menu' && (
            <>
                <h1 className="text-4xl font-bold">Pong</h1>
                <button onClick={onStart} className="mt-6 px-6 py-3 bg-green-500 rounded-lg text-xl border-b-4 border-green-700 hover:bg-green-400">Start Game</button>
            </>
        )}
        {gameState === 'paused' && (
            <>
                <h1 className="text-4xl font-bold">Paused</h1>
                <div className="flex gap-4 mt-6">
                    <button onClick={onResume} className="px-6 py-3 bg-blue-500 rounded-lg text-xl border-b-4 border-blue-700 hover:bg-blue-400">Resume</button>
                    <button onClick={onRestart} className="px-6 py-3 bg-gray-500 rounded-lg text-xl border-b-4 border-gray-700 hover:bg-gray-400">Restart</button>
                </div>
            </>
        )}
        {gameState === 'gameOver' && (
            <>
                <h1 className="text-4xl font-bold text-red-500">{scores.player === WINNING_SCORE ? 'You Win!' : 'You Lose!'}</h1>
                <p className="text-2xl mt-2">Final Score: {scores.player} - {scores.ai}</p>
                <button onClick={onRestart} className="mt-6 px-6 py-3 bg-blue-500 rounded-lg text-xl border-b-4 border-blue-700 hover:bg-blue-400">Play Again</button>
            </>
        )}
    </div>
);

export const PongApp: React.FC<AppProps> = () => {
    const { addCoins } = useSettings();
    const [gameState, setGameState] = useState<GameState>('menu');
    const playerY = useRef(GAME_HEIGHT / 2 - PADDLE_HEIGHT / 2);
    const aiY = useRef(GAME_HEIGHT / 2 - PADDLE_HEIGHT / 2);
    const ball = useRef({ x: GAME_WIDTH / 2, y: GAME_HEIGHT / 2, dx: 5, dy: 5 });
    const [scores, setScores] = useState({ player: 0, ai: 0 });

    const resetBall = (direction: 1 | -1 = 1) => {
        ball.current = {
            x: GAME_WIDTH / 2,
            y: GAME_HEIGHT / 2,
            dx: 5 * direction,
            dy: (Math.random() > 0.5 ? 1 : -1) * (Math.random() * 3 + 2)
        };
    };

    const resetGame = () => {
        setScores({ player: 0, ai: 0 });
        resetBall();
    };

    const startGame = () => {
        resetGame();
        setGameState('playing');
    };

    const gameLoop = useCallback(() => {
        if (gameState !== 'playing') return;

        // Ball movement
        ball.current.x += ball.current.dx;
        ball.current.y += ball.current.dy;

        // Wall collision (top/bottom)
        if (ball.current.y <= 0 || ball.current.y >= GAME_HEIGHT - BALL_SIZE) {
            ball.current.dy *= -1;
        }

        // Paddle collision
        // Player
        if (ball.current.x <= PADDLE_WIDTH && ball.current.y > playerY.current && ball.current.y < playerY.current + PADDLE_HEIGHT) {
            ball.current.dx *= -1;
        }
        // AI
        if (ball.current.x >= GAME_WIDTH - PADDLE_WIDTH - BALL_SIZE && ball.current.y > aiY.current && ball.current.y < aiY.current + PADDLE_HEIGHT) {
            ball.current.dx *= -1;
        }

        // Score
        if (ball.current.x < 0) {
            setScores(s => ({ ...s, ai: s.ai + 1 }));
            resetBall(1);
        } else if (ball.current.x > GAME_WIDTH) {
            setScores(s => ({ ...s, player: s.player + 1 }));
            resetBall(-1);
        }
        
        // AI Movement
        aiY.current += (ball.current.y - (aiY.current + PADDLE_HEIGHT / 2)) * 0.1;
        aiY.current = Math.max(0, Math.min(aiY.current, GAME_HEIGHT - PADDLE_HEIGHT));

        // Win condition
        if (scores.player >= WINNING_SCORE || scores.ai >= WINNING_SCORE) {
            setGameState('gameOver');
            if(scores.player >= WINNING_SCORE) addCoins(25);
        }
        
        // Force re-render
        if(canvasRef.current) {
            const ctx = canvasRef.current.getContext('2d');
            draw(ctx!);
        }
        requestAnimationFrame(gameLoop);
    }, [gameState, scores, addCoins]);

    const canvasRef = useRef<HTMLCanvasElement>(null);

    const draw = (ctx: CanvasRenderingContext2D) => {
        ctx.clearRect(0, 0, GAME_WIDTH, GAME_HEIGHT);
        ctx.fillStyle = 'white';
        // Player
        ctx.fillRect(0, playerY.current, PADDLE_WIDTH, PADDLE_HEIGHT);
        // AI
        ctx.fillRect(GAME_WIDTH - PADDLE_WIDTH, aiY.current, PADDLE_WIDTH, PADDLE_HEIGHT);
        // Ball
        ctx.fillRect(ball.current.x, ball.current.y, BALL_SIZE, BALL_SIZE);
        // Center line
        ctx.setLineDash([10, 10]);
        ctx.beginPath();
        ctx.moveTo(GAME_WIDTH / 2, 0);
        ctx.lineTo(GAME_WIDTH / 2, GAME_HEIGHT);
        ctx.strokeStyle = 'white';
        ctx.stroke();
    };

    useEffect(() => {
        const canvas = canvasRef.current;
        const ctx = canvas?.getContext('2d');
        if (!ctx) return;

        const handleMouseMove = (e: MouseEvent) => {
            const rect = canvas.getBoundingClientRect();
            playerY.current = e.clientY - rect.top - PADDLE_HEIGHT / 2;
            playerY.current = Math.max(0, Math.min(playerY.current, GAME_HEIGHT - PADDLE_HEIGHT));
        };
        
         const handleKeyDown = (e: KeyboardEvent) => {
            if (e.key === 'Escape') {
                setGameState(gs => gs === 'playing' ? 'paused' : 'playing');
            }
        };

        window.addEventListener('keydown', handleKeyDown);
        canvas.addEventListener('mousemove', handleMouseMove);
        const animationFrameId = requestAnimationFrame(gameLoop);

        return () => {
            cancelAnimationFrame(animationFrameId);
            window.removeEventListener('keydown', handleKeyDown);
            canvas?.removeEventListener('mousemove', handleMouseMove);
        };
    }, [gameLoop]);

    return (
        <div className="w-full h-full bg-gray-900 flex flex-col items-center justify-center select-none">
            <div className="flex justify-around w-full max-w-[600px] text-white text-4xl p-2 font-mono">
                <span>{scores.player}</span>
                <span>{scores.ai}</span>
            </div>
            <div className="relative">
                {gameState !== 'playing' && <GameOverlay gameState={gameState} scores={scores} onStart={startGame} onResume={() => setGameState('playing')} onRestart={startGame} />}
                <canvas ref={canvasRef} width={GAME_WIDTH} height={GAME_HEIGHT} className="bg-black" />
            </div>
        </div>
    );
};
