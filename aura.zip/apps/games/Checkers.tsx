import React, { useState } from 'react';
import type { AppProps } from '../../types';

type Player = 'red' | 'black';
type Piece = { player: Player; isKing: boolean };
type Square = Piece | null;
type Board = Square[][];

const createBoard = (): Board => {
    const board = Array.from({ length: 8 }, () => Array(8).fill(null));
    for (let r = 0; r < 8; r++) {
        for (let c = 0; c < 8; c++) {
            if ((r + c) % 2 !== 0) { // Dark squares
                if (r < 3) board[r][c] = { player: 'black', isKing: false };
                else if (r > 4) board[r][c] = { player: 'red', isKing: false };
            }
        }
    }
    return board;
};

export const CheckersApp: React.FC<AppProps> = () => {
    const [board, setBoard] = useState<Board>(() => createBoard());
    const [turn, setTurn] = useState<Player>('red');
    const [selected, setSelected] = useState<{ r: number; c: number } | null>(null);

    // Basic move logic, no capture enforcement for simplicity
    const handleSquareClick = (r: number, c: number) => {
        if (selected) {
            const piece = board[selected.r][selected.c];
            if (piece?.player === turn && !board[r][c]) {
                const dy = r - selected.r;
                const dx = Math.abs(c - selected.c);
                const moveDir = turn === 'red' ? -1 : 1;
                
                // Regular move
                if(dx === 1 && dy === moveDir) {
                    const newBoard = board.map(row => [...row]);
                    newBoard[r][c] = newBoard[selected.r][selected.c];
                    newBoard[selected.r][selected.c] = null;
                    if ((turn === 'red' && r === 0) || (turn === 'black' && r === 7)) {
                        newBoard[r][c]!.isKing = true;
                    }
                    setBoard(newBoard);
                    setTurn(t => t === 'red' ? 'black' : 'red');
                    setSelected(null);
                }
            }
            setSelected(null);
        } else {
            if (board[r][c] && board[r][c]?.player === turn) {
                setSelected({ r, c });
            }
        }
    };
    
    return (
        <div className="w-full h-full bg-gray-700 flex flex-col items-center justify-center p-4">
            <h1 className="text-2xl font-bold text-white mb-4">Checkers - {turn.charAt(0).toUpperCase() + turn.slice(1)}'s Turn</h1>
            <div className="grid grid-cols-8 border-4 border-gray-900">
                {board.map((row, r) => row.map((square, c) => (
                    <div key={`${r}-${c}`} onClick={() => handleSquareClick(r, c)}
                        className={`w-12 h-12 flex items-center justify-center
                            ${(r + c) % 2 === 0 ? 'bg-gray-300' : 'bg-gray-800'}
                            ${selected && selected.r === r && selected.c === c ? 'ring-2 ring-yellow-400' : ''}`}
                    >
                        {square && (
                            <div className={`w-10 h-10 rounded-full flex items-center justify-center text-yellow-400 text-lg
                                ${square.player === 'red' ? 'bg-red-600 border-2 border-red-800' : 'bg-black border-2 border-gray-600'}
                            `}>
                                {square.isKing && '👑'}
                            </div>
                        )}
                    </div>
                )))}
            </div>
            <button onClick={() => setBoard(createBoard())} className="mt-4 px-4 py-2 bg-blue-500 text-white rounded-md">New Game</button>
        </div>
    );
};
