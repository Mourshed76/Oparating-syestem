// This app has been replaced by the more advanced "Pixelate" app.
// See /apps/entertainment/Pixelate.tsx for the new implementation.
import React from 'react';
import type { AppProps } from '../../types';

export const DrawingPadApp: React.FC<AppProps> = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-gray-200">
            <p className="text-gray-600">This app has been upgraded to Pixelate.</p>
        </div>
    );
};
