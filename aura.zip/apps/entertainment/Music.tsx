import React, { useState, useMemo } from 'react';
import type { AppProps, MusicAlbum, MusicTrack } from '../../types';
import { faker } from '@faker-js/faker';

// --- MOCK DATA ---
const generateMusicLibrary = (count: number): MusicAlbum[] => {
    return Array.from({ length: count }, (_, i) => ({
        id: faker.string.uuid(),
        title: faker.music.songName(),
        artist: faker.person.fullName(),
        coverSeed: faker.string.uuid(),
        tracks: Array.from({ length: Math.floor(Math.random() * 8) + 5 }, (_, j) => ({
            id: faker.string.uuid(),
            title: faker.lorem.words(3),
            artist: faker.person.fullName(),
            duration: `${Math.floor(Math.random() * 4) + 2}:${String(Math.floor(Math.random() * 60)).padStart(2, '0')}`,
        })),
    }));
};

const LIBRARY = generateMusicLibrary(20);

// --- SUB-COMPONENTS ---
const AlbumCard: React.FC<{ album: MusicAlbum, onSelect: () => void }> = ({ album, onSelect }) => (
    <div onClick={onSelect} className="group cursor-pointer">
        <div className="aspect-square bg-gray-700 rounded-lg overflow-hidden">
            <img src={`https://picsum.photos/seed/${album.coverSeed}/300/300`} alt={album.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
        </div>
        <h3 className="font-semibold mt-2 truncate">{album.title}</h3>
        <p className="text-sm text-gray-400 truncate">{album.artist}</p>
    </div>
);

const TrackRow: React.FC<{ track: MusicTrack, index: number, onPlay: () => void }> = ({ track, index, onPlay }) => (
    <button onClick={onPlay} className="w-full grid grid-cols-[20px_1fr_1fr_auto] items-center gap-4 p-2 rounded-md hover:bg-white/10 text-left">
        <span className="text-gray-400">{index + 1}</span>
        <span className="truncate">{track.title}</span>
        <span className="text-gray-400 truncate">{track.artist}</span>
        <span className="text-gray-400">{track.duration}</span>
    </button>
);

const PlayerBar: React.FC<{ track: MusicTrack | null, album: MusicAlbum | null }> = ({ track, album }) => {
    if (!track || !album) return null;
    return (
        <footer className="h-20 bg-gray-900/80 backdrop-blur-lg border-t border-white/10 p-3 flex items-center gap-4">
            <img src={`https://picsum.photos/seed/${album.coverSeed}/100/100`} alt={album.title} className="w-14 h-14 rounded"/>
            <div className="flex-grow">
                <p className="font-semibold">{track.title}</p>
                <p className="text-sm text-gray-400">{album.artist}</p>
            </div>
            <div className="flex items-center gap-4 text-2xl">
                <span>⏮️</span>
                <span className="text-4xl">▶️</span>
                <span>⏭️</span>
            </div>
        </footer>
    );
};

// --- MAIN APP ---
export const MusicApp: React.FC<AppProps> = () => {
    const [view, setView] = useState<'library' | 'album'>('library');
    const [selectedAlbum, setSelectedAlbum] = useState<MusicAlbum | null>(null);
    const [nowPlaying, setNowPlaying] = useState<{ track: MusicTrack, album: MusicAlbum } | null>(null);

    const handleSelectAlbum = (album: MusicAlbum) => {
        setSelectedAlbum(album);
        setView('album');
    };

    return (
        <div className="w-full h-full flex bg-[#121212] text-white">
            <aside className="w-56 bg-black/50 p-4 shrink-0">
                <h1 className="text-xl font-bold mb-6">Music</h1>
                <nav className="space-y-2">
                    <button onClick={() => setView('library')} className="w-full p-2 rounded text-left bg-white/10 font-semibold">Library</button>
                </nav>
            </aside>
            <main className="flex-grow flex flex-col">
                <div className="flex-grow overflow-y-auto">
                    {view === 'library' && (
                        <div className="p-6">
                            <h2 className="text-2xl font-bold mb-4">Albums</h2>
                            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
                                {LIBRARY.map(album => <AlbumCard key={album.id} album={album} onSelect={() => handleSelectAlbum(album)} />)}
                            </div>
                        </div>
                    )}
                    {view === 'album' && selectedAlbum && (
                        <div className="p-6">
                            <div className="flex items-end gap-6 mb-6">
                                <img src={`https://picsum.photos/seed/${selectedAlbum.coverSeed}/200/200`} alt={selectedAlbum.title} className="w-48 h-48 rounded-lg shadow-2xl"/>
                                <div>
                                    <p className="text-sm">ALBUM</p>
                                    <h2 className="text-5xl font-extrabold">{selectedAlbum.title}</h2>
                                    <p className="text-lg text-gray-300 mt-2">{selectedAlbum.artist}</p>
                                </div>
                            </div>
                            <div className="space-y-1">
                                {selectedAlbum.tracks.map((track, index) => (
                                    <TrackRow key={track.id} track={track} index={index} onPlay={() => setNowPlaying({ track, album: selectedAlbum })}/>
                                ))}
                            </div>
                        </div>
                    )}
                </div>
                <PlayerBar track={nowPlaying?.track || null} album={nowPlaying?.album || null} />
            </main>
        </div>
    );
};
