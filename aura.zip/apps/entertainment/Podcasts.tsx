import React, { useState } from 'react';
import type { AppProps, MusicAlbum, MusicTrack } from '../../types'; // Re-using Music types for simplicity
import { faker } from '@faker-js/faker';

// MOCK DATA
const generatePodcastLibrary = (count: number): MusicAlbum[] => {
    return Array.from({ length: count }, () => ({
        id: faker.string.uuid(),
        title: faker.lorem.words(3).replace(/\b\w/g, l => l.toUpperCase()),
        artist: faker.person.fullName(),
        coverSeed: faker.string.uuid(),
        tracks: Array.from({ length: Math.floor(Math.random() * 20) + 5 }, (_, j) => ({
            id: faker.string.uuid(),
            title: `Episode ${j + 1}: ${faker.lorem.sentence()}`,
            artist: faker.person.fullName(),
            duration: `${Math.floor(Math.random() * 50) + 10} min`,
        })),
    }));
};
const LIBRARY = generatePodcastLibrary(15);

// SUB-COMPONENTS
const PodcastCard: React.FC<{ podcast: MusicAlbum, onSelect: () => void }> = ({ podcast, onSelect }) => (
    <div onClick={onSelect} className="group cursor-pointer">
        <div className="aspect-square bg-gray-700 rounded-lg overflow-hidden">
            <img src={`https://picsum.photos/seed/${podcast.coverSeed}/300/300`} alt={podcast.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
        </div>
        <h3 className="font-semibold mt-2 truncate">{podcast.title}</h3>
        <p className="text-sm text-gray-400 truncate">{podcast.artist}</p>
    </div>
);

const EpisodeRow: React.FC<{ episode: MusicTrack, onPlay: () => void }> = ({ episode, onPlay }) => (
    <button onClick={onPlay} className="w-full flex items-center gap-4 p-3 border-b border-purple-300/10 hover:bg-white/5">
        <div className="w-8 h-8 rounded bg-purple-500 flex items-center justify-center font-bold text-sm flex-shrink-0">▶</div>
        <div className="flex-grow text-left">
            <p className="font-semibold">{episode.title}</p>
            <p className="text-xs text-gray-400">{new Date().toLocaleDateString()}</p>
        </div>
        <span className="text-sm text-gray-400">{episode.duration}</span>
    </button>
);

// MAIN APP
export const PodcastsApp: React.FC<AppProps> = () => {
    const [selectedPodcast, setSelectedPodcast] = useState<MusicAlbum | null>(LIBRARY[0]);

    return (
        <div className="w-full h-full flex bg-[#2c1a4d] text-white">
            <aside className="w-1/3 max-w-xs bg-black/20 p-4 shrink-0 overflow-y-auto">
                <h2 className="text-xl font-bold mb-4">Podcasts</h2>
                <div className="space-y-4">
                    {LIBRARY.map(podcast => (
                        <div key={podcast.id} onClick={() => setSelectedPodcast(podcast)} className={`flex items-center gap-3 p-2 rounded-lg cursor-pointer ${selectedPodcast?.id === podcast.id ? 'bg-purple-500/30' : 'hover:bg-white/10'}`}>
                            <img src={`https://picsum.photos/seed/${podcast.coverSeed}/100/100`} alt={podcast.title} className="w-12 h-12 rounded-md" />
                            <div className="overflow-hidden">
                                <p className="font-semibold truncate">{podcast.title}</p>
                                <p className="text-xs text-gray-400 truncate">{podcast.artist}</p>
                            </div>
                        </div>
                    ))}
                </div>
            </aside>
            <main className="flex-grow flex flex-col">
                {selectedPodcast ? (
                    <div className="flex-grow overflow-y-auto p-6">
                        <h1 className="text-3xl font-bold">{selectedPodcast.title}</h1>
                        <p className="text-gray-300 mb-4">{selectedPodcast.artist}</p>
                        <div className="space-y-2">
                             {selectedPodcast.tracks.map(track => <EpisodeRow key={track.id} episode={track} onPlay={() => {}} />)}
                        </div>
                    </div>
                ) : (
                    <div className="flex-grow flex items-center justify-center text-gray-400">Select a podcast to view episodes.</div>
                )}
            </main>
        </div>
    );
};
