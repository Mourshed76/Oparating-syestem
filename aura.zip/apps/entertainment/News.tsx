import React from 'react';
import type { AppProps } from '../../types';

interface Article {
    id: number;
    headline: string;
    source: string;
    time: string;
    summary: string;
    imageUrl: string;
}

const mockArticles: Article[] = [
    { id: 1, headline: 'AuraOS 2.0 Unveiled with Groundbreaking AI Features', source: 'Tech Today', time: '1h ago', summary: 'The new version of AuraOS integrates generative AI at its core, promising a revolutionary user experience.', imageUrl: 'https://picsum.photos/seed/news1/400/200' },
    { id: 2, headline: 'The Rise of Web-Based Operating Systems', source: 'Future Forward', time: '3h ago', summary: 'A deep dive into how platforms like AuraOS are changing our perception of computing.', imageUrl: 'https://picsum.photos/seed/news2/400/200' },
    { id: 3, headline: 'Is This the End of Traditional Desktops?', source: 'The Verge', time: '5h ago', summary: 'With powerful browsers and cloud computing, the need for local-first operating systems is diminishing.', imageUrl: 'https://picsum.photos/seed/news3/400/200' },
    { id: 4, headline: 'New "ConnectSphere" App Aims to Redefine Social', source: 'Digital Trends', time: '1d ago', summary: 'AuraOS\'s new social app focuses on privacy and meaningful connections through AI-powered simulations.', imageUrl: 'https://picsum.photos/seed/news4/400/200' },
];

export const NewsApp: React.FC<AppProps> = () => {
    return (
        <div className="w-full h-full flex bg-gray-100">
            <aside className="w-64 h-full bg-white p-3 shrink-0 border-r border-gray-200">
                 <h2 className="text-xs font-bold text-gray-500 uppercase px-3 mb-2">Topics</h2>
                <div className="space-y-1">
                     <button className="flex items-center w-full text-left px-3 py-2 rounded-lg bg-red-500/20 text-red-700">
                        <span className="font-medium text-sm">Top Stories</span>
                    </button>
                     <button className="flex items-center w-full text-left px-3 py-2 rounded-lg hover:bg-gray-200">
                        <span className="font-medium text-sm">Technology</span>
                    </button>
                      <button className="flex items-center w-full text-left px-3 py-2 rounded-lg hover:bg-gray-200">
                        <span className="font-medium text-sm">Science</span>
                    </button>
                </div>
            </aside>
            <main className="flex-grow overflow-y-auto p-6">
                <h1 className="text-3xl font-extrabold mb-6 text-mac-text">Top Stories</h1>
                <div className="space-y-8">
                    {mockArticles.map(article => (
                        <div key={article.id} className="grid grid-cols-3 gap-6">
                            <div className="col-span-2">
                                <p className="text-xs font-bold text-gray-500 uppercase">{article.source} · {article.time}</p>
                                <h2 className="text-xl font-bold mt-1 text-mac-text hover:underline cursor-pointer">{article.headline}</h2>
                                <p className="text-mac-text-secondary mt-2">{article.summary}</p>
                            </div>
                            <div className="col-span-1">
                                <img src={article.imageUrl} alt={article.headline} className="w-full h-32 object-cover rounded-lg"/>
                            </div>
                        </div>
                    ))}
                </div>
            </main>
        </div>
    );
};
