import React from 'react';
import type { AppProps } from '../../types';

// Mock Data
const weatherData = {
  city: 'San Francisco',
  current: { temp: 18, condition: 'Partly Cloudy', icon: '⛅️', high: 21, low: 14 },
  forecast: [
    { day: 'Mon', icon: '☀️', high: 22, low: 15 },
    { day: 'Tue', icon: '☁️', high: 20, low: 14 },
    { day: 'Wed', icon: '🌧️', high: 18, low: 13 },
    { day: 'Thu', icon: '🌤️', high: 21, low: 14 },
    { day: 'Fri', icon: '☀️', high: 23, low: 16 },
  ],
};

export const WeatherApp: React.FC<AppProps> = () => {
  return (
    <div className="w-full h-full bg-gradient-to-br from-blue-400 to-indigo-600 text-white p-6 flex flex-col font-sans select-none">
      <div className="text-center">
        <h1 className="text-3xl font-bold">{weatherData.city}</h1>
        <p className="text-xl">{weatherData.current.temp}°</p>
        <p className="text-lg opacity-80">{weatherData.current.condition}</p>
      </div>

      <div className="my-8 text-center">
        <div className="text-7xl">{weatherData.current.icon}</div>
        <div className="flex justify-center gap-4 mt-2">
            <span>H: {weatherData.current.high}°</span>
            <span>L: {weatherData.current.low}°</span>
        </div>
      </div>

      <div className="mt-auto bg-white/20 backdrop-blur-lg rounded-xl p-4">
        <h2 className="text-sm uppercase opacity-80 mb-2">5-Day Forecast</h2>
        <div className="flex justify-between text-center">
          {weatherData.forecast.map(day => (
            <div key={day.day} className="flex flex-col items-center">
              <span className="font-semibold">{day.day}</span>
              <span className="text-2xl my-1">{day.icon}</span>
              <span className="font-semibold">{day.high}°</span>
              <span className="opacity-70">{day.low}°</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
