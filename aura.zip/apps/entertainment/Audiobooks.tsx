import React, { useState } from 'react';
import type { AppProps } from '../../types';
import { faker } from '@faker-js/faker';

interface Audiobook {
    id: string;
    title: string;
    author: string;
    narrator: string;
    coverSeed: string;
    duration: string;
}

// MOCK DATA
const generateLibrary = (count: number): Audiobook[] => {
    return Array.from({ length: count }, () => ({
        id: faker.string.uuid(),
        title: faker.lorem.words(3).replace(/\b\w/g, l => l.toUpperCase()),
        author: faker.person.fullName(),
        narrator: faker.person.fullName(),
        coverSeed: faker.string.uuid(),
        duration: `${Math.floor(Math.random() * 10) + 5}h ${Math.floor(Math.random() * 60)}m`,
    }));
};
const LIBRARY = generateLibrary(12);

export const AudiobooksApp: React.FC<AppProps> = () => {
    const [selectedBook, setSelectedBook] = useState<Audiobook | null>(null);

    if (selectedBook) {
        return (
            <div className="w-full h-full bg-[#333] text-white flex flex-col p-8 items-center justify-between">
                <button onClick={() => setSelectedBook(null)} className="absolute top-4 left-4 text-sm hover:underline">← Back to Library</button>
                <div className="text-center">
                    <img src={`https://picsum.photos/seed/${selectedBook.coverSeed}/400/400`} alt={selectedBook.title} className="w-64 h-64 rounded-lg shadow-2xl mx-auto" />
                    <h1 className="text-3xl font-bold mt-6">{selectedBook.title}</h1>
                    <p className="text-lg text-gray-300">{selectedBook.author}</p>
                </div>
                <div className="w-full max-w-md">
                    <div className="h-2 bg-white/20 rounded-full"><div className="w-1/3 h-full bg-white rounded-full"></div></div>
                    <div className="flex justify-between text-xs mt-1">
                        <span>1:15:30</span>
                        <span>{selectedBook.duration}</span>
                    </div>
                </div>
                <div className="flex items-center gap-8 text-4xl">
                    <button>-15s</button>
                    <button className="text-6xl">▶</button>
                    <button>+15s</button>
                </div>
            </div>
        );
    }

    return (
        <div className="w-full h-full bg-[#1e1e1e] text-white p-6 overflow-y-auto">
            <h1 className="text-3xl font-bold mb-6">Library</h1>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {LIBRARY.map(book => (
                    <div key={book.id} onClick={() => setSelectedBook(book)} className="group cursor-pointer">
                        <div className="aspect-[1/1] bg-gray-800 rounded-lg overflow-hidden">
                            <img src={`https://picsum.photos/seed/${book.coverSeed}/300/300`} alt={book.title} className="w-full h-full object-cover group-hover:opacity-80 transition-opacity" />
                        </div>
                        <h3 className="font-semibold mt-2 truncate">{book.title}</h3>
                        <p className="text-sm text-gray-400 truncate">{book.author}</p>
                    </div>
                ))}
            </div>
        </div>
    );
};
