import React, { useState, useMemo, useEffect } from 'react';
import type { AppProps, OSAction, Photo, PhotoAlbum } from '../../types';
import { useSettings } from '../../context/SettingsContext';

type View = 'grid' | 'viewer';

// --- SUB-COMPONENTS ---
const PhotoGrid: React.FC<{ photos: Photo[], onPhotoClick: (id: string) => void }> = ({ photos, onPhotoClick }) => (
    <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-2 p-4">
        {photos.map((photo) => (
            <div key={photo.id} className="aspect-square bg-gray-200 rounded-lg overflow-hidden group cursor-pointer" onClick={() => onPhotoClick(photo.id)}>
                <img src={`https://picsum.photos/seed/${photo.id}/300/300`} alt="thumbnail" className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" loading="lazy" />
            </div>
        ))}
    </div>
);

const PhotoViewer: React.FC<{
    photos: Photo[],
    startId: string,
    onClose: () => void,
    onSetWallpaper: (url: string) => void,
    onTogglePrivate: (seed: string) => void,
    isPrivate: (seed: string) => boolean,
    onExecuteAction: (action: OSAction) => void;
}> = ({ photos, startId, onClose, onSetWallpaper, onTogglePrivate, isPrivate, onExecuteAction }) => {
    const [currentIndex, setCurrentIndex] = useState(() => photos.findIndex(p => p.id === startId));
    
    const currentPhoto = photos[currentIndex];
    const imageUrl = `https://picsum.photos/seed/${currentPhoto.id}/1200/800`;

    const handleNext = () => setCurrentIndex(prev => (prev + 1) % photos.length);
    const handlePrev = () => setCurrentIndex(prev => (prev - 1 + photos.length) % photos.length);

    const handleEdit = () => {
        onExecuteAction({
            action: 'open_app',
            payload: { appId: 'pixelate', filePath: imageUrl }
        });
        onClose();
    };


    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            if (e.key === 'ArrowRight') handleNext();
            if (e.key === 'ArrowLeft') handlePrev();
            if (e.key === 'Escape') onClose();
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [onClose]);

    const bgPattern = `linear-gradient(45deg, #ccc 25%, transparent 25%), linear-gradient(-45deg, #ccc 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #ccc 75%), linear-gradient(-45deg, transparent 75%, #ccc 75%)`;

    return (
        <div className="absolute inset-0 bg-black/50 backdrop-blur-md z-10 flex flex-col" style={{ backgroundImage: bgPattern, backgroundSize: '20px 20px' }}>
            <header className="flex-shrink-0 p-2 text-right bg-black/20 flex justify-between items-center">
                <button onClick={handleEdit} className="px-3 py-1 bg-white/80 hover:bg-white text-black rounded-md text-sm font-semibold">Edit in Pixelate</button>
                <button onClick={onClose} className="w-8 h-8 rounded-full bg-black/30 text-white font-bold text-lg hover:bg-black/50">✕</button>
            </header>
            <main className="flex-grow flex items-center justify-center p-4">
                 <img src={imageUrl} alt="Full size" className="max-w-full max-h-full object-contain shadow-2xl rounded-lg border-2 border-white" />
            </main>
            <footer className="flex-shrink-0 p-2 text-center bg-black/20 flex justify-center items-center space-x-3">
                <button onClick={handlePrev} className="px-3 py-2 bg-white/60 hover:bg-white/90 rounded-md">⬅️</button>
                <button onClick={() => onSetWallpaper(imageUrl)} className="px-3 py-2 bg-white/60 hover:bg-white/90 rounded-md">🌄 Set Wallpaper</button>
                <button onClick={() => onTogglePrivate(currentPhoto.id)} className="px-3 py-2 bg-white/60 hover:bg-white/90 rounded-md">{isPrivate(currentPhoto.id) ? '✅ Public' : '🔒 Private'}</button>
                <button onClick={handleNext} className="px-3 py-2 bg-white/60 hover:bg-white/90 rounded-md">➡️</button>
            </footer>
        </div>
    );
};

const MemoriesSection: React.FC<{ photos: Photo[], onPhotoClick: (id: string) => void }> = ({ photos, onPhotoClick }) => {
    const memories = useMemo(() => {
        if (photos.length < 4) return [];
        const memory1 = photos.slice(0, 4);
        return [{ title: 'Recent Highlights', photos: memory1 }];
    }, [photos]);

    if (memories.length === 0) return null;

    return (
        <div className="p-4">
            <h2 className="text-xl font-bold mb-2">For You</h2>
            {memories.map(memory => (
                <div key={memory.title} className="cursor-pointer" onClick={() => onPhotoClick(memory.photos[0].id)}>
                    <div className="w-full aspect-[4/3] rounded-xl overflow-hidden bg-gray-200">
                         <img src={`https://picsum.photos/seed/${memory.photos[0].id}/800/600`} alt={memory.title} className="w-full h-full object-cover"/>
                    </div>
                    <h3 className="font-semibold mt-2">{memory.title}</h3>
                    <p className="text-sm text-gray-500">Today</p>
                </div>
            ))}
        </div>
    );
};

// --- MAIN APP ---
export const PhotosApp: React.FC<AppProps> = ({ onExecuteAction = () => {} }) => {
    const { setWallpaper, photosState, importPhotos, createPhotoAlbum, addPhotoToAlbum, removePhotoFromAlbum } = useSettings();
    
    const [activeAlbumId, setActiveAlbumId] = useState('all');
    const [view, setView] = useState<View>('grid');
    const [viewerStartId, setViewerStartId] = useState<string | null>(null);
    const [feedback, setFeedback] = useState('');

    const photosForCurrentAlbum = useMemo(() => {
        if (activeAlbumId === 'memories') return [];
        return photosState.photos
            .filter(p => p.albumIds.includes(activeAlbumId))
            .sort((a,b) => b.addedAt - a.addedAt);
    }, [activeAlbumId, photosState.photos]);

    const showFeedback = (message: string) => {
        setFeedback(message);
        setTimeout(() => setFeedback(''), 2000);
    };

    const handlePhotoClick = (id: string) => {
        setViewerStartId(id);
        setView('viewer');
    };
    
    const handleTogglePrivate = (photoId: string) => {
        const isCurrentlyPrivate = photosState.photos.find(p => p.id === photoId)?.albumIds.includes('private');
        if (isCurrentlyPrivate) {
            removePhotoFromAlbum(photoId, 'private');
            showFeedback('Moved to All Photos');
        } else {
            addPhotoToAlbum(photoId, 'private');
            showFeedback('Moved to Private');
        }
    };
    
    const handleCreateAlbum = () => {
        const name = prompt("Enter new album name:");
        if (name) createPhotoAlbum(name);
    }

    return (
        <div className="w-full h-full flex bg-mac-gray relative">
            <aside className="w-56 h-full bg-mac-gray-header/60 p-3 shrink-0 border-r border-black/10 flex flex-col">
                <div className="space-y-1">
                    <h2 className="text-xs font-bold text-gray-500 uppercase px-3 mb-2">Library</h2>
                    <SidebarItem icon="🖼️" label="All Photos" isActive={activeAlbumId === 'all'} onClick={() => setActiveAlbumId('all')} />
                    <SidebarItem icon="💖" label="Favorites" isActive={activeAlbumId === 'favorites'} onClick={() => setActiveAlbumId('favorites')} />
                    <SidebarItem icon="✨" label="Memories" isActive={activeAlbumId === 'memories'} onClick={() => setActiveAlbumId('memories')} />
                    <SidebarItem icon="🔒" label="Private" isActive={activeAlbumId === 'private'} onClick={() => setActiveAlbumId('private')} />
                </div>
                 <div className="mt-4 pt-4 border-t border-gray-300">
                    <div className="flex justify-between items-center px-3 mb-2">
                         <h2 className="text-xs font-bold text-gray-500 uppercase">My Albums</h2>
                         <button onClick={handleCreateAlbum} className="text-blue-500 text-lg font-bold">+</button>
                    </div>
                    <div className="space-y-1">
                        {photosState.albums.filter(a => !['all', 'private', 'favorites'].includes(a.id)).map(album => (
                            <SidebarItem key={album.id} icon="앨범" label={album.name} isActive={activeAlbumId === album.id} onClick={() => setActiveAlbumId(album.id)} />
                        ))}
                    </div>
                 </div>
                 <div className="mt-auto">
                    <button onClick={() => importPhotos(5)} className="w-full px-4 py-1.5 bg-gray-200 hover:bg-gray-300 text-mac-text font-medium rounded-md transition-colors border border-black/10 text-sm">Import Photos</button>
                 </div>
            </aside>
            
            <main className="flex-grow flex flex-col bg-white overflow-y-auto">
                 {feedback && <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-black/60 text-white px-4 py-2 rounded-full text-sm z-20">{feedback}</div>}
                 
                 {activeAlbumId === 'memories' ? (
                     <MemoriesSection photos={photosState.photos} onPhotoClick={handlePhotoClick} />
                 ) : photosForCurrentAlbum.length > 0 ? (
                    <PhotoGrid photos={photosForCurrentAlbum} onPhotoClick={handlePhotoClick} />
                 ) : (
                    <div className="flex-grow flex items-center justify-center text-mac-text-secondary">This album is empty.</div>
                 )}
            </main>
            
            {view === 'viewer' && viewerStartId && (
                <PhotoViewer
                    photos={photosForCurrentAlbum}
                    startId={viewerStartId}
                    onClose={() => setView('grid')}
                    onSetWallpaper={(url) => { setWallpaper(url); showFeedback('Wallpaper Set!'); }}
                    onTogglePrivate={handleTogglePrivate}
                    isPrivate={(photoId) => photosState.photos.find(p => p.id === photoId)?.albumIds.includes('private') || false}
                    onExecuteAction={onExecuteAction}
                />
            )}
        </div>
    );
};

const SidebarItem: React.FC<{ icon: string; label: string; isActive: boolean; onClick: () => void }> = ({ icon, label, isActive, onClick }) => (
    <button
        onClick={onClick}
        className={`flex items-center w-full text-left px-3 py-2 rounded-lg transition-colors duration-150 ${
            isActive ? 'bg-mac-blue/20 text-mac-blue' : 'hover:bg-gray-200/50'
        }`}
    >
        <span className="text-md mr-3">{icon}</span>
        <span className="font-medium text-sm">{label}</span>
    </button>
);