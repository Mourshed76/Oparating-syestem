import React, { useState, useRef, useEffect, useCallback } from 'react';
import type { AppProps, Photo } from '../../types';
import { useSettings } from '../../context/SettingsContext';
import { aiService } from '../../utils/aiService';

// --- TYPE DEFINITIONS ---
type Tool = 'move' | 'marquee' | 'brush' | 'eraser' | 'text' | 'bucket' | 'eyedropper';
type AppState = 'welcome' | 'editing';

interface Layer {
    id: number;
    name: string;
    canvas: HTMLCanvasElement;
    isVisible: boolean;
    opacity: number;
    textData?: { content: string; x: number; y: number; color: string; size: number; };
}

interface HistoryState {
    layers: { [id: number]: {
        name: string;
        isVisible: boolean;
        opacity: number;
        imageDataUrl: string;
        textData?: Layer['textData'];
    }}
}

interface Selection { x: number; y: number; width: number; height: number; }

// --- HELPER & CHILD COMPONENTS ---

const WelcomeScreen: React.FC<{ onNew: () => void; onOpen: () => void; onAiGenerate: () => void; }> = ({ onNew, onOpen, onAiGenerate }) => (
    <div className="absolute inset-0 bg-gray-800 flex flex-col items-center justify-center p-8 z-50 text-white">
        <div className="text-center">
            <h1 className="text-5xl font-bold mb-2">Pixelate</h1>
            <p className="text-gray-300 mb-8">Your Advanced AI Photo Editor</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full max-w-4xl">
            <button onClick={onNew} className="bg-gray-700 hover:bg-purple-600 p-8 rounded-xl flex flex-col items-center justify-center transition-colors">
                <span className="text-4xl mb-2">📄</span><h2 className="font-bold text-lg">Create New</h2><p className="text-sm text-gray-400">Start with a blank canvas</p>
            </button>
            <button onClick={onOpen} className="bg-gray-700 hover:bg-purple-600 p-8 rounded-xl flex flex-col items-center justify-center transition-colors">
                <span className="text-4xl mb-2">💻</span><h2 className="font-bold text-lg">Open from Computer</h2><p className="text-sm text-gray-400">Import an image from your device</p>
            </button>
            <button onClick={onAiGenerate} className="bg-gray-700 hover:bg-purple-600 p-8 rounded-xl flex flex-col items-center justify-center transition-colors">
                <span className="text-4xl mb-2">✨</span><h2 className="font-bold text-lg">AI Generate</h2><p className="text-sm text-gray-400">Create an image from text</p>
            </button>
        </div>
    </div>
);

const Toolbar: React.FC<{ activeTool: Tool; onToolSelect: (tool: Tool) => void }> = ({ activeTool, onToolSelect }) => {
    const tools = [
        { id: 'marquee', name: 'Marquee', icon: '🖼️' }, { id: 'brush', name: 'Brush', icon: '🖌️' },
        { id: 'eraser', name: 'Eraser', icon: '🧼' }, { id: 'bucket', name: 'Paint Bucket', icon: '🗑️' },
        { id: 'eyedropper', name: 'Eyedropper', icon: '💧' }, { id: 'text', name: 'Text', icon: 'T' },
    ];
    return (
        <aside className="w-16 bg-gray-900 p-2 flex flex-col items-center gap-1 shrink-0">
            {tools.map(tool => (
                <button key={tool.id} onClick={() => onToolSelect(tool.id as Tool)} title={tool.name} className={`p-2 rounded-lg flex items-center justify-center w-full ${activeTool === tool.id ? 'bg-purple-600' : 'hover:bg-gray-700'}`}>
                    <span className="text-2xl">{tool.icon}</span>
                </button>
            ))}
        </aside>
    );
};

const LayersPanel: React.FC<{ layers: Layer[], activeLayerId: number | null, onSelect: (id: number) => void, onAdd: () => void, onDelete: (id: number) => void, onOpacityChange: (id: number, opacity: number) => void }> = ({ layers, activeLayerId, onSelect, onAdd, onDelete, onOpacityChange }) => (
    <div className="flex flex-col h-full">
        <div className="flex-grow bg-gray-800 rounded-lg p-2 space-y-1 overflow-y-auto">
            {layers.slice().reverse().map(layer => (
                <div key={layer.id} onClick={() => onSelect(layer.id)} className={`p-2 rounded text-sm cursor-pointer flex items-center gap-2 ${activeLayerId === layer.id ? 'bg-purple-600/50' : 'hover:bg-gray-700'}`}>
                    <canvas width="40" height="30" className="bg-white/10 rounded shrink-0" ref={ref => { if (ref) { const ctx = ref.getContext('2d'); ctx?.clearRect(0,0,40,30); ctx?.drawImage(layer.canvas, 0, 0, 40, 30); } }} />
                    <span className="truncate flex-grow">{layer.name}</span>
                    <input type="range" min="0" max="1" step="0.05" value={layer.opacity} onChange={(e) => onOpacityChange(layer.id, parseFloat(e.target.value))} className="w-16 accent-purple-500" />
                </div>
            ))}
        </div>
        <div className="flex-shrink-0 pt-2 flex justify-center gap-4">
            <button onClick={onAdd} className="px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded">New Layer</button>
            <button onClick={() => activeLayerId && onDelete(activeLayerId)} disabled={!activeLayerId} className="px-2 py-1 bg-red-800 hover:bg-red-700 rounded disabled:opacity-50">Delete</button>
        </div>
    </div>
);

const HistoryPanel: React.FC<{ history: HistoryState[], onRevert: (index: number) => void, currentIndex: number }> = ({ history, onRevert, currentIndex }) => (
    <div className="bg-gray-800 rounded-lg p-2 space-y-1 overflow-y-auto h-full">
        {history.slice().reverse().map((state, index) => {
            const historyIdx = history.length - 1 - index;
            return (
                <button key={historyIdx} onClick={() => onRevert(historyIdx)} className={`w-full text-left p-2 rounded text-sm ${currentIndex === historyIdx ? 'bg-purple-600/50' : 'hover:bg-gray-700'}`}>
                    Action {historyIdx}
                </button>
            );
        })}
    </div>
);

// --- MAIN APP ---
export const PixelateApp: React.FC<AppProps> = ({ filePath }) => {
    const [appState, setAppState] = useState<AppState>('welcome');
    const [layers, setLayers] = useState<Layer[]>([]);
    const [activeLayerId, setActiveLayerId] = useState<number | null>(null);
    const [activeTool, setActiveTool] = useState<Tool>('brush');
    const [history, setHistory] = useState<HistoryState[]>([]);
    const [historyIndex, setHistoryIndex] = useState(-1);
    const [isDrawing, setIsDrawing] = useState(false);
    
    // Tool settings
    const [brushColor, setBrushColor] = useState('#ffffff');
    const [brushSize, setBrushSize] = useState(10);
    const [fontSize, setFontSize] = useState(48);
    
    // UI State
    const [canvasSize, setCanvasSize] = useState({width: 800, height: 600});
    const [selection, setSelection] = useState<Selection | null>(null);
    const [isAiModalOpen, setIsAiModalOpen] = useState<{ open: boolean, type: 'generate' | 'magic-fill' }>({ open: false, type: 'generate' });
    const [isLoadingAi, setIsLoadingAi] = useState(false);
    const [aiPrompt, setAiPrompt] = useState('');

    const fileInputRef = useRef<HTMLInputElement>(null);
    const mainCanvasRef = useRef<HTMLCanvasElement>(null);
    const overlayCanvasRef = useRef<HTMLCanvasElement>(null);
    const lastMousePos = useRef<{ x: number, y: number } | null>(null);

    const addLayer = useCallback((name: string, image?: HTMLImageElement): number => {
        const newSize = image ? { width: image.width, height: image.height } : canvasSize;
        const newCanvas = document.createElement('canvas');
        newCanvas.width = newSize.width;
        newCanvas.height = newSize.height;
        if (image) newCanvas.getContext('2d')?.drawImage(image, 0, 0);
        
        const newLayer: Layer = { id: Date.now(), name, canvas: newCanvas, isVisible: true, opacity: 1 };
        
        const updateAllCanvases = (layersToUpdate: Layer[]): Layer[] => {
            return layersToUpdate.map(l => {
                const resizedCanvas = document.createElement('canvas');
                resizedCanvas.width = newSize.width;
                resizedCanvas.height = newSize.height;
                resizedCanvas.getContext('2d')?.drawImage(l.canvas, 0, 0);
                return { ...l, canvas: resizedCanvas };
            });
        };

        if (image) {
            setCanvasSize(newSize);
            setLayers(prev => [...updateAllCanvases(prev), newLayer]);
        } else {
            setLayers(prev => [...prev, newLayer]);
        }
        setActiveLayerId(newLayer.id);
        return newLayer.id;
    }, [canvasSize]);

    useEffect(() => {
        if (filePath) {
            const img = new Image();
            img.crossOrigin = "anonymous";
            img.onload = () => {
                addLayer('Imported Image', img);
                setAppState('editing');
            };
            img.src = filePath;
        }
    }, [filePath, addLayer]);

    const compositeLayers = useCallback(() => {
        const canvas = mainCanvasRef.current;
        const ctx = canvas?.getContext('2d');
        if (!ctx || !canvas) return;
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        layers.forEach(layer => {
            if (layer.isVisible) {
                ctx.globalAlpha = layer.opacity;
                ctx.drawImage(layer.canvas, 0, 0);
            }
        });
        ctx.globalAlpha = 1.0;
    }, [layers]);

    useEffect(compositeLayers, [layers, compositeLayers]);

    const addHistory = useCallback(() => {
        const layersData: HistoryState['layers'] = {};
        layers.forEach(l => {
            layersData[l.id] = { name: l.name, isVisible: l.isVisible, opacity: l.opacity, imageDataUrl: l.canvas.toDataURL(), textData: l.textData };
        });
        const newHistory = history.slice(0, historyIndex + 1);
        newHistory.push({ layers: layersData });
        setHistory(newHistory);
        setHistoryIndex(newHistory.length - 1);
    }, [layers, history, historyIndex]);

    const restoreFromHistory = useCallback(async (index: number) => {
        const historyState = history[index];
        if (!historyState) return;
        const newLayers: Layer[] = [];
        for (const [idStr, data] of Object.entries(historyState.layers)) {
            const id = parseInt(idStr, 10);
            const img = new Image();
            img.src = data.imageDataUrl;
            await img.decode();
            const canvas = document.createElement('canvas');
            canvas.width = canvasSize.width;
            canvas.height = canvasSize.height;
            canvas.getContext('2d')?.drawImage(img, 0, 0);
            newLayers.push({ id, ...data, canvas });
        }
        setLayers(newLayers.sort((a, b) => a.id - b.id));
        setHistoryIndex(index);
    }, [history, canvasSize]);

    const undo = () => historyIndex > 0 && restoreFromHistory(historyIndex - 1);
    const redo = () => historyIndex < history.length - 1 && restoreFromHistory(historyIndex + 1);
    
    useEffect(() => {
        if(appState === 'editing') setTimeout(addHistory, 100);
    }, [layers.length, appState]);


    const handleFileOpen = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (event) => {
                const img = new Image();
                img.onload = () => { addLayer(file.name, img); setAppState('editing'); };
                img.src = event.target?.result as string;
            };
            reader.readAsDataURL(file);
        }
    };
    
    const handleAiGenerate = async () => {
        if (!aiPrompt.trim()) return;
        setIsLoadingAi(true);
        try {
            const response = await aiService.generateImages(aiPrompt);
            const base64 = response.generatedImages[0].image.imageBytes;
            const img = new Image();
            img.onload = () => {
                if (isAiModalOpen.type === 'magic-fill' && activeLayerId && selection) {
                    const newLayerId = addLayer(`${aiPrompt.substring(0, 15)}...`);
                    setLayers(prev => {
                        const newLayers = [...prev];
                        const layer = newLayers.find(l => l.id === newLayerId);
                        if (layer?.canvas) {
                            const ctx = layer.canvas.getContext('2d');
                            if(ctx) {
                                ctx.save();
                                ctx.beginPath();
                                ctx.rect(selection.x, selection.y, selection.width, selection.height);
                                ctx.clip();
                                ctx.drawImage(img, 0, 0, img.width, img.height, selection.x, selection.y, selection.width, selection.height);
                                ctx.restore();
                            }
                        }
                        return newLayers;
                    });
                    setTimeout(addHistory, 100);
                    setSelection(null);
                } else {
                    addLayer(aiPrompt, img);
                    setAppState('editing');
                }
            };
            img.src = `data:image/jpeg;base64,${base64}`;
        } catch (error) { console.error("AI generation failed:", error); } 
        finally {
            setIsLoadingAi(false); setAiPrompt(''); setIsAiModalOpen({ open: false, type: 'generate' });
        }
    };

    const getMousePos = (e: React.MouseEvent) => {
        const rect = overlayCanvasRef.current?.getBoundingClientRect();
        if (!rect) return { x: 0, y: 0 };
        return { x: e.clientX - rect.left, y: e.clientY - rect.top };
    }
    
    const handleMouseDown = (e: React.MouseEvent) => {
        const pos = getMousePos(e);
        lastMousePos.current = pos;
        setIsDrawing(true);
        const activeLayerData = layers.find(l => l.id === activeLayerId);
        if (!activeLayerData) return;
        const ctx = activeLayerData.canvas.getContext('2d');
        if (!ctx) return;

        if (activeTool === 'brush' || activeTool === 'eraser') { ctx.beginPath(); ctx.moveTo(pos.x, pos.y); }
        if (activeTool === 'eyedropper') {
            const mainCtx = mainCanvasRef.current?.getContext('2d');
            if (mainCtx) {
                const pixel = mainCtx.getImageData(pos.x, pos.y, 1, 1).data;
                setBrushColor(`rgba(${pixel[0]}, ${pixel[1]}, ${pixel[2]}, ${pixel[3] / 255})`);
            }
        }
        if (activeTool === 'bucket') { ctx.fillStyle = brushColor; ctx.fillRect(0, 0, canvasSize.width, canvasSize.height); compositeLayers(); addHistory(); }
        if (activeTool === 'marquee') { setSelection({ x: pos.x, y: pos.y, width: 0, height: 0 }); }
        if (activeTool === 'text') {
            const newLayerId = addLayer('Text Layer');
            const content = prompt("Enter text:", "Hello World");
            if(content) {
                setLayers(prev => {
                    const newLayers = [...prev];
                    const textLayer = newLayers.find(l => l.id === newLayerId);
                    if (textLayer) {
                         textLayer.textData = { content, x: pos.x, y: pos.y, color: brushColor, size: fontSize };
                         const textCtx = textLayer.canvas.getContext('2d');
                         if(textCtx) {
                             textCtx.fillStyle = textLayer.textData.color;
                             textCtx.font = `${textLayer.textData.size}px sans-serif`;
                             textCtx.fillText(textLayer.textData.content, textLayer.textData.x, textLayer.textData.y);
                         }
                    }
                    return newLayers;
                });
                setTimeout(addHistory, 100);
            }
        }
    };
    
    const handleMouseMove = (e: React.MouseEvent) => {
        if (!isDrawing) return;
        const pos = getMousePos(e);
        const startPos = lastMousePos.current;
        if (activeTool === 'brush' || activeTool === 'eraser') {
            const activeLayerData = layers.find(l => l.id === activeLayerId);
            if (!activeLayerData) return;
            const ctx = activeLayerData.canvas.getContext('2d');
            if (ctx) {
                ctx.strokeStyle = brushColor; ctx.lineWidth = brushSize; ctx.lineCap = 'round';
                ctx.globalCompositeOperation = activeTool === 'eraser' ? 'destination-out' : 'source-over';
                ctx.lineTo(pos.x, pos.y); ctx.stroke(); compositeLayers();
            }
        }
        if (activeTool === 'marquee' && selection && startPos) {
            const overlayCtx = overlayCanvasRef.current?.getContext('2d');
            if (overlayCtx) {
                overlayCtx.clearRect(0, 0, canvasSize.width, canvasSize.height);
                overlayCtx.strokeStyle = 'rgba(255, 255, 255, 0.9)'; overlayCtx.lineWidth = 1; overlayCtx.setLineDash([4, 4]);
                const width = pos.x - startPos.x; const height = pos.y - startPos.y;
                overlayCtx.strokeRect(startPos.x, startPos.y, width, height);
                setSelection({ x: startPos.x, y: startPos.y, width, height });
            }
        }
    };
    
    const handleMouseUp = () => {
        if(isDrawing) {
            if (activeTool === 'brush' || activeTool === 'eraser') addHistory();
            if (activeTool === 'marquee' && selection && (selection.width !== 0 || selection.height !== 0)) {
                const overlayCtx = overlayCanvasRef.current?.getContext('2d');
                overlayCtx?.clearRect(0, 0, canvasSize.width, canvasSize.height);
                setIsAiModalOpen({ open: true, type: 'magic-fill' });
            }
        }
        setIsDrawing(false); lastMousePos.current = null;
    };

    return (
        <div className="w-full h-full bg-gray-800 text-white flex flex-col select-none">
            {appState === 'welcome' && !filePath && <WelcomeScreen onNew={() => { addLayer('Background'); setAppState('editing'); }} onOpen={() => fileInputRef.current?.click()} onAiGenerate={() => setIsAiModalOpen({ open: true, type: 'generate' })} />}
            <input type="file" ref={fileInputRef} onChange={handleFileOpen} accept="image/*" className="hidden" />
            
            <div className={`flex-grow flex flex-col overflow-hidden ${appState === 'welcome' && !filePath ? 'hidden' : ''}`}>
                <div className="h-12 bg-gray-900 flex-shrink-0 flex items-center justify-between px-4 text-sm">
                    <div className="flex gap-4"><span>File</span><span>Edit</span><span>Layer</span></div>
                    <div className="flex items-center gap-4">
                        { (activeTool === 'brush' || activeTool === 'eraser' || activeTool === 'bucket' || activeTool === 'text') && <input type="color" value={brushColor} onChange={e => setBrushColor(e.target.value)} /> }
                        { (activeTool === 'brush' || activeTool === 'eraser') && <><span>Size: {brushSize}</span><input type="range" min="1" max="100" value={brushSize} onChange={e => setBrushSize(parseInt(e.target.value))} /></> }
                        { activeTool === 'text' && <><span>Font Size: {fontSize}</span><input type="range" min="8" max="128" value={fontSize} onChange={e => setFontSize(parseInt(e.target.value))} /></> }
                    </div>
                </div>
                <div className="flex-grow flex overflow-hidden">
                    <Toolbar activeTool={activeTool} onToolSelect={setActiveTool} />
                    <main className="flex-grow bg-gray-700 flex items-center justify-center p-4 overflow-auto">
                        <div className="relative" onMouseDown={handleMouseDown} onMouseMove={handleMouseMove} onMouseUp={handleMouseUp} onMouseLeave={handleMouseUp}>
                            <canvas ref={mainCanvasRef} width={canvasSize.width} height={canvasSize.height} className="bg-white" style={{ background: 'repeating-conic-gradient(#808080 0% 25%, transparent 0% 50%) 50% / 20px 20px' }} />
                            <canvas ref={overlayCanvasRef} width={canvasSize.width} height={canvasSize.height} className="absolute top-0 left-0 pointer-events-none" />
                        </div>
                    </main>
                    <aside className="w-72 bg-gray-900 p-3 flex flex-col gap-4 shrink-0">
                         <div className="h-1/2"><LayersPanel layers={layers} activeLayerId={activeLayerId} onSelect={setActiveLayerId} onAdd={() => addLayer('New Layer')} onDelete={(id) => { setLayers(l => l.filter(lay => lay.id !== id)); setTimeout(addHistory, 100); }} onOpacityChange={(id, val) => setLayers(l => l.map(lay => lay.id === id ? {...lay, opacity: val} : lay))} /></div>
                         <div className="h-1/2"><HistoryPanel history={history} currentIndex={historyIndex} onRevert={restoreFromHistory} /></div>
                    </aside>
                </div>
            </div>

            {isAiModalOpen.open && (
                <div className="absolute inset-0 bg-black/60 z-50 flex items-center justify-center">
                    <div className="bg-gray-800 p-6 rounded-lg w-96 flex flex-col gap-4">
                        <h2 className="text-xl font-bold">{isAiModalOpen.type === 'generate' ? 'AI Image Generation' : 'Magic Fill'}</h2>
                        <textarea value={aiPrompt} onChange={e => setAiPrompt(e.target.value)} placeholder="A majestic castle on a hill..." className="w-full p-2 rounded bg-gray-700 h-24 resize-none" />
                        <div className="flex justify-end gap-2">
                            <button onClick={() => setIsAiModalOpen({ open: false, type: 'generate' })} className="px-4 py-2 bg-gray-600 rounded">Cancel</button>
                            <button onClick={handleAiGenerate} disabled={isLoadingAi} className="px-4 py-2 bg-purple-600 rounded disabled:opacity-50">{isLoadingAi ? 'Generating...' : 'Generate'}</button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};