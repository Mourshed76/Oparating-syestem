import React, { useState, useMemo } from 'react';
import type { AppProps, MediaItem } from '../../types';
import { faker } from '@faker-js/faker';

// --- MOCK DATA ---
const generateMedia = (count: number): MediaItem[] => {
    return Array.from({ length: count }, () => ({
        id: faker.string.uuid(),
        title: faker.lorem.words(3).replace(/\b\w/g, l => l.toUpperCase()),
        type: Math.random() > 0.7 ? 'Show' : 'Movie',
        description: faker.lorem.paragraph(),
        coverSeed: faker.string.uuid(),
    }));
};
const MEDIA_LIBRARY = generateMedia(30);

// --- SUB-COMPONENTS ---
const MediaPoster: React.FC<{ item: MediaItem, onSelect: () => void }> = ({ item, onSelect }) => (
    <div onClick={onSelect} className="group cursor-pointer aspect-[2/3] bg-gray-800 rounded-lg overflow-hidden relative">
        <img src={`https://picsum.photos/seed/${item.coverSeed}/400/600`} alt={item.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform"/>
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"/>
        <h3 className="absolute bottom-3 left-3 right-3 font-bold text-white">{item.title}</h3>
    </div>
);

const MediaDetails: React.FC<{ item: MediaItem, onClose: () => void }> = ({ item, onClose }) => (
    <div className="absolute inset-0 bg-black/70 backdrop-blur-xl z-10 flex items-center justify-center" onClick={onClose}>
        <div className="w-full max-w-4xl h-[80vh] bg-gray-900 rounded-2xl flex overflow-hidden" onClick={e => e.stopPropagation()}>
            <img src={`https://picsum.photos/seed/${item.coverSeed}/500/750`} alt={item.title} className="w-1/3 h-full object-cover"/>
            <div className="flex-grow p-8 flex flex-col">
                <h1 className="text-4xl font-extrabold">{item.title}</h1>
                <p className="text-lg text-gray-400 mt-1">{item.type}</p>
                <p className="text-gray-300 mt-6 flex-grow overflow-y-auto">{item.description}</p>
                <div className="mt-6 flex gap-4">
                    <button className="px-8 py-3 bg-white text-black font-bold rounded-lg text-lg">▶ Play</button>
                    <button className="px-4 py-3 bg-white/20 rounded-lg text-lg">+</button>
                </div>
            </div>
        </div>
    </div>
);


// --- MAIN APP ---
export const TVApp: React.FC<AppProps> = () => {
    const [selectedItem, setSelectedItem] = useState<MediaItem | null>(null);

    return (
        <div className="w-full h-full bg-[#141414] text-white">
            <header className="h-16 px-8 flex items-center">
                <h1 className="text-2xl font-bold text-red-600">AURA TV</h1>
            </header>
            <main className="p-8 overflow-y-auto h-[calc(100%-4rem)]">
                <h2 className="text-3xl font-bold mb-4">Trending Now</h2>
                 <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-6">
                    {MEDIA_LIBRARY.map(item => <MediaPoster key={item.id} item={item} onSelect={() => setSelectedItem(item)} />)}
                </div>
            </main>
            {selectedItem && <MediaDetails item={selectedItem} onClose={() => setSelectedItem(null)} />}
        </div>
    );
};
