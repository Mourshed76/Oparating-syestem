import React, { useState } from 'react';
import type { AppProps } from '../../types';
import { faker } from '@faker-js/faker';

interface Comic {
    id: string;
    title: string;
    issue: number;
    coverSeed: string;
}

// MOCK DATA
const generateLibrary = (count: number): Comic[] => {
    return Array.from({ length: count }, () => ({
        id: faker.string.uuid(),
        title: faker.company.name().replace(/\s/g, ''),
        issue: Math.floor(Math.random() * 100) + 1,
        coverSeed: faker.string.uuid(),
    }));
};
const LIBRARY = generateLibrary(18);

export const ComicsApp: React.FC<AppProps> = () => {
    const [selectedComic, setSelectedComic] = useState<Comic | null>(null);

    if (selectedComic) {
        return (
            <div className="w-full h-full bg-gray-800 flex flex-col">
                <header className="p-2 bg-black/50 text-white flex justify-between items-center">
                    <h2 className="font-bold">{selectedComic.title} #{selectedComic.issue}</h2>
                    <button onClick={() => setSelectedComic(null)} className="px-3 py-1 bg-gray-600 rounded text-sm">Close</button>
                </header>
                <main className="flex-grow flex items-center justify-center">
                    <img src={`https://picsum.photos/seed/${selectedComic.coverSeed}/600/900`} alt={selectedComic.title} className="max-w-full max-h-full object-contain" />
                </main>
            </div>
        );
    }
    
    return (
        <div className="w-full h-full bg-[#1e1e1e] text-white p-6 overflow-y-auto">
            <h1 className="text-3xl font-bold mb-6">My Comics</h1>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
                {LIBRARY.map(comic => (
                    <div key={comic.id} onClick={() => setSelectedComic(comic)} className="group cursor-pointer">
                        <div className="aspect-[2/3] bg-gray-800 rounded-lg overflow-hidden shadow-2xl">
                            <img src={`https://picsum.photos/seed/${comic.coverSeed}/400/600`} alt={comic.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                        </div>
                        <h3 className="font-semibold mt-2 truncate">{comic.title}</h3>
                        <p className="text-sm text-gray-400">Issue #{comic.issue}</p>
                    </div>
                ))}
            </div>
        </div>
    );
};
