import React, { useState } from 'react';

export const NotesApp: React.FC = () => {
    const [text, setText] = useState('This is a simple note.\n\nIt\'s designed to look and feel like the Notes app on macOS. You can jot down your ideas here.');

    return (
        <div className="w-full h-full bg-[#fffbeb]">
            <textarea
                className="w-full h-full p-6 resize-none border-none focus:ring-0 bg-transparent text-[#3e2723] font-serif text-lg leading-relaxed"
                value={text}
                onChange={(e) => setText(e.target.value)}
                spellCheck="false"
            />
        </div>
    );
};
