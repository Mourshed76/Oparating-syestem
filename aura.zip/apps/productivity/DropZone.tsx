import React, { useState, useCallback } from 'react';
import type { AppProps } from '../../types';
import { v4 as uuidv4 } from 'uuid';

interface DroppedFile {
    id: string;
    name: string;
    size: number; // in bytes
    type: string;
}

export const DropZoneApp: React.FC<AppProps> = () => {
    const [files, setFiles] = useState<DroppedFile[]>([]);
    const [isDragging, setIsDragging] = useState(false);

    const handleDragEnter = (e: React.DragEvent) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(true);
    };
    const handleDragLeave = (e: React.DragEvent) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(false);
    };
    const handleDragOver = (e: React.DragEvent) => {
        e.preventDefault();
        e.stopPropagation();
    };

    const handleDrop = (e: React.DragEvent) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(false);

        if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
            const newFiles = Array.from(e.dataTransfer.files).map(file => ({
                id: uuidv4(),
                name: file.name,
                size: file.size,
                type: file.type,
            }));
            setFiles(prev => [...prev, ...newFiles]);
            e.dataTransfer.clearData();
        }
    };
    
    const formatBytes = (bytes: number) => {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    };
    
    const copyLink = (id: string) => {
        navigator.clipboard.writeText(`https://aura.os/share/${id}`);
        // Add feedback
    };

    return (
        <div className="w-full h-full flex flex-col bg-gray-800 text-white p-6">
            <h1 className="text-3xl font-bold mb-4">DropZone</h1>
            <p className="text-gray-400 mb-6">Drag and drop files to simulate uploading and get a shareable link.</p>
            
            <div
                onDragEnter={handleDragEnter}
                onDragLeave={handleDragLeave}
                onDragOver={handleDragOver}
                onDrop={handleDrop}
                className={`flex-grow border-4 border-dashed rounded-xl flex flex-col items-center justify-center transition-colors ${isDragging ? 'border-purple-500 bg-purple-500/10' : 'border-gray-600'}`}
            >
                <div className="text-5xl mb-4">📤</div>
                <p className="font-semibold text-lg">{isDragging ? 'Drop files now!' : 'Drag files here'}</p>
            </div>
            
            <div className="h-48 mt-6 overflow-y-auto pr-2">
                 {files.length > 0 && files.map(file => (
                    <div key={file.id} className="bg-gray-700 p-3 rounded-lg flex items-center justify-between mb-2">
                        <div>
                            <p className="font-semibold">{file.name}</p>
                            <p className="text-sm text-gray-400">{formatBytes(file.size)}</p>
                        </div>
                        <button onClick={() => copyLink(file.id)} className="px-3 py-1 bg-purple-600 hover:bg-purple-700 rounded-md text-sm">Copy Link</button>
                    </div>
                ))}
            </div>
        </div>
    );
};
