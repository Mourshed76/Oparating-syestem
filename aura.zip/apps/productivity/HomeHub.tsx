import React, { useState } from 'react';
import type { AppProps } from '../../types';

interface Device {
    id: string;
    name: string;
    room: string;
    type: 'light' | 'thermostat' | 'security';
    state: any;
}

const initialDevices: Device[] = [
    { id: 'lr_light', name: 'Living Room Light', room: 'Living Room', type: 'light', state: true },
    { id: 'thermo', name: 'Main Thermostat', room: 'Home', type: 'thermostat', state: 21 },
    { id: 'bed_light', name: 'Bedroom Lamp', room: 'Bedroom', type: 'light', state: false },
    { id: 'security', name: 'Security System', room: 'Home', type: 'security', state: 'armed' },
];

const DeviceCard: React.FC<{ device: Device; onUpdate: (id: string, newState: any) => void }> = ({ device, onUpdate }) => {
    const baseClass = "p-4 rounded-xl transition-colors flex flex-col justify-between";
    const onClass = "bg-yellow-400 text-black";
    const offClass = "bg-gray-800 text-white";

    if (device.type === 'light') {
        return (
            <div className={`${baseClass} ${device.state ? onClass : offClass}`}>
                <div className="text-3xl">{device.state ? '💡' : '💡'}</div>
                <div>
                    <p className="font-bold">{device.name}</p>
                    <button onClick={() => onUpdate(device.id, !device.state)} className="font-semibold text-sm">{device.state ? 'On' : 'Off'}</button>
                </div>
            </div>
        );
    }
    
    if (device.type === 'thermostat') {
        return (
             <div className={`${baseClass} bg-gray-800 text-white`}>
                <div className="text-3xl">🌡️</div>
                <div>
                    <p className="font-bold">{device.name}</p>
                    <p className="text-2xl font-bold">{device.state}°C</p>
                    <input type="range" min="15" max="25" value={device.state} onChange={e => onUpdate(device.id, Number(e.target.value))} className="w-full mt-2 accent-orange-500" />
                </div>
            </div>
        );
    }
    
     if (device.type === 'security') {
        const isArmed = device.state === 'armed';
        return (
             <div className={`${baseClass} ${isArmed ? 'bg-red-600 text-white' : 'bg-green-600 text-white'}`}>
                <div className="text-3xl">{isArmed ? '🔒' : '✅'}</div>
                <div>
                    <p className="font-bold">{device.name}</p>
                    <button onClick={() => onUpdate(device.id, isArmed ? 'disarmed' : 'armed')} className="font-semibold text-sm capitalize">{device.state}</button>
                </div>
            </div>
        );
    }

    return null;
};

export const HomeHubApp: React.FC<AppProps> = () => {
    const [devices, setDevices] = useState(initialDevices);
    
    const updateDeviceState = (id: string, newState: any) => {
        setDevices(prev => prev.map(d => d.id === id ? {...d, state: newState} : d));
    };

    return (
        <div className="w-full h-full bg-black text-white p-6 overflow-y-auto">
            <header className="mb-8">
                <h1 className="text-3xl font-bold">Good Evening</h1>
                <p className="text-gray-400">Welcome to your smart home dashboard.</p>
            </header>
            <main className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                 {devices.map(device => (
                    <DeviceCard key={device.id} device={device} onUpdate={updateDeviceState} />
                ))}
            </main>
        </div>
    );
};
