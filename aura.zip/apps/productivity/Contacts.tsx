import React, { useState, useMemo } from 'react';
import type { AppProps, Contact } from '../../types';
import { faker } from '@faker-js/faker';

// --- MOCK DATA ---
const generateContacts = (count: number): Contact[] => {
    return Array.from({ length: count }, () => ({
        id: faker.string.uuid(),
        firstName: faker.person.firstName(),
        lastName: faker.person.lastName(),
        email: faker.internet.email(),
        phone: faker.phone.number(),
        address: faker.location.streetAddress(true),
        notes: faker.lorem.paragraph(),
    })).sort((a,b) => a.lastName.localeCompare(b.lastName));
};
const ALL_CONTACTS = generateContacts(30);

// --- SUB-COMPONENTS ---
const ContactList: React.FC<{ contacts: Contact[], selectedId: string | null, onSelect: (id: string) => void }> = ({ contacts, selectedId, onSelect }) => (
    <aside className="w-64 h-full bg-white border-r border-gray-200 overflow-y-auto">
        {contacts.map(contact => (
            <button key={contact.id} onClick={() => onSelect(contact.id)} className={`w-full text-left p-3 border-b border-gray-200 ${selectedId === contact.id ? 'bg-blue-100' : 'hover:bg-gray-100'}`}>
                <p className="font-semibold text-sm text-gray-800">{contact.firstName} {contact.lastName}</p>
                <p className="text-xs text-gray-500 truncate">{contact.email}</p>
            </button>
        ))}
    </aside>
);

const ContactDetails: React.FC<{ contact: Contact | null }> = ({ contact }) => {
    if (!contact) return <div className="flex-grow flex items-center justify-center text-gray-500">Select a contact</div>;
    return (
        <main className="flex-grow p-8 overflow-y-auto">
            <div className="flex items-center gap-6 mb-8">
                <div className="w-24 h-24 rounded-full bg-gray-300 flex-shrink-0 flex items-center justify-center text-4xl font-bold text-gray-600">
                    {contact.firstName[0]}{contact.lastName[0]}
                </div>
                <div>
                    <h1 className="text-3xl font-bold">{contact.firstName} {contact.lastName}</h1>
                </div>
            </div>
            <div className="space-y-4 text-sm">
                <div>
                    <p className="font-semibold text-gray-500">Email</p>
                    <p className="text-blue-600 hover:underline cursor-pointer">{contact.email}</p>
                </div>
                <div>
                    <p className="font-semibold text-gray-500">Phone</p>
                    <p>{contact.phone}</p>
                </div>
                <div>
                    <p className="font-semibold text-gray-500">Address</p>
                    <p>{contact.address}</p>
                </div>
                 <div>
                    <p className="font-semibold text-gray-500">Notes</p>
                    <p className="text-gray-700">{contact.notes}</p>
                </div>
            </div>
        </main>
    );
};

// --- MAIN COMPONENT ---
export const ContactsApp: React.FC<AppProps> = () => {
    const [contacts] = useState<Contact[]>(ALL_CONTACTS);
    const [selectedContactId, setSelectedContactId] = useState<string | null>(contacts[0]?.id || null);
    const [searchTerm, setSearchTerm] = useState('');

    const filteredContacts = useMemo(() => {
        if (!searchTerm) return contacts;
        const lowerCaseSearch = searchTerm.toLowerCase();
        return contacts.filter(c => 
            `${c.firstName} ${c.lastName}`.toLowerCase().includes(lowerCaseSearch) ||
            c.email.toLowerCase().includes(lowerCaseSearch)
        );
    }, [contacts, searchTerm]);

    const selectedContact = useMemo(() => {
        return contacts.find(c => c.id === selectedContactId) || null;
    }, [contacts, selectedContactId]);

    return (
        <div className="w-full h-full flex flex-col bg-mac-gray">
            <header className="p-2 border-b border-gray-200 bg-white">
                 <input
                    type="search"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Search"
                    className="w-full px-3 py-1.5 bg-gray-100 rounded-lg border-transparent focus:border-blue-500 focus:ring-0 text-sm"
                />
            </header>
            <div className="flex-grow flex overflow-hidden">
                <ContactList contacts={filteredContacts} selectedId={selectedContactId} onSelect={setSelectedContactId} />
                <ContactDetails contact={selectedContact} />
            </div>
        </div>
    );
};
