import React, { useState, useMemo } from 'react';
import type { AppProps, CalendarEvent } from '../../types';
import { faker } from '@faker-js/faker';

const generateEvents = (year: number, month: number): CalendarEvent[] => {
    return Array.from({ length: 5 }, () => {
        const day = Math.floor(Math.random() * 28) + 1;
        const date = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
        return {
            id: faker.string.uuid(),
            date,
            title: faker.lorem.words(3),
            color: ['blue', 'green', 'red', 'purple'][Math.floor(Math.random() * 4)] as 'blue' | 'green' | 'red' | 'purple',
        };
    });
};

const EventPill: React.FC<{ event: CalendarEvent }> = ({ event }) => {
    const colors = {
        blue: 'bg-blue-500',
        green: 'bg-green-500',
        red: 'bg-red-500',
        purple: 'bg-purple-500',
    };
    return (
        <div className={`text-white text-xs px-1.5 py-0.5 rounded-md truncate ${colors[event.color]}`}>
            {event.title}
        </div>
    );
};

export const CalendarApp: React.FC<AppProps> = () => {
    const [currentDate, setCurrentDate] = useState(new Date());

    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();

    const events = useMemo(() => generateEvents(year, month), [year, month]);

    const changeMonth = (delta: number) => {
        setCurrentDate(d => new Date(d.getFullYear(), d.getMonth() + delta, 1));
    };

    const daysInMonth = useMemo(() => {
        const firstDay = new Date(year, month, 1).getDay();
        const daysInMonthCount = new Date(year, month + 1, 0).getDate();
        const days = [];
        for (let i = 0; i < firstDay; i++) days.push(null);
        for (let i = 1; i <= daysInMonthCount; i++) days.push(new Date(year, month, i));
        return days;
    }, [year, month]);

    const weekdays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const today = new Date();

    return (
        <div className="w-full h-full flex flex-col bg-white text-mac-text">
            <header className="flex-shrink-0 flex items-center justify-between p-3 border-b border-gray-200">
                <div className="flex items-center gap-2">
                    <button onClick={() => changeMonth(-1)} className="px-3 py-1 bg-gray-100 rounded hover:bg-gray-200">&lt;</button>
                    <button onClick={() => changeMonth(1)} className="px-3 py-1 bg-gray-100 rounded hover:bg-gray-200">&gt;</button>
                    <button onClick={() => setCurrentDate(new Date())} className="px-3 py-1 bg-gray-100 rounded hover:bg-gray-200 font-semibold text-sm">Today</button>
                </div>
                <h1 className="text-xl font-bold">
                    {currentDate.toLocaleString('default', { month: 'long', year: 'numeric' })}
                </h1>
                <div className="w-40 text-right">
                     <span className="text-sm font-semibold">Month</span>
                </div>
            </header>
            <main className="flex-grow grid grid-cols-7 grid-rows-6">
                {weekdays.map(day => (
                    <div key={day} className="text-center font-semibold text-sm text-gray-500 py-2 border-b border-r border-gray-200">{day}</div>
                ))}
                {daysInMonth.map((day, index) => {
                    const isToday = day && day.toDateString() === today.toDateString();
                    const dayEvents = day ? events.filter(e => e.date === day.toISOString().split('T')[0]) : [];
                    return (
                        <div key={index} className="border-b border-r border-gray-200 p-1.5 overflow-hidden">
                            {day && (
                                <>
                                    <span className={`flex items-center justify-center h-6 w-6 rounded-full text-sm mb-1 ${isToday ? 'bg-mac-blue text-white' : ''}`}>
                                        {day.getDate()}
                                    </span>
                                    <div className="space-y-1">
                                        {dayEvents.map(event => <EventPill key={event.id} event={event} />)}
                                    </div>
                                </>
                            )}
                        </div>
                    );
                })}
            </main>
        </div>
    );
};
