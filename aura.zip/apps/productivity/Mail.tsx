import React, { useState, useMemo } from 'react';
import type { AppProps, Email } from '../../types';
import { faker } from '@faker-js/faker';

// --- MOCK DATA ---
const generateEmails = (count: number, mailbox: 'inbox' | 'sent'): Email[] => {
    return Array.from({ length: count }, (_, i) => ({
        id: faker.string.uuid(),
        senderName: faker.person.fullName(),
        senderEmail: faker.internet.email(),
        subject: faker.lorem.sentence(),
        body: faker.lorem.paragraphs(5),
        timestamp: faker.date.recent().getTime(),
        isRead: Math.random() > 0.5,
        mailbox,
    }));
};
const ALL_EMAILS = [...generateEmails(20, 'inbox'), ...generateEmails(5, 'sent')];


// --- SUB-COMPONENTS ---
const MailboxList: React.FC<{ active: string, onSelect: (m: 'inbox' | 'sent' | 'trash') => void }> = ({ active, onSelect }) => {
    const mailboxes = [
        { id: 'inbox', name: 'Inbox', icon: '📥' },
        { id: 'sent', name: 'Sent', icon: '📤' },
        { id: 'trash', name: 'Trash', icon: '🗑️' },
    ] as const;
    return (
        <aside className="w-56 h-full bg-mac-gray-header/80 p-3 shrink-0 border-r border-black/10">
            {mailboxes.map(mb => (
                <button key={mb.id} onClick={() => onSelect(mb.id)} className={`flex items-center w-full text-left px-3 py-2 rounded-lg gap-3 ${active === mb.id ? 'bg-mac-blue/20 text-mac-blue' : 'hover:bg-gray-200/50'}`}>
                    <span className="text-lg">{mb.icon}</span>
                    <span className="font-medium text-sm">{mb.name}</span>
                </button>
            ))}
        </aside>
    );
};

const EmailList: React.FC<{ emails: Email[], selectedId: string | null, onSelect: (id: string) => void }> = ({ emails, selectedId, onSelect }) => (
    <aside className="w-80 h-full bg-white border-r border-gray-200 overflow-y-auto">
        {emails.map(email => (
            <button key={email.id} onClick={() => onSelect(email.id)} className={`w-full text-left p-3 border-b border-gray-200 ${selectedId === email.id ? 'bg-blue-100' : 'hover:bg-gray-100'}`}>
                <div className="flex justify-between items-start">
                    <p className={`font-semibold text-sm ${!email.isRead ? 'text-black' : 'text-gray-700'}`}>{email.senderName}</p>
                    <p className="text-xs text-gray-500">{new Date(email.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                </div>
                <p className={`text-sm truncate ${!email.isRead ? 'text-black' : 'text-gray-600'}`}>{email.subject}</p>
                <p className="text-xs text-gray-500 truncate">{email.body}</p>
            </button>
        ))}
    </aside>
);

const EmailView: React.FC<{ email: Email | null }> = ({ email }) => {
    if (!email) return <div className="flex-grow flex items-center justify-center text-gray-500">Select an email to read</div>;
    return (
        <main className="flex-grow p-6 overflow-y-auto">
            <h1 className="text-2xl font-bold mb-1">{email.subject}</h1>
            <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-full bg-gray-300 flex items-center justify-center font-bold">{email.senderName[0]}</div>
                <div>
                    <p className="font-semibold">{email.senderName}</p>
                    <p className="text-sm text-gray-600">{`<${email.senderEmail}>`}</p>
                </div>
                <p className="ml-auto text-sm text-gray-500">{new Date(email.timestamp).toLocaleString()}</p>
            </div>
            <div className="prose max-w-none whitespace-pre-wrap">
                {email.body}
            </div>
        </main>
    );
};


// --- MAIN COMPONENT ---
export const MailApp: React.FC<AppProps> = () => {
    const [emails, setEmails] = useState<Email[]>(ALL_EMAILS);
    const [activeMailbox, setActiveMailbox] = useState<'inbox' | 'sent' | 'trash'>('inbox');
    const [selectedEmailId, setSelectedEmailId] = useState<string | null>(null);

    const filteredEmails = useMemo(() => {
        return emails
            .filter(e => e.mailbox === activeMailbox)
            .sort((a, b) => b.timestamp - a.timestamp);
    }, [emails, activeMailbox]);

    const selectedEmail = useMemo(() => {
        return emails.find(e => e.id === selectedEmailId) || null;
    }, [emails, selectedEmailId]);

    const handleSelectEmail = (id: string) => {
        setSelectedEmailId(id);
        setEmails(prev => prev.map(e => e.id === id ? { ...e, isRead: true } : e));
    };

    return (
        <div className="w-full h-full flex bg-mac-gray">
            <MailboxList active={activeMailbox} onSelect={setActiveMailbox} />
            <EmailList emails={filteredEmails} selectedId={selectedEmailId} onSelect={handleSelectEmail} />
            <EmailView email={selectedEmail} />
        </div>
    );
};
