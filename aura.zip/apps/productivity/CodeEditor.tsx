import React, { useState, useEffect, useRef, useCallback } from 'react';
import type { AppProps, VFSFile, VFSFolder, VFSItem } from '../../types';
import { useSettings } from '../../context/SettingsContext';
import { aiService } from '../../utils/aiService';

// --- Helper Functions ---
const useDebounce = (callback: (...args: any[]) => void, delay: number) => {
    const timeoutRef = useRef<number | null>(null);
    return (...args: any[]) => {
        if (timeoutRef.current) clearTimeout(timeoutRef.current);
        timeoutRef.current = window.setTimeout(() => {
            callback(...args);
        }, delay);
    };
};

const highlightSyntax = (code: string) => {
    // Basic JS syntax highlighting
    return code
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/\b(const|let|var|function|return|if|else|for|while|import|export|from|as|new)\b/g, '<span class="text-purple-400">$1</span>')
        .replace(/\b(true|false|null|undefined)\b/g, '<span class="text-blue-400">$1</span>')
        .replace(/(\/\/.*)/g, '<span class="text-gray-500">$1</span>')
        .replace(/(['"`].*?['"`])/g, '<span class="text-green-400">$1</span>')
        .replace(/([\(\)\[\]\{\}])/g, '<span class="text-yellow-400">$1</span>');
};

// --- Sub-Components ---

const FileTree: React.FC<{ items: VFSItem[], allItems: Record<string, VFSItem>, onOpenFile: (id: string) => void, level?: number }> = ({ items, allItems, onOpenFile, level = 0 }) => {
    return (
        <div style={{ paddingLeft: `${level * 12}px` }}>
            {items.sort((a,b) => (a.type > b.type) ? 1 : ((b.type > a.type) ? -1 : a.name.localeCompare(b.name))).map(item => (
                <div key={item.id}>
                    {item.type === 'folder' ? (
                        <div>
                            <span className="text-gray-400">📁 {item.name}</span>
                            <FileTree items={(item as VFSFolder).children.map(id => allItems[id])} allItems={allItems} onOpenFile={onOpenFile} level={level + 1} />
                        </div>
                    ) : (
                        <button onClick={() => onOpenFile(item.id)} className="text-left w-full hover:bg-gray-700 rounded px-1">
                           📄 {item.name}
                        </button>
                    )}
                </div>
            ))}
        </div>
    );
};

const FileExplorer: React.FC<{ onOpenFile: (id: string) => void, onCreateFile: () => void }> = ({ onOpenFile, onCreateFile }) => {
    const { vfs } = useSettings();
    const rootItems = vfs.items[vfs.homeId] ? (vfs.items[vfs.homeId] as VFSFolder).children.map(id => vfs.items[id]) : [];

    return (
        <aside className="w-52 bg-[#252526] p-2 flex flex-col shrink-0">
            <h2 className="text-gray-400 text-xs uppercase font-bold tracking-wider mb-2 px-1">Explorer</h2>
            <div className="flex-grow overflow-y-auto">
                <FileTree items={rootItems} allItems={vfs.items} onOpenFile={onOpenFile} />
            </div>
             <button onClick={onCreateFile} className="mt-2 w-full text-center p-1 bg-gray-600 hover:bg-gray-500 rounded text-xs">New File</button>
        </aside>
    );
};

const Editor: React.FC<{ content: string, onChange: (value: string) => void, onInlineAi: (prompt: string, selection: {start: number, end: number}) => void }> = ({ content, onChange, onInlineAi }) => {
    const textareaRef = useRef<HTMLTextAreaElement>(null);
    const highlightRef = useRef<HTMLElement>(null);
    const lineNumbersRef = useRef<HTMLDivElement>(null);

    const syncScroll = () => {
        if (textareaRef.current && highlightRef.current && lineNumbersRef.current) {
            highlightRef.current.scrollTop = textareaRef.current.scrollTop;
            highlightRef.current.scrollLeft = textareaRef.current.scrollLeft;
            lineNumbersRef.current.scrollTop = textareaRef.current.scrollTop;
        }
    };
    
    const lineCount = content.split('\n').length;

    const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
        if (e.key === 'Tab') {
            e.preventDefault();
            const start = e.currentTarget.selectionStart;
            const end = e.currentTarget.selectionEnd;
            const value = e.currentTarget.value;
            e.currentTarget.value = value.substring(0, start) + '  ' + value.substring(end);
            e.currentTarget.selectionStart = e.currentTarget.selectionEnd = start + 2;
            onChange(e.currentTarget.value);
        }
        if (e.ctrlKey && e.key === 'Enter') {
            e.preventDefault();
            const { selectionStart, value } = e.currentTarget;
            const lineStart = value.lastIndexOf('\n', selectionStart - 1) + 1;
            const lineEnd = value.indexOf('\n', selectionStart);
            const currentLine = value.substring(lineStart, lineEnd === -1 ? undefined : lineEnd);
            
            if (currentLine.trim().startsWith('// ai:')) {
                const prompt = currentLine.trim().substring(6).trim();
                onInlineAi(prompt, {start: lineStart, end: lineEnd === -1 ? value.length : lineEnd});
            }
        }
    };

    return (
        <div className="relative w-full h-full bg-[#1e1e1e] flex">
            <div ref={lineNumbersRef} className="h-full bg-[#1e1e1e] text-right p-2 text-gray-500 select-none">
                {Array.from({ length: lineCount }, (_, i) => <div key={i}>{i + 1}</div>)}
            </div>
            <div className="relative flex-grow h-full">
                <textarea
                    ref={textareaRef}
                    value={content}
                    onChange={(e) => onChange(e.target.value)}
                    onScroll={syncScroll}
                    onKeyDown={handleKeyDown}
                    className="absolute inset-0 w-full h-full p-2 bg-transparent text-transparent caret-white resize-none border-none focus:outline-none z-10"
                    spellCheck="false"
                />
                <pre className="absolute inset-0 w-full h-full p-2 overflow-auto pointer-events-none">
                    <code ref={highlightRef} dangerouslySetInnerHTML={{ __html: highlightSyntax(content) + '\n' }} />
                </pre>
            </div>
        </div>
    );
};

const AiAssistant: React.FC<{ editorRef: React.RefObject<HTMLTextAreaElement>, onCodeInsert: (code: string) => void }> = ({ editorRef, onCodeInsert }) => {
    const [mode, setMode] = useState<'generate' | 'explain' | 'bugs' | 'refactor'>('generate');
    const [prompt, setPrompt] = useState('');
    const [output, setOutput] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const handleAction = async () => {
        setIsLoading(true);
        setOutput('');
        let fullPrompt = '';
        const selectedText = editorRef.current?.value.substring(editorRef.current.selectionStart, editorRef.current.selectionEnd) || '';

        switch(mode) {
            case 'generate':
                fullPrompt = `You are a coding assistant. Generate code for the following prompt: ${prompt}`;
                break;
            case 'explain':
                fullPrompt = `You are a coding assistant. Explain the following code snippet:\n\`\`\`javascript\n${selectedText}\n\`\`\``;
                break;
            case 'bugs':
                 fullPrompt = `You are a code reviewer. Find potential bugs in the following code and suggest fixes:\n\`\`\`javascript\n${selectedText}\n\`\`\``;
                break;
            case 'refactor':
                 fullPrompt = `You are a senior developer. Refactor the following code for clarity and performance:\n\`\`\`javascript\n${selectedText}\n\`\`\``;
                break;
        }

        try {
            const response = await aiService.generateContent(fullPrompt);
            setOutput(response.text);
        } catch (error: any) {
            setOutput(`Error: ${error.message}`);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <aside className="w-80 bg-[#252526] p-3 flex flex-col shrink-0">
            <h2 className="text-gray-400 text-xs uppercase font-bold tracking-wider mb-2">AI Assistant</h2>
            <div className="grid grid-cols-2 gap-1 mb-2">
                {(['generate', 'explain', 'bugs', 'refactor'] as const).map(m => (
                    <button key={m} onClick={() => setMode(m)} className={`p-1 rounded text-xs capitalize ${mode === m ? 'bg-purple-600' : 'bg-gray-700 hover:bg-gray-600'}`}>{m}</button>
                ))}
            </div>
            { (mode === 'generate') && <textarea value={prompt} onChange={e => setPrompt(e.target.value)} placeholder="Enter a prompt..." rows={3} className="w-full bg-[#1e1e1e] p-1 rounded text-xs mb-2 resize-none"/> }
            <button onClick={handleAction} disabled={isLoading} className="w-full p-1 bg-purple-700 hover:bg-purple-600 rounded disabled:opacity-50">{isLoading ? 'Working...' : 'Run AI'}</button>
            <div className="flex-grow bg-[#1e1e1e] mt-2 rounded p-2 overflow-y-auto text-xs whitespace-pre-wrap">
                {output}
            </div>
        </aside>
    );
};

// Main App Component
export const CodeEditorApp: React.FC<AppProps> = ({ windowId }) => {
    const { vfs, createVFSItem, updateVFSFileContent } = useSettings();
    const [openFileIds, setOpenFileIds] = useState<string[]>([]);
    const [activeFileId, setActiveFileId] = useState<string | null>(null);
    const [fileContents, setFileContents] = useState<Record<string, string>>({});

    const editorRef = useRef<HTMLTextAreaElement>(null);

    const openFile = useCallback((fileId: string) => {
        if (!openFileIds.includes(fileId)) {
            setOpenFileIds(prev => [...prev, fileId]);
            const file = vfs.items[fileId] as VFSFile;
            setFileContents(prev => ({ ...prev, [fileId]: file.content || '' }));
        }
        setActiveFileId(fileId);
    }, [openFileIds, vfs.items]);
    
    const closeFile = (fileId: string) => {
        setOpenFileIds(prev => {
            const newIds = prev.filter(id => id !== fileId);
            if(activeFileId === fileId) {
                setActiveFileId(newIds[newIds.length - 1] || null);
            }
            return newIds;
        });
    };

    const handleCreateFile = () => {
        const name = prompt("Enter filename:", "new_file.js");
        if(name) {
            const newFile = createVFSItem('file', vfs.documentsId, name, '// New file created in CodePad');
            if (newFile) openFile(newFile.id);
        }
    };
    
    const handleContentChange = (newContent: string) => {
        if (activeFileId) {
            setFileContents(prev => ({...prev, [activeFileId]: newContent }));
        }
    };
    
    const debouncedSave = useDebounce((id, content) => {
        updateVFSFileContent(id, content);
    }, 1500);

    useEffect(() => {
        if (activeFileId && fileContents[activeFileId] !== undefined) {
            debouncedSave(activeFileId, fileContents[activeFileId]);
        }
    }, [fileContents, activeFileId, debouncedSave]);
    
    const handleInlineAi = async (prompt: string, selection: { start: number, end: number }) => {
        if(!activeFileId) return;
        
        const fullPrompt = `You are an expert programmer writing JavaScript. Generate only the raw code for the following request, without any explanation or markdown formatting: ${prompt}`;
        try {
            const response = await aiService.generateContent(fullPrompt);
            const generatedCode = response.text.trim();
            const currentContent = fileContents[activeFileId];
            const newContent = currentContent.substring(0, selection.start) + generatedCode + currentContent.substring(selection.end);
            handleContentChange(newContent);

        } catch (error) {
            console.error("Inline AI failed", error);
        }
    };

    const activeFileContent = activeFileId ? fileContents[activeFileId] : '';

    return (
        <div className="w-full h-full bg-[#1e1e1e] text-gray-300 font-mono flex text-sm">
            <FileExplorer onOpenFile={openFile} onCreateFile={handleCreateFile}/>
            <main className="flex-grow flex flex-col">
                <div className="flex-shrink-0 bg-[#2d2d2d] flex">
                    {openFileIds.map(id => {
                        const file = vfs.items[id];
                        return (
                            <div key={id} className={`flex items-center px-3 py-2 border-r border-black cursor-pointer ${id === activeFileId ? 'bg-[#1e1e1e]' : 'hover:bg-[#3f3f3f]'}`}>
                                <button onClick={() => setActiveFileId(id)} className="pr-2">{file?.name}</button>
                                <button onClick={() => closeFile(id)} className="text-gray-500 hover:text-white">x</button>
                            </div>
                        )
                    })}
                </div>
                <div className="flex-grow relative">
                    {activeFileId && <Editor key={activeFileId} content={activeFileContent} onChange={handleContentChange} onInlineAi={handleInlineAi} />}
                </div>
            </main>
            <AiAssistant editorRef={editorRef} onCodeInsert={()=>{}} />
        </div>
    );
};
