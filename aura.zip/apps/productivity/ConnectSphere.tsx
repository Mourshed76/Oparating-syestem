import React, { useState, useMemo, useRef, useEffect } from 'react';
import type { AppProps, ConnectSpherePost, User, ConnectSphereComment, Conversation, DirectMessage } from '../../types';
import { useSettings } from '../../context/SettingsContext';

type ViewType = 'feed' | 'profile' | 'messages' | 'friend_requests';

// --- Shared Components ---
const GeneratedAvatar: React.FC<{ username: string; size?: string; className?: string; onClick?: () => void; }> = ({ username, size = 'w-12 h-12', className = '', onClick }) => {
    const gradient = useMemo(() => {
        let hash = 0;
        if (!username) return 'linear-gradient(135deg, #888, #555)';
        for (let i = 0; i < username.length; i++) {
            hash = username.charCodeAt(i) + ((hash << 5) - hash);
        }
        const h = hash % 360;
        return `linear-gradient(135deg, hsl(${h}, 70%, 50%), hsl(${(h + 60) % 360}, 70%, 60%))`;
    }, [username]);

    return <div className={`${size} rounded-full flex-shrink-0 ${className} cursor-pointer`} style={{ background: gradient }} onClick={onClick} />;
};

const formatTimeAgo = (timestamp: number) => {
    const seconds = Math.floor((new Date().getTime() - timestamp) / 1000);
    let interval = seconds / 31536000;
    if (interval > 1) return Math.floor(interval) + "y ago";
    interval = seconds / 2592000;
    if (interval > 1) return Math.floor(interval) + "mo ago";
    interval = seconds / 86400;
    if (interval > 1) return Math.floor(interval) + "d ago";
    interval = seconds / 3600;
    if (interval > 1) return Math.floor(interval) + "h ago";
    interval = seconds / 60;
    if (interval > 1) return Math.floor(interval) + "m ago";
    return Math.floor(seconds) + "s ago";
}

// --- Post Related Components ---
const CommentCard: React.FC<{ comment: ConnectSphereComment, onSelectProfile: (id: string) => void; }> = ({ comment, onSelectProfile }) => (
    <div className="flex items-start gap-3">
        <GeneratedAvatar username={comment.authorName} size="w-8 h-8" onClick={() => onSelectProfile(comment.authorId)}/>
        <div className="bg-black/20 rounded-lg p-2 flex-grow">
            <p className="font-bold text-sm cursor-pointer hover:underline" onClick={() => onSelectProfile(comment.authorId)}>{comment.authorName}</p>
            <p className="text-sm">{comment.content}</p>
        </div>
    </div>
);


const PostCard: React.FC<{ post: ConnectSpherePost; onLike: (id: string) => void; onComment: (postId: string, content: string) => void; onSelectProfile: (id: string) => void; currentUserId: string | null }> = ({ post, onLike, onComment, onSelectProfile, currentUserId }) => {
    const [commentText, setCommentText] = useState('');
    const [showComments, setShowComments] = useState(false);
    const isLiked = currentUserId ? post.likedBy.includes(currentUserId) : false;

    const handleCommentSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if(!commentText.trim()) return;
        onComment(post.id, commentText);
        setCommentText('');
    };
    
    return (
        <div className="bg-white/10 backdrop-blur-lg border border-white/20 rounded-xl shadow-lg p-5 text-white">
            <div className="flex items-center gap-4 mb-4">
                <GeneratedAvatar username={post.authorName} size="w-12 h-12" onClick={() => onSelectProfile(post.authorId)}/>
                <div>
                    <p className="font-bold text-lg cursor-pointer hover:underline" onClick={() => onSelectProfile(post.authorId)}>{post.authorName}</p>
                    <p className="text-xs text-gray-300">{formatTimeAgo(post.timestamp)}</p>
                </div>
            </div>
            <p className="whitespace-pre-wrap text-base mb-4">{post.content}</p>
            {post.imageUrl && <img src={post.imageUrl} alt="Post content" className="rounded-lg w-full mb-4" />}
            <div className="flex items-center gap-6 text-gray-300 border-t border-b border-white/10 py-2">
                <button onClick={() => onLike(post.id)} className={`flex items-center gap-2 hover:text-pink-400 transition-colors ${isLiked ? 'text-pink-500' : ''}`}>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill={isLiked ? 'currentColor' : 'none'} viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4.318 6.318a4.5 4.5 0 016.364 0L12 7.5l1.318-1.182a4.5 4.5 0 116.364 6.364L12 21l-7.682-7.682a4.5 4.5 0 010-6.364z" /></svg>
                    <span>{post.likes > 0 ? post.likes : ''}</span>
                </button>
                 <button onClick={() => setShowComments(!showComments)} className="flex items-center gap-2 hover:text-cyan-400 transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg>
                    <span>{post.comments.length > 0 ? post.comments.length : ''}</span>
                </button>
            </div>
            {showComments && (
                 <div className="mt-4 space-y-4">
                    {post.comments.map(comment => <CommentCard key={comment.id} comment={comment} onSelectProfile={onSelectProfile}/>)}
                    <form onSubmit={handleCommentSubmit} className="flex items-center gap-2">
                        <input value={commentText} onChange={e => setCommentText(e.target.value)} type="text" placeholder="Write a comment..." className="w-full bg-black/20 text-white px-3 py-1.5 rounded-full focus:outline-none focus:ring-1 focus:ring-purple-400 text-sm"/>
                        <button type="submit" className="text-sm font-semibold text-purple-400 hover:text-white disabled:opacity-50" disabled={!commentText.trim()}>Post</button>
                    </form>
                </div>
            )}
        </div>
    );
};

// --- Feed View ---
const FeedView: React.FC<{
    posts: ConnectSpherePost[];
    currentUser: User | null;
    onLike: (id: string) => void;
    onComment: (postId: string, content: string) => void;
    onSelectProfile: (id: string) => void;
}> = ({ posts, currentUser, onLike, onComment, onSelectProfile }) => {
    const { createConnectSpherePost } = useSettings();
    const [content, setContent] = useState('');
    const [imageUrl, setImageUrl] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!content.trim()) return;
        createConnectSpherePost(content, imageUrl);
        setContent('');
        setImageUrl('');
    };

    const addRandomImage = () => {
        const seed = Math.random().toString(36).substring(7);
        setImageUrl(`https://picsum.photos/seed/${seed}/600/400`);
    };

    return (
        <div className="p-5 space-y-5">
            <div className="bg-white/10 backdrop-blur-lg border border-white/20 rounded-xl shadow-lg p-5">
                <form onSubmit={handleSubmit} className="flex gap-4">
                    <GeneratedAvatar username={currentUser?.username || 'G'} />
                    <div className="flex-grow flex flex-col gap-3">
                        <textarea value={content} onChange={(e) => setContent(e.target.value)} placeholder="What's happening?" className="w-full p-3 rounded-lg bg-black/20 border border-white/10 resize-none focus:outline-none focus:ring-2 focus:ring-purple-400 text-white placeholder-gray-400" rows={3}/>
                        {imageUrl && <img src={imageUrl} alt="Preview" className="rounded-lg w-full" />}
                        <div className="flex justify-between items-center">
                            <button type="button" onClick={addRandomImage} className="text-gray-300 hover:text-white">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                            </button>
                            <button type="submit" className="px-5 py-2 bg-gradient-to-r from-purple-500 to-indigo-600 text-white rounded-full font-semibold hover:opacity-90 disabled:opacity-50" disabled={!content.trim()}>Post</button>
                        </div>
                    </div>
                </form>
            </div>
            {posts.map(post => <PostCard key={post.id} post={post} onLike={onLike} onComment={onComment} onSelectProfile={onSelectProfile} currentUserId={currentUser?.id || null} />)}
        </div>
    );
};

// --- Profile View ---
const ProfileView: React.FC<{ user: User, currentUser: User | null; posts: ConnectSpherePost[]; onLike: (id: string) => void; onComment: (postId: string, content: string) => void; onSelectProfile: (id: string) => void; onFriendAction: (id: string) => void; }> = ({ user, currentUser, posts, onLike, onComment, onSelectProfile, onFriendAction }) => {
    const isFriend = currentUser?.friends.includes(user.id);
    const hasSentRequest = user.friendRequests.some(r => r.from === currentUser?.id);
    const isSelf = currentUser?.id === user.id;

    const FriendButton = () => {
        if(isSelf) return null;
        if(isFriend) return <span className="px-4 py-1 bg-green-500/30 text-green-300 rounded-full text-sm">Friends</span>
        if(hasSentRequest) return <span className="px-4 py-1 bg-gray-500/30 text-gray-300 rounded-full text-sm">Request Sent</span>
        return <button onClick={() => onFriendAction(user.id)} className="px-4 py-1 bg-blue-500 hover:bg-blue-600 rounded-full text-sm">Add Friend</button>
    }

    return (
        <div>
            <div className="h-48 bg-gray-700 relative">
                <img src={`https://picsum.photos/seed/${user.coverPhotoSeed}/1000/200`} className="w-full h-full object-cover"/>
                 <div className="absolute -bottom-16 left-8">
                     <GeneratedAvatar username={user.username} size="w-32 h-32" className="border-4 border-gray-800"/>
                 </div>
            </div>
            <div className="p-8 pt-4 bg-gray-900/50 flex justify-end">
                <FriendButton />
            </div>
            <div className="p-8 pt-4 bg-gray-800/10">
                <h2 className="text-3xl font-bold text-white">{user.username}</h2>
                <p className="text-gray-400">@{user.username.toLowerCase()}</p>
                <p className="text-gray-300 mt-2 text-sm">{user.bio}</p>
            </div>
            <div className="p-5 space-y-5">
                <h3 className="text-xl font-bold text-white">Posts</h3>
                {posts.map(post => <PostCard key={post.id} post={post} onLike={onLike} onComment={onComment} onSelectProfile={onSelectProfile} currentUserId={currentUser?.id || null}/>)}
            </div>
        </div>
    );
};

// --- Messages View ---
const MessagesView: React.FC<{
    conversations: Conversation[],
    users: User[],
    currentUser: User,
    onSendMessage: (toId: string, content: string) => void
}> = ({ conversations, users, currentUser, onSendMessage }) => {
    const [activeConvoId, setActiveConvoId] = useState<string | null>(null);
    const [messageText, setMessageText] = useState('');
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const activeConversation = useMemo(() => conversations.find(c => c.id === activeConvoId), [activeConvoId, conversations]);
    const otherParticipantId = activeConversation?.participants.find(p => p !== currentUser.id);
    const otherUser = users.find(u => u.id === otherParticipantId);
    
    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [activeConversation]);

    const handleSendMessage = (e: React.FormEvent) => {
        e.preventDefault();
        if(!messageText.trim() || !otherParticipantId) return;
        onSendMessage(otherParticipantId, messageText);
        setMessageText('');
    };

    return (
        <div className="h-full grid grid-cols-[300px_1fr]">
            <aside className="h-full border-r border-white/10 flex flex-col">
                <div className="p-4 border-b border-white/10"><h2 className="font-bold text-xl">Messages</h2></div>
                <div className="flex-grow overflow-y-auto">
                    {conversations.map(convo => {
                        const otherUserId = convo.participants.find(p => p !== currentUser.id);
                        const otherUser = users.find(u => u.id === otherUserId);
                        const lastMessage = convo.messages[convo.messages.length - 1];
                        return (
                            <button key={convo.id} onClick={() => setActiveConvoId(convo.id)} className={`w-full flex items-center gap-3 p-3 text-left hover:bg-white/5 ${activeConvoId === convo.id ? 'bg-white/10' : ''}`}>
                                <GeneratedAvatar username={otherUser?.username || 'U'} size="w-10 h-10"/>
                                <div className="flex-grow overflow-hidden">
                                    <p className="font-semibold">{otherUser?.username}</p>
                                    <p className="text-xs text-gray-400 truncate">{lastMessage.content}</p>
                                </div>
                            </button>
                        );
                    })}
                </div>
            </aside>
            <main className="h-full flex flex-col">
                {activeConversation && otherUser ? (
                     <>
                        <div className="p-3 border-b border-white/10 flex items-center gap-3">
                             <GeneratedAvatar username={otherUser.username} size="w-10 h-10"/>
                             <h3 className="font-bold">{otherUser.username}</h3>
                        </div>
                        <div className="flex-grow p-4 overflow-y-auto flex flex-col gap-4">
                            {activeConversation.messages.map(msg => (
                                <div key={msg.id} className={`flex items-end gap-2 ${msg.senderId === currentUser.id ? 'justify-end' : 'justify-start'}`}>
                                    <div className={`max-w-md px-3 py-2 rounded-2xl ${msg.senderId === currentUser.id ? 'bg-purple-600' : 'bg-white/20'}`}>
                                        {msg.content}
                                    </div>
                                </div>
                            ))}
                            <div ref={messagesEndRef}/>
                        </div>
                        <form onSubmit={handleSendMessage} className="p-3 border-t border-white/10 flex gap-2">
                             <input value={messageText} onChange={e => setMessageText(e.target.value)} type="text" placeholder="Send a message..." className="w-full bg-black/20 text-white px-3 py-2 rounded-full focus:outline-none focus:ring-1 focus:ring-purple-400 text-sm"/>
                             <button type="submit" disabled={!messageText.trim()} className="px-4 py-2 bg-purple-600 text-white rounded-full font-semibold text-sm disabled:opacity-50">Send</button>
                        </form>
                    </>
                ) : (
                    <div className="flex-grow flex items-center justify-center text-gray-400">Select a conversation</div>
                )}
            </main>
        </div>
    );
}

// --- Friend Requests View ---
const FriendRequestsView: React.FC<{
    requests: {from: string}[],
    users: User[],
    onAccept: (id: string) => void,
    onDecline: (id: string) => void
}> = ({ requests, users, onAccept, onDecline }) => {
    return (
         <div className="p-5 space-y-5">
            <h2 className="font-bold text-2xl">Friend Requests</h2>
            {requests.length === 0 && <p className="text-gray-400">No new friend requests.</p>}
            {requests.map(req => {
                const user = users.find(u => u.id === req.from);
                if (!user) return null;
                return (
                    <div key={req.from} className="bg-white/10 p-4 rounded-lg flex items-center justify-between">
                        <div className="flex items-center gap-4">
                            <GeneratedAvatar username={user.username} size="w-12 h-12"/>
                            <div>
                                <p className="font-bold">{user.username}</p>
                                <p className="text-sm text-gray-400">Wants to be your friend.</p>
                            </div>
                        </div>
                        <div className="flex gap-2">
                            <button onClick={() => onAccept(req.from)} className="px-4 py-1 bg-green-600 hover:bg-green-700 rounded-full text-sm">Accept</button>
                            <button onClick={() => onDecline(req.from)} className="px-4 py-1 bg-gray-600 hover:bg-gray-700 rounded-full text-sm">Decline</button>
                        </div>
                    </div>
                )
            })}
        </div>
    )
};


// --- Main App Component ---
export const ConnectSphereApp: React.FC<AppProps> = () => {
    const { connectSphereState, users, currentUser, toggleLikeConnectSpherePost, addConnectSphereComment, sendFriendRequest, acceptFriendRequest, declineFriendRequest, sendDirectMessage } = useSettings();
    const [view, setView] = useState<{ type: ViewType, id?: string }>({ type: 'feed' });
    
    const friendRequests = currentUser?.friendRequests || [];
    
    const handleNavigation = (type: ViewType, id?: string) => {
        setView({ type, id });
    };

    const sortedPosts = useMemo(() => [...connectSphereState.posts].sort((a, b) => b.timestamp - a.timestamp), [connectSphereState.posts]);
    const sortedConversations = useMemo(() => {
         return [...connectSphereState.conversations].sort((a, b) => b.messages[b.messages.length - 1].timestamp - a.messages[a.messages.length - 1].timestamp)
    }, [connectSphereState.conversations]);
    
    const profileUser = useMemo(() => users.find(u => u.id === view.id), [view, users]);

    const MainContent = () => {
        if (!currentUser) return <div className="flex items-center justify-center h-full">Please log in.</div>;

        switch(view.type) {
            case 'profile':
                if(!profileUser) return <div className="flex items-center justify-center h-full">User not found.</div>;
                return <ProfileView user={profileUser} currentUser={currentUser} posts={sortedPosts.filter(p => p.authorId === profileUser.id)} onLike={toggleLikeConnectSpherePost} onComment={addConnectSphereComment} onSelectProfile={(id) => handleNavigation('profile', id)} onFriendAction={sendFriendRequest}/>;
            case 'messages':
                return <MessagesView conversations={sortedConversations.filter(c => c.participants.includes(currentUser.id))} users={users} currentUser={currentUser} onSendMessage={sendDirectMessage} />;
            case 'friend_requests':
                return <FriendRequestsView requests={friendRequests} users={users} onAccept={acceptFriendRequest} onDecline={declineFriendRequest}/>
            case 'feed':
            default:
                return <FeedView posts={sortedPosts} currentUser={currentUser} onLike={toggleLikeConnectSpherePost} onComment={addConnectSphereComment} onSelectProfile={(id) => handleNavigation('profile', id)}/>;
        }
    };
    
    return (
        <div className="w-full h-full bg-gray-900 text-white font-sans grid grid-cols-[280px_1fr] overflow-hidden">
            <aside className="bg-black/20 p-6 flex flex-col gap-6 border-r border-white/10">
                <h1 className="text-2xl font-bold">ConnectSphere</h1>
                <nav className="space-y-2">
                    <button onClick={() => handleNavigation('feed')} className={`flex items-center gap-4 text-lg w-full p-3 rounded-lg hover:bg-white/10 transition-colors ${view.type === 'feed' ? 'bg-white/10' : ''}`}><svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg> Home</button>
                    <button onClick={() => handleNavigation('profile', currentUser?.id)} className={`flex items-center gap-4 text-lg w-full p-3 rounded-lg hover:bg-white/10 transition-colors ${view.type === 'profile' && view.id === currentUser?.id ? 'bg-white/10' : ''}`}><svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg> Profile</button>
                    <button onClick={() => handleNavigation('messages')} className={`flex items-center justify-between text-lg w-full p-3 rounded-lg hover:bg-white/10 transition-colors ${view.type === 'messages' ? 'bg-white/10' : ''}`}>
                         <span className="flex items-center gap-4"><svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg> Messages</span>
                    </button>
                    <button onClick={() => handleNavigation('friend_requests')} className={`flex items-center justify-between text-lg w-full p-3 rounded-lg hover:bg-white/10 transition-colors ${view.type === 'friend_requests' ? 'bg-white/10' : ''}`}>
                        <span className="flex items-center gap-4"><svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M15 21a6 6 0 00-9-5.197M15 11a4 4 0 110-5.292M12 4.354a4 4 0 100 5.292" /></svg> Friends</span>
                        {friendRequests.length > 0 && <span className="bg-red-500 text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">{friendRequests.length}</span>}
                    </button>
                </nav>
                 <div className="mt-auto flex items-center gap-4 bg-black/30 p-3 rounded-lg">
                    <GeneratedAvatar username={currentUser?.username || 'G'} size="w-10 h-10"/>
                    <div>
                        <p className="font-semibold">{currentUser?.username}</p>
                        <p className="text-xs text-gray-400">Online</p>
                    </div>
                 </div>
            </aside>

            <main className="overflow-y-auto">
                 <MainContent />
            </main>
        </div>
    );
};