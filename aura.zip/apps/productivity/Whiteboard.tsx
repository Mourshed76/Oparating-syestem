import React, { useState, useRef, useEffect, useCallback } from 'react';
import type { AppProps } from '../../types';

export const WhiteboardApp: React.FC<AppProps> = () => {
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const [isDrawing, setIsDrawing] = useState(false);
    const [color, setColor] = useState('#000000');
    const [brushSize, setBrushSize] = useState(5);

    const getContext = useCallback(() => canvasRef.current?.getContext('2d'), []);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (canvas) {
            // Set initial canvas size
            canvas.width = canvas.offsetWidth;
            canvas.height = canvas.offsetHeight;
            // Fill background white
            const ctx = getContext();
            if (ctx) {
                ctx.fillStyle = 'white';
                ctx.fillRect(0, 0, canvas.width, canvas.height);
            }
        }
    }, [getContext]);

    const startDrawing = ({ nativeEvent }: React.MouseEvent) => {
        const { offsetX, offsetY } = nativeEvent;
        const ctx = getContext();
        if (ctx) {
            ctx.strokeStyle = color;
            ctx.lineWidth = brushSize;
            ctx.lineCap = 'round';
            ctx.beginPath();
            ctx.moveTo(offsetX, offsetY);
            setIsDrawing(true);
        }
    };

    const draw = ({ nativeEvent }: React.MouseEvent) => {
        if (!isDrawing) return;
        const { offsetX, offsetY } = nativeEvent;
        const ctx = getContext();
        if (ctx) {
            ctx.lineTo(offsetX, offsetY);
            ctx.stroke();
        }
    };

    const stopDrawing = () => {
        getContext()?.closePath();
        setIsDrawing(false);
    };

    const clearCanvas = () => {
        const canvas = canvasRef.current;
        const ctx = getContext();
        if (canvas && ctx) {
            ctx.fillStyle = 'white';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
        }
    };
    
    const colors = ['#000000', '#ef4444', '#f97316', '#eab308', '#22c55e', '#3b82f6', '#8b5cf6'];

    return (
        <div className="w-full h-full flex flex-col bg-gray-200">
            <header className="flex-shrink-0 p-2 bg-white/80 backdrop-blur-md border-b border-gray-300 flex items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                    <span className="text-sm font-semibold">Color:</span>
                    <div className="flex gap-2">
                        {colors.map(c => (
                            <button key={c} onClick={() => setColor(c)} style={{ backgroundColor: c }} className={`w-6 h-6 rounded-full ${color === c ? 'ring-2 ring-offset-2 ring-blue-500' : ''}`} />
                        ))}
                    </div>
                     <input type="color" value={color} onChange={e => setColor(e.target.value)} className="w-8 h-8"/>
                </div>
                 <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold">Size:</span>
                    <input type="range" min="1" max="50" value={brushSize} onChange={e => setBrushSize(Number(e.target.value))} />
                </div>
                <button onClick={clearCanvas} className="px-3 py-1 bg-gray-600 text-white rounded-md text-sm hover:bg-gray-700">Clear</button>
            </header>
            <main className="flex-grow p-4">
                 <canvas
                    ref={canvasRef}
                    onMouseDown={startDrawing}
                    onMouseMove={draw}
                    onMouseUp={stopDrawing}
                    onMouseLeave={stopDrawing}
                    className="w-full h-full bg-white rounded-lg shadow-lg cursor-crosshair"
                />
            </main>
        </div>
    );
};
