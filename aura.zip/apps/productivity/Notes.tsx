import React, { useState, useMemo, useEffect, useCallback, useRef } from 'react';
import type { AppProps, Note, NoteFolder, NotesState } from '../../types';
import { useSettings } from '../../context/SettingsContext';
import { aiService } from '../../utils/aiService';

// --- Sub-components ---

const AiToolbar: React.FC<{ onAction: (action: 'summarize' | 'improve' | 'correct') => void, isLoading: boolean }> = ({ onAction, isLoading }) => {
    const actions = [
        { id: 'summarize', label: 'Summarize' },
        { id: 'improve', label: 'Improve Writing' },
        { id: 'correct', label: 'Correct Grammar' },
    ] as const;

    return (
        <div className="p-1 border-b border-yellow-200/50 flex items-center justify-center gap-2">
            <span className="text-sm font-semibold text-purple-700 mr-2">✨ AI Assist:</span>
            {actions.map(action => (
                <button key={action.id} onClick={() => onAction(action.id)} disabled={isLoading} className="px-2 py-1 text-xs bg-purple-100 text-purple-800 rounded hover:bg-purple-200 disabled:opacity-50">
                    {isLoading ? 'Thinking...' : action.label}
                </button>
            ))}
        </div>
    );
};


const NoteListItem: React.FC<{ note: Note; isActive: boolean; onClick: () => void }> = ({ note, isActive, onClick }) => {
    const subtitle = new Date(note.updatedAt).toLocaleDateString([], { month: 'short', day: 'numeric' });
    const preview = note.content.replace(/<[^>]+>/g, '').substring(0, 40) + '...';

    return (
        <button
            onClick={onClick}
            className={`w-full text-left p-3 rounded-lg border-b border-gray-200/50 ${
                isActive ? 'bg-yellow-200/60' : 'hover:bg-gray-200/40'
            }`}
        >
            <h3 className="font-bold text-sm truncate text-gray-800">{note.title}</h3>
            <p className="text-xs text-gray-500">{subtitle} <span className="text-gray-400">{preview}</span></p>
        </button>
    );
};

const FolderItem: React.FC<{ folder: NoteFolder, isActive: boolean, onClick: () => void }> = ({ folder, isActive, onClick }) => (
    <button onClick={onClick} className={`flex items-center w-full text-left px-3 py-2 rounded-lg ${isActive ? 'bg-yellow-200/60' : 'hover:bg-gray-200/40'}`}>
        <span>📁</span>
        <span className="ml-2 font-medium text-sm">{folder.name}</span>
    </button>
);


// --- Main Component ---
export const NotesApp: React.FC<AppProps> = () => {
    const { notesState, createNote, updateNote, deleteNote, createNoteFolder } = useSettings();
    const [activeFolderId, setActiveFolderId] = useState<string>('default');
    const [activeNoteId, setActiveNoteId] = useState<string | null>(null);
    const [searchTerm, setSearchTerm] = useState('');
    const [isAiLoading, setIsAiLoading] = useState(false);
    const editorRef = useRef<HTMLDivElement>(null);

    const filteredNotes = useMemo(() => {
        return notesState.notes
            .filter(note => {
                const inFolder = note.folderId === activeFolderId;
                if (!searchTerm) return inFolder;
                const searchTermLower = searchTerm.toLowerCase();
                const inSearch = note.title.toLowerCase().includes(searchTermLower) || note.content.toLowerCase().includes(searchTermLower);
                return inFolder && inSearch;
            });
    }, [notesState.notes, activeFolderId, searchTerm]);

    const activeNote = useMemo(() => notesState.notes.find(n => n.id === activeNoteId), [notesState.notes, activeNoteId]);

    useEffect(() => {
        if (activeNote && editorRef.current) {
            editorRef.current.innerHTML = activeNote.content;
        }
    }, [activeNote]);
    
    useEffect(() => {
        const firstNoteInFolder = filteredNotes[0];
        setActiveNoteId(firstNoteInFolder?.id || null);
    }, [activeFolderId]);


    const handleCreateNote = () => {
        const newNote = createNote(activeFolderId);
        setActiveNoteId(newNote.id);
    };

    const handleDeleteNote = () => {
        if (activeNoteId) {
            deleteNote(activeNoteId);
            setActiveNoteId(null);
        }
    };
    
    const handleContentChange = (e: React.FormEvent<HTMLDivElement>) => {
        if (activeNote) {
            updateNote(activeNote.id, { content: e.currentTarget.innerHTML });
        }
    };
    
    const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (activeNote) {
            updateNote(activeNote.id, { title: e.target.value });
        }
    }
    
    const handleNewFolder = () => {
        const name = prompt("Enter new folder name:");
        if (name) createNoteFolder(name);
    }

    const handleAiAction = async (action: 'summarize' | 'improve' | 'correct') => {
        if (!activeNote || !editorRef.current) return;
        setIsAiLoading(true);

        const content = editorRef.current.innerText;
        let prompt = '';
        switch (action) {
            case 'summarize': prompt = `Summarize the following text:\n\n${content}`; break;
            case 'improve': prompt = `Improve the writing of the following text, keeping the original meaning but making it more clear, concise, and engaging:\n\n${content}`; break;
            case 'correct': prompt = `Correct any spelling and grammar mistakes in the following text. Only output the corrected text, without any explanation:\n\n${content}`; break;
        }

        try {
            const response = await aiService.generateContent(prompt);
            const newContent = response.text.replace(/\n/g, '<br>'); // Convert newlines to breaks for HTML
            if (editorRef.current) {
                editorRef.current.innerHTML = newContent;
            }
            updateNote(activeNote.id, { content: newContent });
        } catch (error) {
            console.error("AI action failed:", error);
            // You might want to show an error to the user
        } finally {
            setIsAiLoading(false);
        }
    };


    return (
        <div className="w-full h-full flex bg-[#fffbeb]">
            <aside className="w-64 h-full bg-yellow-100/50 p-2 shrink-0 border-r border-yellow-200/50 flex flex-col">
                <input type="text" placeholder="Search All Notes..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="w-full px-2 py-1 mb-2 rounded-md border-yellow-300 bg-white/50 text-sm" />
                <div className="mb-2">
                    <h3 className="text-xs font-bold text-gray-500 uppercase px-3 mb-1">Folders</h3>
                    {notesState.folders.map(folder => (
                        <FolderItem key={folder.id} folder={folder} isActive={folder.id === activeFolderId} onClick={() => setActiveFolderId(folder.id)} />
                    ))}
                    <button onClick={handleNewFolder} className="text-sm text-blue-600 px-3 py-1 hover:bg-yellow-200/50 rounded-md w-full text-left">+ New Folder</button>
                </div>
                <div className="flex-grow overflow-y-auto space-y-1 border-t border-yellow-200/50 pt-2">
                    {filteredNotes.map(note => (
                        <NoteListItem key={note.id} note={note} isActive={note.id === activeNoteId} onClick={() => setActiveNoteId(note.id)} />
                    ))}
                </div>
                <div className="flex-shrink-0 p-1 flex items-center justify-between border-t border-yellow-200/50">
                    <button onClick={handleCreateNote} className="text-gray-500 hover:text-black text-xl p-1 font-mono">+</button>
                    <button onClick={handleDeleteNote} disabled={!activeNoteId} className="text-gray-500 hover:text-red-500 disabled:opacity-50 text-xl p-1">🗑️</button>
                </div>
            </aside>
            <main className="flex-grow flex flex-col">
                {activeNote ? (
                    <>
                         <div className="flex items-center border-b border-yellow-200/50 p-2">
                            <input type="text" value={activeNote.title} onChange={handleTitleChange} className="w-full text-center text-lg font-semibold bg-transparent focus:outline-none focus:ring-0" placeholder="Note Title"/>
                        </div>
                        <AiToolbar onAction={handleAiAction} isLoading={isAiLoading} />
                        <div
                            ref={editorRef}
                            key={activeNote.id}
                            contentEditable
                            onInput={handleContentChange}
                            className="w-full flex-grow p-6 resize-none border-none focus:ring-0 focus:outline-none bg-transparent text-[#3e2723] font-serif text-lg leading-relaxed overflow-y-auto"
                            spellCheck="false"
                        />
                    </>
                ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center text-gray-500">
                        <div className="text-3xl mb-2">📝</div>
                        <h2 className="text-xl font-semibold">{searchTerm ? 'No matching notes' : 'No Note Selected'}</h2>
                        <p>{searchTerm ? 'Clear search or select another folder.' : 'Create a new note to get started.'}</p>
                    </div>
                )}
            </main>
        </div>
    );
};