import React, { useState, useRef, useEffect } from 'react';
import type { AppProps } from '../../types';

interface Memo {
    id: string;
    name: string;
    blobUrl: string;
    duration: number; // in seconds
}

export const VoiceMemosApp: React.FC<AppProps> = () => {
    const [memos, setMemos] = useState<Memo[]>([]);
    const [isRecording, setIsRecording] = useState(false);
    const [currentAudioUrl, setCurrentAudioUrl] = useState<string | null>(null);
    const mediaRecorderRef = useRef<MediaRecorder | null>(null);
    const audioChunksRef = useRef<Blob[]>([]);
    const recordingStartTimeRef = useRef<number>(0);

    const startRecording = async () => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            mediaRecorderRef.current = new MediaRecorder(stream);
            mediaRecorderRef.current.ondataavailable = event => {
                audioChunksRef.current.push(event.data);
            };
            mediaRecorderRef.current.onstop = () => {
                const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' });
                const audioUrl = URL.createObjectURL(audioBlob);
                const duration = Math.round((Date.now() - recordingStartTimeRef.current) / 1000);
                const newMemo: Memo = {
                    id: `memo-${Date.now()}`,
                    name: `New Recording ${memos.length + 1}`,
                    blobUrl: audioUrl,
                    duration
                };
                setMemos(prev => [newMemo, ...prev]);
                audioChunksRef.current = [];
            };
            mediaRecorderRef.current.start();
            recordingStartTimeRef.current = Date.now();
            setIsRecording(true);
        } catch (err) {
            console.error("Error accessing microphone:", err);
            alert("Could not access microphone. Please enable permissions.");
        }
    };

    const stopRecording = () => {
        if (mediaRecorderRef.current) {
            mediaRecorderRef.current.stop();
            // Stop all tracks to release the microphone
            mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
        }
        setIsRecording(false);
    };

    const formatDuration = (sec: number) => {
        const minutes = Math.floor(sec / 60);
        const seconds = sec % 60;
        return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }

    return (
        <div className="w-full h-full flex flex-col bg-gray-100">
            <header className="p-4 border-b border-gray-200">
                <h1 className="text-2xl font-bold text-mac-text">Voice Memos</h1>
            </header>
            <main className="flex-grow overflow-y-auto p-4 space-y-2">
                {memos.length === 0 && !isRecording && <p className="text-center text-gray-500">No recordings yet.</p>}
                {memos.map(memo => (
                    <div key={memo.id} onClick={() => setCurrentAudioUrl(memo.blobUrl)} className="p-3 bg-white rounded-lg shadow-sm cursor-pointer hover:bg-gray-50">
                        <p className="font-semibold">{memo.name}</p>
                        <p className="text-sm text-gray-500">{formatDuration(memo.duration)}</p>
                    </div>
                ))}
            </main>
            <footer className="p-4 border-t border-gray-200 flex flex-col items-center">
                {currentAudioUrl && (
                    <audio key={currentAudioUrl} controls autoPlay className="w-full mb-4">
                        <source src={currentAudioUrl} type="audio/wav" />
                    </audio>
                )}
                <button
                    onClick={isRecording ? stopRecording : startRecording}
                    className={`w-16 h-16 rounded-full transition-colors ${isRecording ? 'bg-red-500 animate-pulse' : 'bg-gray-300'}`}
                    aria-label={isRecording ? 'Stop recording' : 'Start recording'}
                >
                    <div className={`w-6 h-6 m-auto transition-all ${isRecording ? 'bg-white rounded-sm' : 'bg-red-500 rounded-full'}`}></div>
                </button>
            </footer>
        </div>
    );
};
