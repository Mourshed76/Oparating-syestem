import React from 'react';
import type { AppProps } from '../../types';

export const MapsApp: React.FC<AppProps> = () => {
    const isOnline = navigator.onLine;

    return (
        <div className="w-full h-full flex flex-col bg-gray-100">
            <header className="flex-shrink-0 p-2 bg-white/80 backdrop-blur-md border-b border-gray-200">
                <input 
                    type="text"
                    placeholder="Search for a place or address"
                    className="w-full px-4 py-2 bg-gray-100 rounded-lg border-2 border-transparent focus:border-blue-500 focus:ring-0 focus:outline-none transition-all"
                    defaultValue="San Francisco, CA"
                    disabled={!isOnline}
                />
            </header>
            <main className="flex-grow">
                {isOnline ? (
                    <iframe
                        width="100%"
                        height="100%"
                        style={{ border: 0 }}
                        loading="lazy"
                        allowFullScreen
                        src="https://www.openstreetmap.org/export/embed.html?bbox=-122.51365661621095%2C37.70813734015093%2C-122.35717773437501%2C37.83239299448074&layer=mapnik"
                    ></iframe>
                ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center text-gray-600 text-center p-4">
                         <h2 className="text-xl font-bold mb-2">You are offline</h2>
                         <p>Maps requires an internet connection to load and display map data.</p>
                    </div>
                )}
            </main>
        </div>
    );
};
