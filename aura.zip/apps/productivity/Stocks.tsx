import React, { useState, useEffect } from 'react';
import type { AppProps } from '../../types';

// Mock Data
const initialStocks = [
  { ticker: 'AURA', name: 'Aura Systems', price: 172.50, change: 2.55, changePercent: 1.50 },
  { ticker: 'APPL', name: 'Apple Inc.', price: 145.11, change: -1.22, changePercent: -0.83 },
  { ticker: 'GOOG', name: 'Alphabet Inc.', price: 2734.87, change: 12.65, changePercent: 0.46 },
  { ticker: 'TSLA', name: 'Tesla, Inc.', price: 730.91, change: -5.12, changePercent: -0.69 },
];

export const StocksApp: React.FC<AppProps> = () => {
  const [stocks, setStocks] = useState(initialStocks);

  useEffect(() => {
    const interval = setInterval(() => {
      setStocks(prevStocks => prevStocks.map(stock => {
        const change = (Math.random() - 0.5) * (stock.price / 100);
        const newPrice = Math.max(0, stock.price + change);
        return {
          ...stock,
          price: newPrice,
          change: change,
          changePercent: (change / stock.price) * 100,
        };
      }));
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="w-full h-full bg-gray-900 text-white flex flex-col font-sans">
      <header className="p-4 border-b border-gray-700 flex justify-between items-center">
        <h1 className="text-2xl font-bold">Stocks</h1>
        <p className="text-sm text-gray-400">{new Date().toLocaleDateString()}</p>
      </header>
      <main className="flex-grow overflow-y-auto">
        <div className="p-4 space-y-2">
          {stocks.map(stock => (
            <div key={stock.ticker} className="flex justify-between items-center p-3 bg-gray-800 rounded-lg">
              <div>
                <p className="font-bold text-lg">{stock.ticker}</p>
                <p className="text-xs text-gray-400">{stock.name}</p>
              </div>
              <div>
                <p className="font-mono text-lg text-right">{stock.price.toFixed(2)}</p>
                <div className={`px-2 py-0.5 rounded text-right font-mono text-sm ${stock.change >= 0 ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
                   {stock.change >= 0 ? '+' : ''}{stock.change.toFixed(2)} ({stock.changePercent.toFixed(2)}%)
                </div>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
};
