import React, { useState, useEffect } from 'react';
import type { AppProps } from '../../types';

interface Reminder {
  id: string;
  text: string;
  completed: boolean;
}

const useReminders = () => {
  const [reminders, setReminders] = useState<Reminder[]>(() => {
    try {
      const saved = localStorage.getItem('aura-reminders');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem('aura-reminders', JSON.stringify(reminders));
  }, [reminders]);

  const addReminder = (text: string) => {
    if (!text.trim()) return;
    const newReminder: Reminder = {
      id: `reminder-${Date.now()}`,
      text: text.trim(),
      completed: false,
    };
    setReminders(prev => [...prev, newReminder]);
  };

  const toggleReminder = (id: string) => {
    setReminders(prev =>
      prev.map(r => (r.id === id ? { ...r, completed: !r.completed } : r))
    );
  };

  const deleteReminder = (id: string) => {
    setReminders(prev => prev.filter(r => r.id !== id));
  };
  
  return { reminders, addReminder, toggleReminder, deleteReminder };
};

export const RemindersApp: React.FC<AppProps> = () => {
  const { reminders, addReminder, toggleReminder, deleteReminder } = useReminders();
  const [newReminderText, setNewReminderText] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addReminder(newReminderText);
    setNewReminderText('');
  };

  return (
    <div className="w-full h-full flex flex-col bg-white">
      <header className="p-4 border-b border-gray-200">
        <h1 className="text-2xl font-bold text-mac-text">Reminders</h1>
      </header>
      <main className="flex-grow overflow-y-auto p-4 space-y-3">
        {reminders.map(reminder => (
          <div key={reminder.id} className="flex items-center gap-3 p-2 rounded-lg group hover:bg-gray-100">
            <input
              type="checkbox"
              checked={reminder.completed}
              onChange={() => toggleReminder(reminder.id)}
              className="w-5 h-5 rounded-full text-blue-500 bg-gray-100 border-gray-300 focus:ring-blue-500 shrink-0 cursor-pointer"
            />
            <span className={`flex-grow ${reminder.completed ? 'line-through text-gray-400' : 'text-mac-text'}`}>
              {reminder.text}
            </span>
            <button
              onClick={() => deleteReminder(reminder.id)}
              className="text-gray-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity font-bold"
            >
              ×
            </button>
          </div>
        ))}
      </main>
      <footer className="p-3 border-t border-gray-200">
        <form onSubmit={handleSubmit} className="flex items-center gap-2">
            <span className="text-blue-500 text-xl font-bold">+</span>
          <input
            type="text"
            value={newReminderText}
            onChange={e => setNewReminderText(e.target.value)}
            placeholder="New Reminder"
            className="flex-grow bg-transparent border-none focus:ring-0 text-mac-text"
          />
           <button type="submit" className="text-blue-500 font-semibold hover:text-blue-700 disabled:opacity-50" disabled={!newReminderText.trim()}>Add</button>
        </form>
      </footer>
    </div>
  );
};
