import React, { useState } from 'react';
import { useSettings } from '../context/SettingsContext';
import { OS_NAME, WALLPAPERS } from '../config/system';

type SettingsPanel = 'Appearance' | 'Dock & Menu Bar' | 'About';

const SidebarItem: React.FC<{
    icon: string;
    label: SettingsPanel;
    isActive: boolean;
    onClick: () => void;
}> = ({ icon, label, isActive, onClick }) => (
    <button
        onClick={onClick}
        className={`flex items-center w-full text-left px-3 py-2 rounded-lg transition-colors duration-150 ${
            isActive ? 'bg-mac-blue/20 text-mac-blue' : 'hover:bg-gray-200/50'
        }`}
    >
        <span className="text-xl mr-3">{icon}</span>
        <span className="font-medium text-sm">{label}</span>
    </button>
);

const AppearancePanel: React.FC = () => {
    const { wallpaper, setWallpaper } = useSettings();

    return (
        <div>
            <h2 className="text-xl font-bold mb-4">Appearance</h2>
            <p className="text-mac-text-secondary mb-6">Select a desktop wallpaper.</p>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                {WALLPAPERS.map((wp) => (
                    <div
                        key={wp.name}
                        className={`relative rounded-lg overflow-hidden border-2 cursor-pointer transition-all ${
                            wallpaper === wp.url ? 'border-mac-blue' : 'border-transparent'
                        }`}
                        onClick={() => setWallpaper(wp.url)}
                        aria-label={`Select ${wp.name} wallpaper`}
                    >
                        <img src={wp.url} alt={wp.name} className="w-full h-24 object-cover" />
                        <div className="absolute inset-0 bg-black/20"></div>
                        <p className="absolute bottom-1 left-2 text-white text-xs font-semibold" style={{ textShadow: '0 1px 2px rgba(0,0,0,0.5)' }}>{wp.name}</p>
                    </div>
                ))}
            </div>
        </div>
    );
};

const DockPanel: React.FC = () => {
    const { dockSize, setDockSize, dockMagnification, setDockMagnification } = useSettings();
    return (
        <div>
            <h2 className="text-xl font-bold mb-4">Dock & Menu Bar</h2>
            <div className="space-y-6">
                <div>
                    <label htmlFor="dock-size" className="block text-sm font-medium text-mac-text mb-2">
                        Size: <span className="text-mac-text-secondary font-normal">{dockSize}px</span>
                    </label>
                    <input
                        id="dock-size"
                        type="range"
                        min="40"
                        max="80"
                        step="4"
                        value={dockSize}
                        onChange={(e) => setDockSize(Number(e.target.value))}
                        className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-mac-blue"
                    />
                </div>
                <div>
                    <label htmlFor="dock-mag" className="block text-sm font-medium text-mac-text mb-2">
                        Magnification: <span className="text-mac-text-secondary font-normal">{Math.round(dockMagnification * 100)}%</span>
                    </label>
                    <input
                        id="dock-mag"
                        type="range"
                        min="1"
                        max="2"
                        step="0.1"
                        value={dockMagnification}
                        onChange={(e) => setDockMagnification(Number(e.target.value))}
                        className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-mac-blue"
                    />
                </div>
            </div>
        </div>
    );
};

const AboutPanel: React.FC = () => (
     <div>
        <h2 className="text-xl font-bold mb-4">About {OS_NAME}</h2>
        <div className="flex flex-col items-center text-center">
            <div className="text-7xl mb-4">✨</div>
            <h3 className="text-2xl font-bold">{OS_NAME}</h3>
            <p className="text-mac-text-secondary mt-1">Version 1.0 (Web)</p>
            <p className="mt-4 max-w-sm">
                A modern, web-based operating system inspired by the elegance and simplicity of macOS. 
                Built with React, TypeScript, and Tailwind CSS.
            </p>
        </div>
    </div>
);


export const SettingsApp: React.FC = () => {
    const [activePanel, setActivePanel] = useState<SettingsPanel>('Appearance');

    const renderPanel = () => {
        switch (activePanel) {
            case 'Appearance': return <AppearancePanel />;
            case 'Dock & Menu Bar': return <DockPanel />;
            case 'About': return <AboutPanel />;
            default: return <AppearancePanel />;
        }
    };
    
    return (
        <div className="w-full h-full bg-mac-gray flex">
            <aside className="w-48 h-full bg-mac-gray-header/60 p-3 shrink-0 border-r border-black/10">
                <div className="space-y-1">
                    <SidebarItem icon="🎨" label="Appearance" isActive={activePanel === 'Appearance'} onClick={() => setActivePanel('Appearance')} />
                    <SidebarItem icon="📏" label="Dock & Menu Bar" isActive={activePanel === 'Dock & Menu Bar'} onClick={() => setActivePanel('Dock & Menu Bar')} />
                    <SidebarItem icon="ℹ️" label="About" isActive={activePanel === 'About'} onClick={() => setActivePanel('About')} />
                </div>
            </aside>
            <main className="flex-grow p-8 overflow-y-auto">
                {renderPanel()}
            </main>
        </div>
    );
};
