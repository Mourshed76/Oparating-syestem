import React, { useState, useCallback, useEffect, useRef } from 'react';
import type { Tab, AppProps, SearchResult, GroundingChunk, Bookmark, HistoryItem, TabGroup } from '../../types';
import { useSettings } from '../../context/SettingsContext';
import { aiService } from '../../utils/aiService';
import { v4 as uuidv4 } from 'uuid';

// --- HELPER FUNCTIONS ---
const isURL = (str: string): boolean => {
    try {
        if (str.includes('.') && !str.includes(' ') && !str.startsWith('about:')) {
            new URL(str.startsWith('http') ? str : `https://${str}`);
            return true;
        }
    } catch (_) {
        return false;
    }
    return false;
};

const getFaviconUrl = (url: string) => {
    try {
        const hostname = new URL(url).hostname;
        return `https://www.google.com/s2/favicons?domain=${hostname}&sz=32`;
    } catch {
        return 'data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>🌐</text></svg>';
    }
};

// --- SUB-COMPONENTS ---

const SearchResultsPage: React.FC<{ result: SearchResult, onNavigate: (url: string) => void }> = ({ result, onNavigate }) => {
  return (
    <div className="w-full max-w-4xl mx-auto p-8 overflow-y-auto bg-white h-full">
      <h2 className="text-2xl font-bold mb-4 text-gray-800">AI Summary</h2>
      <p className="text-gray-700 leading-relaxed whitespace-pre-wrap mb-8">{result.summary}</p>

      {result.links && result.links.length > 0 && (
        <>
          <h3 className="text-xl font-semibold mb-3 text-gray-800">Sources</h3>
          <div className="space-y-4">
            {result.links.map((chunk, index) => (
              chunk.web && chunk.web.uri ? (
                <div key={index} onClick={() => onNavigate(chunk.web!.uri!)} className="group cursor-pointer p-3 rounded-lg hover:bg-gray-100 border border-gray-200">
                  <div className="flex items-center space-x-3">
                    <img src={getFaviconUrl(chunk.web.uri)} alt="" className="w-5 h-5 flex-shrink-0" />
                    <div className="overflow-hidden">
                      <h4 className="text-lg text-blue-700 group-hover:underline truncate">{chunk.web.title || chunk.web.uri}</h4>
                      <span className="text-sm text-green-700 truncate block">{chunk.web.uri}</span>
                    </div>
                  </div>
                </div>
              ) : null
            ))}
          </div>
        </>
      )}
    </div>
  );
};

const HomePage: React.FC<{ onSearch: (query: string) => void }> = ({ onSearch }) => {
    const [query, setQuery] = useState('');
    return (
        <div className="w-full h-full flex flex-col items-center justify-center bg-white p-8">
            <h1 className="text-7xl font-bold mb-4 bg-gradient-to-r from-blue-600 to-purple-600 text-transparent bg-clip-text">Nexus</h1>
            <p className="text-gray-500 mb-8">Your intelligent portal to the web.</p>
            <form onSubmit={(e) => { e.preventDefault(); if(query.trim()) onSearch(query.trim())}} className="w-full max-w-xl relative">
                <input
                    type="text"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Search with AI or type a URL"
                    className="w-full pl-12 pr-4 py-3 bg-gray-100 rounded-full border-2 border-transparent focus:border-blue-500 focus:ring-0 focus:outline-none transition-all"
                />
                <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6"><path strokeLinecap="round" strokeLinejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z" /></svg>
                </div>
            </form>
        </div>
    );
};

const HistoryPage: React.FC<{ history: HistoryItem[], onNavigate: (url: string) => void }> = ({ history, onNavigate }) => (
    <div className="w-full max-w-4xl mx-auto p-8 overflow-y-auto">
        <h1 className="text-2xl font-bold mb-6">History</h1>
        <div className="space-y-4">
            {history.map(item => (
                <div key={item.id} onClick={() => onNavigate(item.url)} className="group cursor-pointer p-2 rounded-lg hover:bg-gray-200">
                    <div className="flex items-center space-x-3">
                        <img src={getFaviconUrl(item.url)} alt="" className="w-5 h-5 flex-shrink-0" />
                        <div className="overflow-hidden">
                            <h4 className="text-md text-gray-800 group-hover:underline truncate">{item.title || item.url}</h4>
                            <span className="text-sm text-gray-500 truncate block">{item.url}</span>
                        </div>
                    </div>
                </div>
            ))}
            {history.length === 0 && <p className="text-gray-500">No history yet.</p>}
        </div>
    </div>
);

const LoadingSpinner: React.FC = () => (
    <div className="w-full h-full flex items-center justify-center bg-white">
        <svg className="animate-spin h-8 w-8 text-blue-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
    </div>
);

const ErrorDisplay: React.FC<{ error: string }> = ({ error }) => (
    <div className="w-full h-full flex flex-col items-center justify-center bg-red-50 text-red-700 p-4">
        <h2 className="text-xl font-bold">Oops!</h2>
        <p>{error}</p>
    </div>
);

const BookmarkBar: React.FC<{ bookmarks: Bookmark[], onNavigate: (url: string) => void, onRemove: (id: string) => void }> = ({ bookmarks, onNavigate, onRemove }) => {
    if (bookmarks.length === 0) return null;
    return (
        <div className="h-10 bg-gray-200 border-b border-gray-300 flex items-center px-2 space-x-1">
            {bookmarks.map(bm => (
                <div key={bm.id} className="group relative">
                    <button onClick={() => onNavigate(bm.url)} className="flex items-center space-x-2 px-2 py-1 rounded hover:bg-black/10">
                        <img src={bm.favicon} alt="" className="w-4 h-4" />
                        <span className="text-sm truncate max-w-[120px]">{bm.title}</span>
                    </button>
                    <button onClick={() => onRemove(bm.id)} className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-gray-400 text-white text-xs opacity-0 group-hover:opacity-100">x</button>
                </div>
            ))}
        </div>
    );
};

const TabComponent: React.FC<{ tab: Tab; isActive: boolean; onSelect: () => void; onClose: () => void; }> = ({ tab, isActive, onSelect, onClose }) => (
    <div onClick={onSelect} className={`relative flex items-center justify-between h-9 min-w-[200px] max-w-[200px] px-3 border-r border-gray-300 cursor-pointer transition-colors ${isActive ? 'bg-white z-10' : 'bg-gray-200 hover:bg-gray-300'}`}>
        <div className="flex items-center overflow-hidden">
            {tab.isLoading ? (
                <svg className="animate-spin h-4 w-4 text-gray-500 mr-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
            ) : (
                <img src={tab.favicon} alt="" className="w-4 h-4 mr-2" />
            )}
            <span className="text-sm truncate">{tab.title}</span>
        </div>
        <button onClick={(e) => {e.stopPropagation(); onClose();}} className="ml-2 w-4 h-4 rounded-full hover:bg-red-500 hover:text-white flex items-center justify-center text-xs text-gray-500">x</button>
    </div>
);

// --- MAIN COMPONENT ---
export const BrowserApp: React.FC<AppProps> = ({ windowId }) => {
    const { browserState, addBookmark, removeBookmark, addHistoryItem } = useSettings();
    const [tabs, setTabs] = useState<Tab[]>([{ id: 'home-1', title: 'Home Page', type: 'home', history: [], historyIndex: -1, isLoading: false, favicon: getFaviconUrl('about:home') }]);
    const [activeTabId, setActiveTabId] = useState('home-1');
    const [inputUrl, setInputUrl] = useState('');
    const [isVertical, setIsVertical] = useState(false);
    const urlInputRef = useRef<HTMLInputElement>(null);

    const activeTab = tabs.find(t => t.id === activeTabId) as Tab;

    useEffect(() => {
        const currentUrl = activeTab.history[activeTab.historyIndex];
        setInputUrl(currentUrl || (activeTab.type === 'search' ? activeTab.searchQuery || '' : ''));
    }, [activeTab]);

    const updateTab = (id: string, updates: Partial<Omit<Tab, 'id'>>) => {
        setTabs(prev => prev.map(t => t.id === id ? { ...t, ...updates } : t));
    };

    const navigateToUrl = useCallback((url: string) => {
        const fullUrl = url.startsWith('http') ? url : `https://${url}`;
        updateTab(activeTabId, { isLoading: true, error: null });

        // Simulate network request
        setTimeout(() => {
            const title = new URL(fullUrl).hostname.replace('www.', '');
            const newHistory = activeTab.history.slice(0, activeTab.historyIndex + 1);
            newHistory.push(fullUrl);
            
            updateTab(activeTabId, {
                type: 'webpage',
                title: title,
                history: newHistory,
                historyIndex: newHistory.length - 1,
                isLoading: false,
                favicon: getFaviconUrl(fullUrl),
            });
            addHistoryItem(fullUrl, title);
        }, 500);
    }, [activeTabId, activeTab, addHistoryItem]);

    const handleSearch = useCallback(async (query: string) => {
        updateTab(activeTabId, { type: 'search', searchQuery: query, isLoading: true, error: null, title: `Search: ${query}`, favicon: getFaviconUrl('about:search') });
        
        try {
            const response = await aiService.generateContent(query, true);
            const summary = response.text;
            const links = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
            const result: SearchResult = { summary, links };
            
            updateTab(activeTabId, { searchResult: result, isLoading: false });
            addHistoryItem(`search:${query}`, `Search: ${query}`);
        } catch (e: any) {
            updateTab(activeTabId, { error: e.message || 'Failed to fetch search results.', isLoading: false });
        }
    }, [activeTabId, addHistoryItem]);
    
    const handleUrlSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (isURL(inputUrl)) {
            navigateToUrl(inputUrl);
        } else {
            handleSearch(inputUrl);
        }
    };
    
    const addTab = () => {
        const newTab: Tab = { id: `tab-${Date.now()}`, title: 'Home Page', type: 'home', history: [], historyIndex: -1, isLoading: false, favicon: getFaviconUrl('about:home') };
        setTabs(prev => [...prev, newTab]);
        setActiveTabId(newTab.id);
    };

    const closeTab = (id: string) => {
        const newTabs = tabs.filter(t => t.id !== id);
        if (newTabs.length === 0) {
            const newTab: Tab = { id: `tab-${Date.now()}`, title: 'Home Page', type: 'home', history: [], historyIndex: -1, isLoading: false, favicon: getFaviconUrl('about:home') };
             setTabs([newTab]);
             setActiveTabId(newTab.id);
             return;
        }
        if (activeTabId === id) {
            setActiveTabId(newTabs[newTabs.length - 1].id);
        }
        setTabs(newTabs);
    };
    
    const goBack = () => {
        if (activeTab.historyIndex > 0) {
            updateTab(activeTabId, { historyIndex: activeTab.historyIndex - 1 });
        }
    };
    
    const goForward = () => {
        if (activeTab.historyIndex < activeTab.history.length - 1) {
            updateTab(activeTabId, { historyIndex: activeTab.historyIndex + 1 });
        }
    };

    const handleAddBookmark = () => {
        const url = activeTab.history[activeTab.historyIndex];
        if (url) addBookmark(url, activeTab.title);
    };

    const renderTabContent = (tab: Tab) => {
        switch (tab.type) {
            case 'home':
                return <HomePage onSearch={(query) => { isURL(query) ? navigateToUrl(query) : handleSearch(query) }} />;
            case 'history':
                return <HistoryPage history={browserState.history} onNavigate={navigateToUrl} />;
            case 'webpage':
                 if (tab.isLoading) return <LoadingSpinner />;
                 if (tab.error) return <ErrorDisplay error={tab.error} />;
                 if (!navigator.onLine) {
                    return (
                        <div className="p-8 text-center text-gray-600 h-full flex flex-col items-center justify-center">
                            <h2 className="text-xl font-bold mb-2">You are offline</h2>
                            <p>This page cannot be loaded without an internet connection.</p>
                        </div>
                    );
                 }
                 return <iframe srcDoc={`<html><body style="font-family: sans-serif;"><h1>${tab.title}</h1><p>Simulated content for: ${tab.history[tab.historyIndex]}</p><p>This is a simulated browsing experience. The actual page is not loaded.</p></body></html>`} className="w-full h-full border-none" title={tab.title} />;
            case 'search':
                if (tab.isLoading) return <LoadingSpinner />;
                if (tab.error) return <ErrorDisplay error={tab.error} />;
                if (tab.searchResult) {
                    return <SearchResultsPage result={tab.searchResult} onNavigate={navigateToUrl} />;
                }
                return <HomePage onSearch={(query) => { isURL(query) ? navigateToUrl(query) : handleSearch(query) }} />;
            default:
                return <div>Unknown tab type</div>
        }
    };

    return (
        <div className="w-full h-full flex flex-col bg-gray-100">
            <header className="bg-gray-200">
                {!isVertical && <div className="h-9 flex items-center border-b border-gray-300">
                    {tabs.map(tab => <TabComponent key={tab.id} tab={tab} isActive={tab.id === activeTabId} onSelect={() => setActiveTabId(tab.id)} onClose={() => closeTab(tab.id)} />)}
                    <button onClick={addTab} className="w-8 h-8 flex items-center justify-center text-lg hover:bg-gray-300">+</button>
                </div>}
                <div className="h-12 flex items-center px-2 space-x-2 border-b border-gray-300">
                     <button onClick={() => setIsVertical(v => !v)} className="p-1 rounded-full hover:bg-black/10"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25H12" /></svg></button>
                    <button onClick={goBack} disabled={activeTab.historyIndex <= 0} className="p-1 rounded-full hover:bg-black/10 disabled:opacity-30"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M15.75 19.5 8.25 12l7.5-7.5" /></svg></button>
                    <button onClick={goForward} disabled={activeTab.historyIndex >= activeTab.history.length - 1} className="p-1 rounded-full hover:bg-black/10 disabled:opacity-30"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" /></svg></button>
                    <button onClick={() => updateTab(activeTabId, { isLoading: true, type: 'home', title: 'Home Page' })} className="p-1 rounded-full hover:bg-black/10"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M2.25 12l8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h7.5" /></svg></button>
                    <form onSubmit={handleUrlSubmit} className="flex-grow">
                        <input ref={urlInputRef} type="text" value={inputUrl} onChange={e => setInputUrl(e.target.value)} className="w-full h-8 px-3 rounded-full bg-white border border-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                    </form>
                    <button onClick={handleAddBookmark} className="p-1 rounded-full hover:bg-black/10 disabled:opacity-30" disabled={activeTab.type !== 'webpage'}>⭐</button>
                    <button onClick={() => updateTab(activeTabId, {type: 'history', title: 'History', history: [], historyIndex: -1})} className="p-1 rounded-full hover:bg-black/10">🕒</button>
                </div>
                <BookmarkBar bookmarks={browserState.bookmarks} onNavigate={navigateToUrl} onRemove={removeBookmark} />
            </header>
             <div className="flex-grow flex overflow-hidden">
                {isVertical && (
                    <aside className="w-64 bg-gray-200 border-r border-gray-300 p-2 flex flex-col gap-1 overflow-y-auto">
                        {tabs.map(tab => (
                            <div key={tab.id} onClick={() => setActiveTabId(tab.id)} className={`flex items-center justify-between p-2 rounded cursor-pointer ${tab.id === activeTabId ? 'bg-white' : 'hover:bg-gray-300'}`}>
                                <div className="flex items-center gap-2 overflow-hidden">
                                     <img src={tab.favicon} alt="" className="w-4 h-4 flex-shrink-0" />
                                     <span className="text-sm truncate">{tab.title}</span>
                                </div>
                                <button onClick={(e) => { e.stopPropagation(); closeTab(tab.id); }} className="text-xs text-gray-500 hover:text-red-500">x</button>
                            </div>
                        ))}
                    </aside>
                )}
                <main className="flex-grow overflow-auto bg-white">
                    {renderTabContent(activeTab)}
                </main>
            </div>
        </div>
    );
};
