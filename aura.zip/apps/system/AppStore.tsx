import React, { useState, useMemo } from 'react';
import { APPS } from '../../config/apps';
import type { AppDefinition, AppProps } from '../../types';
import { useSettings } from '../../context/SettingsContext';

type Tab = 'All' | 'Apps' | 'Games' | 'Entertainment';

const AppActionButton: React.FC<{ app: AppDefinition }> = ({ app }) => {
    const { installedApps, installingProgress, installApp } = useSettings();
    const isInstalled = installedApps.includes(app.id);
    const progress = installingProgress[app.id];
    const isCurrentlyInstalling = progress !== undefined;

    if (isInstalled) {
        return (
            <button disabled className="bg-gray-500 text-white font-bold py-2 px-6 rounded-full text-sm w-32 text-center" aria-label={`${app.name} is installed`}>
                INSTALLED
            </button>
        );
    }

    if (isCurrentlyInstalling) {
        return (
            <div className="w-32 h-9 relative bg-gray-200 rounded-full overflow-hidden">
                <div className="absolute inset-0 bg-blue-500 transition-all duration-100" style={{ width: `${progress}%` }}></div>
                <span className="absolute inset-0 flex items-center justify-center text-xs font-bold text-white mix-blend-difference">{Math.round(progress)}%</span>
            </div>
        );
    }

    return (
        <button onClick={() => installApp(app.id)} className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-6 rounded-full text-sm w-32 text-center" aria-label={`Install ${app.name}`}>
            INSTALL
        </button>
    );
};

const AppRow: React.FC<{ app: AppDefinition }> = ({ app }) => (
    <div className="flex items-center space-x-6 p-4 border-b border-gray-200">
        <div className="w-20 h-20 flex-shrink-0">{app.icon}</div>
        <div className="flex-grow">
            <h3 className="text-lg font-semibold text-mac-text">{app.name}</h3>
            <p className="text-sm text-mac-text-secondary mt-1">{app.description}</p>
        </div>
        <div className="text-center w-32 flex-shrink-0">
            <AppActionButton app={app} />
            <p className="text-xs text-gray-400 mt-1">{app.sizeMB} MB</p>
        </div>
    </div>
);

const TabButton: React.FC<{ label: Tab, activeTab: Tab, onClick: (tab: Tab) => void }> = ({ label, activeTab, onClick }) => (
    <button
        onClick={() => onClick(label)}
        className={`px-6 py-2 text-lg font-semibold border-b-2 transition-colors ${
            activeTab === label
                ? 'text-mac-blue border-mac-blue'
                : 'text-mac-text-secondary border-transparent hover:text-mac-text'
        }`}
    >
        {label}
    </button>
);

const SettingsModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
    const { installApp, installedApps, installingProgress } = useSettings();

    const handleInstallAll = () => {
        const appsToInstall = APPS.filter(app => 
            !installedApps.includes(app.id) && 
            installingProgress[app.id] === undefined
        );
        appsToInstall.forEach(app => installApp(app.id));
    };
    
    return (
        <div className="absolute inset-0 bg-black/30 backdrop-blur-sm z-10 flex items-center justify-center" onClick={onClose}>
            <div className="bg-mac-gray-light w-96 rounded-lg shadow-2xl p-6" onClick={e => e.stopPropagation()}>
                <h2 className="text-xl font-bold mb-4">App Store Settings</h2>
                <div className="space-y-4">
                    <div className="flex items-center justify-between p-3 bg-white rounded-lg">
                        <span className="font-medium">Install All Apps</span>
                        <button onClick={handleInstallAll} className="px-4 py-1.5 bg-green-500 hover:bg-green-600 text-white font-medium rounded-md transition-colors text-sm">
                            Install
                        </button>
                    </div>
                     <p className="text-xs text-mac-text-secondary px-1">Install all available applications from the App Store at once.</p>
                </div>
            </div>
        </div>
    );
};


export const AppStoreApp: React.FC<AppProps> = () => {
    const [activeTab, setActiveTab] = useState<Tab>('All');
    const [isSettingsOpen, setIsSettingsOpen] = useState(false);
    
    const allApps = APPS.filter(app => app.id !== 'app_store'); // Don't show App Store in itself

    const filteredApps = useMemo(() => {
        switch (activeTab) {
            case 'Apps':
                return allApps.filter(app => app.category === 'Productivity' || app.category === 'System');
            case 'Games':
                return allApps.filter(app => app.category === 'Games');
            case 'Entertainment':
                return allApps.filter(app => app.category === 'Entertainment');
            case 'All':
            default:
                return allApps;
        }
    }, [activeTab, allApps]);

    return (
        <div className="w-full h-full bg-mac-gray-light text-mac-text flex flex-col relative">
            {isSettingsOpen && <SettingsModal onClose={() => setIsSettingsOpen(false)} />}
            <header className="flex-shrink-0 bg-white/80 backdrop-blur-md border-b border-gray-200 shadow-sm flex items-center justify-between px-4">
                <div className="flex items-center justify-center space-x-4 flex-grow">
                    <TabButton label="All" activeTab={activeTab} onClick={setActiveTab} />
                    <TabButton label="Apps" activeTab={activeTab} onClick={setActiveTab} />
                    <TabButton label="Games" activeTab={activeTab} onClick={setActiveTab} />
                    <TabButton label="Entertainment" activeTab={activeTab} onClick={setActiveTab} />
                </div>
                <button onClick={() => setIsSettingsOpen(true)} className="p-2 rounded-full hover:bg-gray-200">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                </button>
            </header>
            <main className="flex-grow overflow-y-auto">
                <div className="divide-y divide-gray-200">
                    {filteredApps.map(app => <AppRow key={app.id} app={app} />)}
                </div>
            </main>
        </div>
    );
};