import React, { useState, useMemo, useCallback, useEffect } from 'react';
import type { AppProps, VFS, VFSItem, VFSFolder, VFSFile } from '../../types';
import { useSettings } from '../../context/SettingsContext';
import { APPS } from '../../config/apps';
import { v4 as uuidv4 } from 'uuid';

// --- ICONS ---
const FolderIcon = () => <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-full h-full text-blue-500"><path d="M19.5 21a3 3 0 0 0 3-3V9a3 3 0 0 0-3-3h-5.25a3 3 0 0 1-2.65-1.5L9.75 1.5a3 3 0 0 0-2.65-1.5H4.5a3 3 0 0 0-3 3v15a3 3 0 0 0 3 3h15Z" /></svg>;
const FileIcon = () => <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-full h-full text-gray-400"><path fillRule="evenodd" d="M5.625 1.5c-1.036 0-1.875.84-1.875 1.875v17.25c0 1.035.84 1.875 1.875 1.875h12.75c1.035 0 1.875-.84 1.875-1.875V12.75A3.75 3.75 0 0 0 16.5 9h-1.875a.375.375 0 0 1-.375-.375V6.75A3.75 3.75 0 0 0 9 3H5.625Z" clipRule="evenodd" /></svg>;
const DesktopIcon = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M9 17.25v1.007a3 3 0 0 1-.879 2.122L7.5 21h9l-1.621-.621A3 3 0 0 1 15 18.257V17.25m6-12V15a2.25 2.25 0 0 1-2.25 2.25H5.25A2.25 2.25 0 0 1 3 15V5.25A2.25 2.25 0 0 1 5.25 3h6.75a2.25 2.25 0 0 1 2.25 2.25v.75" /></svg>
const DocumentsIcon = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Z" /></svg>
const DownloadsIcon = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75V16.5M16.5 12 12 16.5m0 0L7.5 12m4.5 4.5V3" /></svg>
const TrashIcon = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.134-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.067-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" /></svg>

// --- SUB-COMPONENTS ---

const ContextMenu: React.FC<{ x: number, y: number, items: { label: string, action: () => void, disabled?: boolean }[], onClose: () => void }> = ({ x, y, items, onClose }) => {
    useEffect(() => {
        document.addEventListener('click', onClose);
        return () => document.removeEventListener('click', onClose);
    }, [onClose]);

    return (
        <div style={{ top: y, left: x }} className="absolute z-50 bg-white/70 backdrop-blur-xl rounded-lg shadow-2xl border border-white/20 p-1 w-48 animate-fade-in-fast">
            {items.map(item => (
                <button key={item.label} onClick={item.action} disabled={item.disabled} className="w-full text-left px-3 py-1.5 text-sm text-black rounded hover:bg-mac-blue hover:text-white disabled:opacity-50 disabled:hover:bg-transparent disabled:hover:text-black">
                    {item.label}
                </button>
            ))}
        </div>
    );
};

const GridItem: React.FC<{ item: VFSItem; onDoubleClick: (item: VFSItem) => void; selected: boolean; onSelect: (e: React.MouseEvent) => void; onContextMenu: (e: React.MouseEvent) => void; isRenaming: boolean; onRename: (newName: string) => void }> = ({ item, onDoubleClick, selected, onSelect, onContextMenu, isRenaming, onRename }) => {
    const app = item.type === 'file' && item.appId ? APPS.find(a => a.id === item.appId) : null;
    const icon = item.type === 'folder' ? <FolderIcon /> : (app?.icon ?? <FileIcon />);

    const handleRenameSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const input = (e.target as HTMLFormElement).elements.namedItem('rename-input') as HTMLInputElement;
        onRename(input.value);
    };

    return (
        <div onDoubleClick={() => onDoubleClick(item)} onClick={onSelect} onContextMenu={onContextMenu} className={`flex flex-col items-center p-2 rounded-lg cursor-pointer text-center w-28 ${selected ? 'bg-blue-500/30' : 'hover:bg-blue-500/10'}`}>
            <div className="w-16 h-16 mb-1 drop-shadow-sm">{icon}</div>
            {isRenaming ? (
                <form onSubmit={handleRenameSubmit}>
                    <input name="rename-input" defaultValue={item.name} autoFocus onBlur={(e) => onRename(e.target.value)} className="w-full text-center text-xs p-0.5 border border-mac-blue rounded" />
                </form>
            ) : (
                <p className="text-xs font-medium text-mac-text truncate w-full break-words">{item.name}</p>
            )}
        </div>
    );
};

// --- MAIN COMPONENT ---
export const FinderApp: React.FC<AppProps> = ({ onExecuteAction }) => {
    const { vfs, createVFSItem, renameVFSItem, moveVFSItemToTrash, emptyTrash } = useSettings();
    
    const [currentPathId, setCurrentPathId] = useState(vfs.desktopId);
    const [selectedItemId, setSelectedItemId] = useState<string | null>(null);
    const [renamingItemId, setRenamingItemId] = useState<string | null>(null);
    const [contextMenu, setContextMenu] = useState<{ x: number, y: number, targetId: string | null } | null>(null);
    const [history, setHistory] = useState([vfs.desktopId]);
    const [historyIndex, setHistoryIndex] = useState(0);

    const currentFolder = vfs.items[currentPathId] as VFSFolder;
    const currentItems = currentFolder?.children.map(id => vfs.items[id]).filter(Boolean) || [];

    const navigate = (pathId: string) => {
        if(pathId === currentPathId) return;
        const newHistory = history.slice(0, historyIndex + 1);
        newHistory.push(pathId);
        setHistory(newHistory);
        setHistoryIndex(newHistory.length - 1);
        setCurrentPathId(pathId);
        setSelectedItemId(null);
    };

    const goBack = () => {
        if(historyIndex > 0) {
            const newIndex = historyIndex - 1;
            setHistoryIndex(newIndex);
            setCurrentPathId(history[newIndex]);
        }
    };
    
    const goForward = () => {
        if(historyIndex < history.length - 1) {
            const newIndex = historyIndex + 1;
            setHistoryIndex(newIndex);
            setCurrentPathId(history[newIndex]);
        }
    };

    const handleDoubleClick = (item: VFSItem) => {
        if (item.type === 'folder') {
            navigate(item.id);
        } else {
             const defaultApp = APPS.find(a => a.id === (item.appId || 'notes')); // Default to notes
             if (defaultApp) {
                onExecuteAction?.({ action: 'open_app', payload: { appId: defaultApp.id, filePath: item.path } });
             }
        }
    };
    
    const handleContextMenu = (e: React.MouseEvent, targetId: string | null = null) => {
        e.preventDefault();
        e.stopPropagation();
        setSelectedItemId(targetId);
        setContextMenu({ x: e.clientX, y: e.clientY, targetId });
    };
    
    const contextMenuItems = useMemo(() => {
        const selectedItem = contextMenu?.targetId ? vfs.items[contextMenu.targetId] : null;
        
        let items: { label: string; action: () => void; disabled?: boolean }[] = [];

        if (selectedItem) {
            items = [
                { label: 'Open', action: () => handleDoubleClick(selectedItem) },
                { label: 'Rename', action: () => setRenamingItemId(selectedItem.id) },
                { label: 'Move to Trash', action: () => moveVFSItemToTrash(selectedItem.id) }
            ];
        } else {
            if (currentPathId === vfs.trashId) {
                items = [{ label: 'Empty Trash', action: emptyTrash, disabled: currentItems.length === 0 }];
            } else {
                items = [{ label: 'New Folder', action: () => { createVFSItem('folder', currentPathId, 'New Folder'); } }];
            }
        }
        
        return items.map(item => ({...item, action: () => { item.action(); setContextMenu(null); }}));
    }, [contextMenu, vfs, currentPathId, currentItems, emptyTrash, createVFSItem, handleDoubleClick, moveVFSItemToTrash]);
    
    const selectedItemDetails = useMemo(() => vfs.items[selectedItemId || ''] || null, [selectedItemId, vfs.items]);
    const breadcrumbs = useMemo(() => {
        const path: VFSItem[] = [];
        let current = vfs.items[currentPathId];
        while (current) {
            path.unshift(current);
            current = current.parentId ? vfs.items[current.parentId] : null;
        }
        return path;
    }, [currentPathId, vfs.items]);

    const sidebarFavorites = [
        { label: 'Desktop', pathId: vfs.desktopId, icon: <DesktopIcon/> },
        { label: 'Documents', pathId: vfs.documentsId, icon: <DocumentsIcon/> },
        { label: 'Downloads', pathId: vfs.downloadsId, icon: <DownloadsIcon/> },
        { label: 'Trash', pathId: vfs.trashId, icon: <TrashIcon/> },
    ];
    
    return (
        <div className="w-full h-full bg-mac-gray flex select-none" onContextMenu={(e) => handleContextMenu(e, null)} onClick={() => { setSelectedItemId(null); setRenamingItemId(null); }}>
            {contextMenu && <ContextMenu {...contextMenu} items={contextMenuItems} onClose={() => setContextMenu(null)} />}
            
            <aside className="w-52 h-full bg-mac-gray-header/80 p-2 shrink-0 border-r border-black/10 flex flex-col">
                <div className="p-2">
                    <h3 className="text-xs font-bold text-gray-500 uppercase mb-2">Favorites</h3>
                    <div className="space-y-1">
                        {sidebarFavorites.map(fav => (
                            <button key={fav.pathId} onClick={() => navigate(fav.pathId)} className={`flex items-center w-full text-left px-2 py-1.5 rounded-md space-x-2 text-sm ${currentPathId === fav.pathId ? 'bg-gray-300' : 'hover:bg-gray-200'}`}>
                                {fav.icon}
                                <span className="font-medium">{fav.label}</span>
                            </button>
                        ))}
                    </div>
                </div>
            </aside>
            <main className="flex-grow flex flex-col">
                <header className="flex-shrink-0 h-12 flex items-center justify-between px-4 border-b border-black/10">
                    <div className="flex items-center space-x-2">
                        <button onClick={goBack} disabled={historyIndex === 0} className="p-1 rounded-full hover:bg-gray-300 disabled:opacity-30">
                           <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M15.75 19.5 8.25 12l7.5-7.5" /></svg>
                        </button>
                         <button onClick={goForward} disabled={historyIndex >= history.length - 1} className="p-1 rounded-full hover:bg-gray-300 disabled:opacity-30">
                           <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" /></svg>
                        </button>
                    </div>
                    <div className="flex items-center text-sm font-semibold">
                        {breadcrumbs.map((part, i) => (
                           <React.Fragment key={part.id}>
                               <button onClick={() => navigate(part.id)} className="px-2 py-1 rounded hover:bg-gray-200">{part.name}</button>
                               {i < breadcrumbs.length - 1 && <span className="text-gray-400">/</span>}
                           </React.Fragment>
                        ))}
                    </div>
                    <div className="w-16"></div> {/* Spacer */}
                </header>
                <div className="flex-grow p-4 overflow-y-auto" onClick={(e) => { e.stopPropagation(); setSelectedItemId(null); setRenamingItemId(null); }}>
                    <div className="flex flex-wrap gap-4">
                        {currentItems.map(item => (
                            <GridItem key={item.id} item={item} onDoubleClick={handleDoubleClick} selected={item.id === selectedItemId} onSelect={(e) => { e.stopPropagation(); setSelectedItemId(item.id); }} onContextMenu={(e) => handleContextMenu(e, item.id)} isRenaming={item.id === renamingItemId} onRename={(newName) => { renameVFSItem(item.id, newName); setRenamingItemId(null); }} />
                        ))}
                         {currentItems.length === 0 && (
                            <div className="w-full text-center text-gray-500 mt-20">This folder is empty.</div>
                        )}
                    </div>
                </div>
                 {selectedItemDetails && (
                    <footer className="flex-shrink-0 h-16 border-t border-black/10 p-2 text-sm text-gray-600">
                        <b>{selectedItemDetails.name}</b>
                        <p>Type: {selectedItemDetails.type} {selectedItemDetails.type === 'file' ? `(${(selectedItemDetails.size / 1024).toFixed(2)} KB)` : ''}</p>
                    </footer>
                 )}
            </main>
        </div>
    );
};
