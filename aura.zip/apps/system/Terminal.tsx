import React, { useState, useEffect, useRef, useCallback } from 'react';
import type { AppProps } from '../../types';
import { useSettings } from '../../context/SettingsContext';
import { APPS } from '../../config/apps';

interface OutputLine {
  type: 'command' | 'response' | 'error' | 'art';
  text: string;
}

const COMMANDS: { [key: string]: string } = {
  help: 'Lists all available commands.',
  echo: 'Prints back the provided text. Usage: echo [text]',
  date: 'Displays the current date and time.',
  clear: 'Clears the terminal screen.',
  ls: 'Lists files in the (fake) current directory.',
  neofetch: 'Displays system information.',
  open: `Opens an application. Usage: open [appId]`,
  whoami: 'Displays the current user.',
};

const FILES = ['Documents', 'Pictures', 'Music', 'Project_Aura', 'README.md'];

const NEOFETCH_ART = `
      ...                       
   ;::::;                      
 ;::::; :;                     
;:::::'   :;                    Aura OS
;:::::;     ;.                  -------
,:::::'       ;           ,--,  OS: Aura OS (Web)
;:::::;       ;          /   /  Host: Your Browser
;:::::;       ;         /   /   Kernel: JavaScript (ESM)
;:::::'      ;         /   /    Uptime: (simulated)
;:::::;     ;         /   /     Shell: AuraTerm
':::::;    ;         /   /
  ':::::..;         /___/

`;

export const TerminalApp: React.FC<AppProps> = ({ onExecuteAction }) => {
  const { currentUser } = useSettings();
  const [input, setInput] = useState('');
  const [output, setOutput] = useState<OutputLine[]>([
    { type: 'response', text: 'Welcome to Aura Terminal. Type "help" for a list of commands.' },
  ]);
  const [history, setHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);

  const inputRef = useRef<HTMLInputElement>(null);
  const endOfTerminalRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  useEffect(() => {
    endOfTerminalRef.current?.scrollIntoView();
  }, [output]);

  const processCommand = (commandStr: string) => {
    const [command, ...args] = commandStr.split(' ');
    const argString = args.join(' ');
    const newOutput: OutputLine[] = [...output, { type: 'command', text: commandStr }];
    
    switch (command) {
      case 'help':
        newOutput.push({ type: 'response', text: 'Available commands:' });
        Object.entries(COMMANDS).forEach(([cmd, desc]) => {
          newOutput.push({ type: 'response', text: `  ${cmd.padEnd(10)} - ${desc}` });
        });
        break;
      case 'echo':
        newOutput.push({ type: 'response', text: argString });
        break;
      case 'date':
        newOutput.push({ type: 'response', text: new Date().toString() });
        break;
      case 'clear':
        setOutput([]);
        return;
      case 'ls':
        newOutput.push({ type: 'response', text: FILES.join('   ') });
        break;
      case 'neofetch':
        newOutput.push({ type: 'art', text: NEOFETCH_ART });
        break;
      case 'whoami':
        newOutput.push({ type: 'response', text: currentUser?.username || 'guest' });
        break;
      case 'open':
        const appIdToOpen = argString;
        if (APPS.some(app => app.id === appIdToOpen)) {
          onExecuteAction?.({ action: 'open_app', payload: { appId: appIdToOpen } });
          newOutput.push({ type: 'response', text: `Opening ${appIdToOpen}...` });
        } else {
          newOutput.push({ type: 'error', text: `Error: App with id "${appIdToOpen}" not found.` });
        }
        break;
      case '':
        break;
      default:
        newOutput.push({ type: 'error', text: `command not found: ${command}` });
    }
    setOutput(newOutput);
  };

  const handleCommandSubmit = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const command = input.trim();
      if (command) {
        processCommand(command);
        setHistory(prev => [command, ...prev]);
      } else {
         setOutput(prev => [...prev, { type: 'command', text: '' }])
      }
      setHistoryIndex(-1);
      setInput('');
    } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        if (history.length > 0 && historyIndex < history.length - 1) {
            const newIndex = historyIndex + 1;
            setHistoryIndex(newIndex);
            setInput(history[newIndex]);
        }
    } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        if (historyIndex > 0) {
             const newIndex = historyIndex - 1;
            setHistoryIndex(newIndex);
            setInput(history[newIndex]);
        } else {
            setHistoryIndex(-1);
            setInput('');
        }
    }
  };

  return (
    <div className="w-full h-full bg-black text-white font-mono p-2 text-sm overflow-y-auto" onClick={() => inputRef.current?.focus()}>
      {output.map((line, index) => (
        <div key={index}>
          {line.type === 'command' && (
            <div>
              <span className="text-green-400">aura@webos:~$</span>
              <span className="ml-2">{line.text}</span>
            </div>
          )}
          {line.type === 'response' && <p>{line.text}</p>}
          {line.type === 'error' && <p className="text-red-500">{line.text}</p>}
          {line.type === 'art' && <pre className="text-blue-400">{line.text}</pre>}
        </div>
      ))}
      <div className="flex">
        <label htmlFor="terminal-input" className="text-green-400">aura@webos:~$</label>
        <input
          id="terminal-input"
          ref={inputRef}
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleCommandSubmit}
          className="bg-transparent border-none text-white w-full focus:outline-none ml-2"
          autoComplete="off"
          spellCheck="false"
        />
      </div>
      <div ref={endOfTerminalRef} />
    </div>
  );
};