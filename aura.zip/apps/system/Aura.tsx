import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Chat } from '@google/genai';
import { useSettings } from '../../context/SettingsContext';
import type { AppProps, OSAction } from '../../types';
import { aiService } from '../../utils/aiService';

interface Message {
    id: number;
    sender: 'user' | 'ai';
    text: string;
}

const initialMessage: Message = { id: 0, sender: 'ai', text: "I'm Aura, your AGI assistant. You can ask me questions, control the OS, or generate images." };
const AURA_SYSTEM_INSTRUCTION = "You are Aura, a powerful AGI integrated into the Aura OS. You are multilingual. Your capabilities include deep conversation and generating images from text prompts. You can also control the OS. To control the OS, you MUST respond ONLY with a JSON object. Do not add any other text or markdown formatting. The JSON format is: {\"action\": \"open_app\", \"payload\": {\"appId\": \"app_id_to_open\"}}. For example, if the user says 'Open Notes', your response must be exactly: {\"action\": \"open_app\", \"payload\": {\"appId\": \"notes\"}}. Valid appIds are: 'finder', 'browser', 'app_store', 'settings', 'notes', 'mail', 'calendar', 'reminders', 'photos', 'music', 'tv', 'chess', 'snake', 'tic_tac_toe', 'pong', 'brick_breaker'. For all other conversational queries or greetings, respond naturally and helpfully as a friendly AI assistant.";

type Mode = 'chat' | 'image';

export const AuraApp: React.FC<AppProps> = ({ onExecuteAction }) => {
    const { auraChatClearCount } = useSettings();
    const [mode, setMode] = useState<Mode>('chat');

    // Chat state
    const [messages, setMessages] = useState<Message[]>([initialMessage]);
    const [chatInput, setChatInput] = useState('');
    const [isChatLoading, setIsChatLoading] = useState(false);
    const [chat, setChat] = useState<Chat | null>(null);

    // Image state
    const [imagePrompt, setImagePrompt] = useState('');
    const [generatedImages, setGeneratedImages] = useState<string[]>([]);
    const [isGeneratingImage, setIsGeneratingImage] = useState(false);
    
    // Common state
    const [error, setError] = useState<string | null>(null);
    const messagesEndRef = useRef<HTMLDivElement>(null);
    const chatClearCountRef = useRef(auraChatClearCount);
    
    useEffect(() => {
        try {
            const chatInstance = aiService.createChat(AURA_SYSTEM_INSTRUCTION);
            if (chatInstance) {
                setChat(chatInstance);
            } else {
                setError("Failed to initialize AI Chat. Check API Key.");
            }
        } catch (e: any) {
            setError(`Failed to initialize AI: ${e.message}`);
        }
    }, []);
    
    useEffect(() => {
        if (auraChatClearCount > chatClearCountRef.current) {
            setMessages([initialMessage]);
            const newChat = aiService.createChat(AURA_SYSTEM_INSTRUCTION);
            if(newChat) setChat(newChat);
            chatClearCountRef.current = auraChatClearCount;
        }
    }, [auraChatClearCount]);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    const handleChatSend = useCallback(async () => {
        if (!chatInput.trim() || isChatLoading || !chat) return;

        const userMessage: Message = { id: Date.now(), sender: 'user', text: chatInput };
        setMessages(prev => [...prev, userMessage]);
        const currentInput = chatInput;
        setChatInput('');
        setIsChatLoading(true);
        setError(null);
        
        try {
            const response = await chat.sendMessage({ message: currentInput });
            const responseText = response.text.trim();
            
            try {
                const parsedAction: OSAction = JSON.parse(responseText);
                if (parsedAction.action === 'open_app' && parsedAction.payload.appId) {
                    onExecuteAction?.(parsedAction);
                } else {
                    throw new Error('Invalid action format');
                }
            } catch (jsonError) {
                // Not a JSON command, treat as regular message
                const aiMessage: Message = { id: Date.now() + 1, sender: 'ai', text: responseText };
                setMessages(prev => [...prev, aiMessage]);
            }
        } catch (e: any) {
            const errorMessage = `Error: ${e.message || 'An unknown error occurred.'}`;
            setError(errorMessage);
            setMessages(prev => [...prev, { id: Date.now() + 1, sender: 'ai', text: `I'm having some trouble right now.` }]);
        } finally {
            setIsChatLoading(false);
        }
    }, [chatInput, isChatLoading, chat, onExecuteAction]);
    
    const handleImageGenerate = useCallback(async () => {
        if (!imagePrompt.trim() || isGeneratingImage) return;

        setIsGeneratingImage(true);
        setError(null);
        
        try {
            const response = await aiService.generateImages(imagePrompt);
            
            const base64ImageBytes = response.generatedImages[0].image.imageBytes;
            const imageUrl = `data:image/jpeg;base64,${base64ImageBytes}`;
            setGeneratedImages(prev => [imageUrl, ...prev]);

        } catch (e: any) {
             const errorMessage = `Error: ${e.message || 'An unknown error occurred.'}`;
            setError(errorMessage);
        } finally {
            setIsGeneratingImage(false);
        }
    }, [imagePrompt, isGeneratingImage]);

    return (
        <div className="w-full h-full flex flex-col bg-[#1E1E1E] text-gray-200 font-sans">
            <div className="flex-shrink-0 p-2 flex justify-center">
                <div className="bg-[#333] p-1 rounded-full flex text-sm">
                    <button onClick={() => setMode('chat')} className={`px-4 py-1 rounded-full ${mode === 'chat' ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white' : 'text-gray-400'}`}>Chat</button>
                    <button onClick={() => setMode('image')} className={`px-4 py-1 rounded-full ${mode === 'image' ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white' : 'text-gray-400'}`}>Image</button>
                </div>
            </div>
            
            {error && <div className="p-1 mx-2 rounded text-center bg-red-500/20 text-red-300 text-xs">{error}</div>}

            {mode === 'chat' ? (
                <>
                    <div className="flex-grow p-4 overflow-y-auto space-y-4">
                        {messages.map((message) => (
                            <div key={message.id} className={`flex items-end gap-2 ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                                <div className={`max-w-md px-4 py-2 rounded-2xl ${message.sender === 'user' ? 'bg-blue-600 text-white' : 'bg-[#333] text-gray-200'}`}>
                                   {message.text}
                                </div>
                            </div>
                        ))}
                        {isChatLoading && (
                            <div className="flex items-end gap-2 justify-start">
                                <div className="px-4 py-2 rounded-2xl bg-[#333]">
                                   <div className="flex space-x-1.5">
                                    <span className="w-2 h-2 bg-gray-500 rounded-full animate-pulse" style={{ animationDelay: '0s' }}></span>
                                    <span className="w-2 h-2 bg-gray-500 rounded-full animate-pulse" style={{ animationDelay: '0.15s' }}></span>
                                    <span className="w-2 h-2 bg-gray-500 rounded-full animate-pulse" style={{ animationDelay: '0.3s' }}></span>
                                   </div>
                                </div>
                            </div>
                        )}
                        <div ref={messagesEndRef} />
                    </div>
                    <div className="p-3 border-t border-gray-700">
                        <div className="flex items-center space-x-2 bg-[#333] rounded-full pr-2">
                            <input
                                type="text" value={chatInput} onChange={(e) => setChatInput(e.target.value)}
                                onKeyPress={(e) => e.key === 'Enter' && handleChatSend()}
                                placeholder="Message Aura or give a command..."
                                className="flex-grow bg-transparent text-gray-200 px-4 py-2.5 rounded-full focus:outline-none"
                                disabled={isChatLoading || !chat}
                            />
                            <button onClick={handleChatSend} disabled={isChatLoading || !chatInput.trim() || !chat} className="disabled:opacity-50 disabled:cursor-not-allowed">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6 text-gray-400 hover:text-white"><path d="M3.478 2.405a.75.75 0 00-.926.94l2.432 7.905H13.5a.75.75 0 010 1.5H4.984l-2.432 7.905a.75.75 0 00.926.94 60.519 60.519 0 0018.445-8.986.75.75 0 000-1.218A60.517 60.517 0 003.478 2.405z" /></svg>
                            </button>
                        </div>
                    </div>
                </>
            ) : (
                <>
                    <div className="flex-grow p-3 overflow-y-auto">
                        {isGeneratingImage && (
                            <div className="absolute inset-0 bg-black/50 flex flex-col items-center justify-center z-10">
                                <svg className="animate-spin h-8 w-8 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                                <p className="mt-2 text-white">Generating...</p>
                            </div>
                        )}
                        {generatedImages.length === 0 && !isGeneratingImage && (
                            <div className="text-center text-gray-500 mt-20">
                                <p className="text-4xl mb-4">🖼️</p>
                                <p>Describe the image you want to create.</p>
                            </div>
                        )}
                        <div className="grid grid-cols-2 gap-3">
                            {generatedImages.map((imgSrc, index) => (
                                <img key={index} src={imgSrc} alt={`Generated image for: ${imagePrompt}`} className="w-full h-auto rounded-lg object-cover" />
                            ))}
                        </div>
                    </div>
                    <div className="p-3 border-t border-gray-700">
                        <div className="flex flex-col gap-2">
                            <textarea
                                value={imagePrompt} onChange={(e) => setImagePrompt(e.target.value)}
                                placeholder="A robot holding a red skateboard..."
                                className="w-full bg-[#333] text-gray-200 px-4 py-2.5 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                                rows={2}
                                disabled={isGeneratingImage}
                            />
                            <button onClick={handleImageGenerate} disabled={isGeneratingImage || !imagePrompt.trim()} className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white font-bold py-2.5 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed">
                                Generate
                            </button>
                        </div>
                    </div>
                </>
            )}
        </div>
    );
};
