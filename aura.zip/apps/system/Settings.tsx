import React, { useState, useMemo } from 'react';
import { useSettings } from '../../context/SettingsContext';
import { OS_NAME, WALLPAPERS } from '../../config/system';
import type { AppProps, NetworkSpeed, ThemeSettings, FocusMode } from '../../types';
import { aiService } from '../../utils/aiService';

// --- DATA & CONFIG ---
const FOCUS_MODES: FocusMode[] = [
    { id: 'work', name: 'Work', icon: '💼', settings: { hideDesktopIcons: true, hideDock: false } },
    { id: 'relax', name: 'Relax', icon: '🧘', settings: { hideDesktopIcons: true, hideDock: true } },
    { id: 'study', name: 'Study', icon: '📚', settings: { hideDesktopIcons: true, hideDock: false } },
];

const ACCENT_COLORS = ['#007aff', '#ff3b30', '#34c759', '#ff9500', '#af52de', '#ff2d55'];

// --- PANELS ---

const AppearancePanel: React.FC = () => {
    const { wallpaper, setWallpaper } = useSettings();
    return (
        <div>
            <h2 className="text-2xl font-bold mb-4">Appearance</h2>
            <p className="text-mac-text-secondary mb-6">Select a desktop wallpaper.</p>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                {WALLPAPERS.map((wp) => (
                    <div
                        key={wp.name}
                        className={`relative rounded-lg overflow-hidden border-4 cursor-pointer transition-all ${
                            wallpaper === wp.url ? 'border-accent' : 'border-transparent hover:border-gray-300'
                        }`}
                        onClick={() => setWallpaper(wp.url)}
                        aria-label={`Select ${wp.name} wallpaper`}
                    >
                        <img src={wp.url} alt={wp.name} className="w-full h-24 object-cover" />
                    </div>
                ))}
            </div>
        </div>
    );
};

const ThemesPanel: React.FC = () => {
    const { theme, setTheme } = useSettings();
    const updateTheme = (updates: Partial<ThemeSettings>) => setTheme(prev => ({...prev, ...updates}));

    return (
        <div>
            <h2 className="text-2xl font-bold mb-4">Themes</h2>
            <div className="space-y-8">
                <div>
                    <h3 className="font-semibold mb-2">Mode</h3>
                    <div className="flex gap-2 p-1 bg-gray-200 rounded-lg max-w-xs">
                        <button onClick={() => updateTheme({mode: 'light'})} className={`flex-1 p-2 rounded-md font-semibold text-sm ${theme.mode === 'light' ? 'bg-white shadow' : 'hover:bg-white/50'}`}>Light</button>
                        <button onClick={() => updateTheme({mode: 'dark'})} className={`flex-1 p-2 rounded-md font-semibold text-sm ${theme.mode === 'dark' ? 'bg-black text-white shadow' : 'hover:bg-black/10'}`}>Dark</button>
                    </div>
                </div>
                 <div>
                    <h3 className="font-semibold mb-2">Accent Color</h3>
                     <div className="flex gap-3">
                        {ACCENT_COLORS.map(color => (
                            <button key={color} onClick={() => updateTheme({accentColor: color})} style={{backgroundColor: color}} className={`w-8 h-8 rounded-full transition-transform hover:scale-110 ${theme.accentColor === color ? 'ring-4 ring-offset-2 ring-accent' : ''}`}/>
                        ))}
                    </div>
                </div>
                <div>
                    <h3 className="font-semibold mb-2">Effects</h3>
                     <label className="flex items-center justify-between p-3 rounded-lg bg-gray-100 max-w-xs cursor-pointer">
                        <span className="font-medium text-sm">Enable Glassmorphism</span>
                        <div className={`w-10 h-6 rounded-full p-1 transition-colors ${theme.glassmorphism ? 'bg-accent' : 'bg-gray-300'}`}>
                            <div className={`w-4 h-4 bg-white rounded-full transition-transform ${theme.glassmorphism ? 'translate-x-4' : 'translate-x-0'}`}/>
                        </div>
                        <input type="checkbox" checked={theme.glassmorphism} onChange={e => updateTheme({glassmorphism: e.target.checked})} className="sr-only"/>
                    </label>
                </div>
            </div>
        </div>
    )
}

const FocusPanel: React.FC = () => {
    const { focusMode, setFocusMode } = useSettings();
    return (
        <div>
            <h2 className="text-2xl font-bold mb-4">Focus & Wellbeing</h2>
            <p className="text-mac-text-secondary mb-6">Minimize distractions by enabling a focus mode.</p>
            <div className="grid grid-cols-2 gap-4 max-w-md">
                 <button onClick={() => setFocusMode(null)} className={`p-4 rounded-lg border-2 text-center ${!focusMode ? 'bg-accent/20 border-accent' : 'bg-gray-100 hover:border-gray-300'}`}>
                    <span className="text-3xl">😌</span>
                    <p className="font-semibold mt-1">Default</p>
                </button>
                {FOCUS_MODES.map(mode => (
                    <button key={mode.id} onClick={() => setFocusMode(mode)} className={`p-4 rounded-lg border-2 text-center ${focusMode?.id === mode.id ? 'bg-accent/20 border-accent' : 'bg-gray-100 hover:border-gray-300'}`}>
                        <span className="text-3xl">{mode.icon}</span>
                        <p className="font-semibold mt-1">{mode.name}</p>
                    </button>
                ))}
            </div>
        </div>
    )
}

const DockPanel: React.FC = () => {
    const { dockSize, setDockSize, dockMagnification, setDockMagnification } = useSettings();
    return (
        <div>
            <h2 className="text-2xl font-bold mb-4">Dock & Menu Bar</h2>
            <div className="space-y-6">
                <div>
                    <label htmlFor="dock-size" className="block text-sm font-medium text-mac-text mb-2">
                        Size: <span className="text-mac-text-secondary font-normal">{dockSize}px</span>
                    </label>
                    <input id="dock-size" type="range" min="40" max="80" step="4" value={dockSize} onChange={(e) => setDockSize(Number(e.target.value))} className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-accent"/>
                </div>
                <div>
                    <label htmlFor="dock-mag" className="block text-sm font-medium text-mac-text mb-2">
                        Magnification: <span className="text-mac-text-secondary font-normal">{Math.round(dockMagnification * 100)}%</span>
                    </label>
                    <input id="dock-mag" type="range" min="1" max="2" step="0.1" value={dockMagnification} onChange={(e) => setDockMagnification(Number(e.target.value))} className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-accent"/>
                </div>
            </div>
        </div>
    );
};

const NetworkPanel: React.FC = () => {
    const { networkSpeed, setNetworkSpeed } = useSettings();
    return (
        <div>
            <h2 className="text-2xl font-bold mb-4">Network</h2>
            <p className="text-mac-text-secondary mb-6">Simulate network speeds for app downloads.</p>
            <div className="space-y-2 max-w-xs">
                {(['fast', 'medium', 'slow', 'offline'] as const).map((speed: NetworkSpeed) => (
                    <label key={speed} className="flex items-center space-x-3 p-2 rounded-lg hover:bg-gray-200 cursor-pointer">
                        <input type="radio" name="network-speed" value={speed} checked={networkSpeed === speed} onChange={() => setNetworkSpeed(speed)} className="h-4 w-4 text-accent focus:ring-accent border-gray-300"/>
                        <span className="capitalize font-medium">{speed}</span>
                    </label>
                ))}
            </div>
        </div>
    );
};

const AboutPanel: React.FC = () => (
     <div>
        <h2 className="text-2xl font-bold mb-4">About {OS_NAME}</h2>
        <div className="flex flex-col items-center text-center">
            <div className="text-7xl mb-4">✨</div>
            <h3 className="text-3xl font-bold">{OS_NAME}</h3>
            <p className="text-mac-text-secondary mt-1">Version 2.0 (Aura Core)</p>
            <p className="mt-4 max-w-sm">A modern, web-based operating system inspired by the elegance and simplicity of macOS. Now powered by generative AI.</p>
        </div>
    </div>
);


// --- MAIN APP COMPONENT ---
type PanelId = 'grid' | 'appearance' | 'themes' | 'focus' | 'dock' | 'network' | 'about';

export const SettingsApp: React.FC<AppProps> = () => {
    const { setWallpaper, setDockSize, setTheme } = useSettings();
    const [activePanel, setActivePanel] = useState<PanelId>('grid');
    const [searchQuery, setSearchQuery] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const handleAiCommand = async () => {
        if (!searchQuery.trim()) return;
        setIsLoading(true);

        const systemInstruction = `You are an OS assistant. The user wants to change a setting. Respond ONLY with a JSON object. Do not add any other text or markdown.
        Available actions and their payloads:
        - set_wallpaper: { "action": "set_wallpaper", "payload": { "url": "A URL of an image that matches the user's description." } }
        - set_dock_size: { "action": "set_dock_size", "payload": { "value": <number_between_40_and_80> } }
        - set_theme: { "action": "set_theme", "payload": { "mode": "'light' or 'dark'", "accentColor": "<hex_code>" } }
        Based on the user's query: "${searchQuery}"`;
        
        try {
            const response = await aiService.generateContent(systemInstruction);
            const actionJson = JSON.parse(response.text.replace(/```json|```/g, ''));

            switch (actionJson.action) {
                case 'set_wallpaper':
                    setWallpaper(actionJson.payload.url);
                    break;
                case 'set_dock_size':
                    setDockSize(actionJson.payload.value);
                    break;
                case 'set_theme':
                    setTheme(prev => ({ ...prev, ...actionJson.payload }));
                    break;
            }
            setSearchQuery('');
        } catch (error) {
            console.error("AI command failed:", error);
            // Handle error (e.g., show a message to the user)
        } finally {
            setIsLoading(false);
        }
    };
    
    const settingsCategories = [
        { id: 'appearance', name: 'Appearance', icon: '🎨', description: 'Wallpaper, display' },
        { id: 'themes', name: 'Themes', icon: '🖌️', description: 'Colors, mode, effects' },
        { id: 'focus', name: 'Focus', icon: '🧘', description: 'Modes, wellbeing' },
        { id: 'dock', name: 'Dock & Menu Bar', icon: '📏', description: 'Size, magnification' },
        { id: 'network', name: 'Network', icon: '🌐', description: 'Simulate connection' },
        { id: 'about', name: 'About', icon: 'ℹ️', description: `About ${OS_NAME}` },
    ];

    const renderPanel = () => {
        switch (activePanel) {
            case 'appearance': return <AppearancePanel />;
            case 'themes': return <ThemesPanel />;
            case 'focus': return <FocusPanel />;
            case 'dock': return <DockPanel />;
            case 'network': return <NetworkPanel />;
            case 'about': return <AboutPanel />;
            case 'grid':
            default:
                return (
                     <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {settingsCategories.map(cat => (
                            <button key={cat.id} onClick={() => setActivePanel(cat.id as PanelId)} className="bg-gray-100 hover:bg-gray-200 p-4 rounded-xl text-left flex items-center gap-4">
                                <span className="text-2xl bg-gray-200 p-2 rounded-lg">{cat.icon}</span>
                                <div>
                                    <h3 className="font-semibold">{cat.name}</h3>
                                    <p className="text-xs text-mac-text-secondary">{cat.description}</p>
                                </div>
                            </button>
                        ))}
                    </div>
                );
        }
    };

    return (
        <div className="w-full h-full bg-mac-gray flex flex-col">
            <header className="flex-shrink-0 h-20 p-4 flex items-center gap-4 border-b border-black/10">
                {activePanel !== 'grid' && (
                    <button onClick={() => setActivePanel('grid')} className="p-2 rounded-lg hover:bg-gray-200 text-xl">‹</button>
                )}
                <div className="relative flex-grow">
                     <input
                        type="text"
                        value={searchQuery}
                        onChange={e => setSearchQuery(e.target.value)}
                        onKeyDown={e => e.key === 'Enter' && handleAiCommand()}
                        placeholder="IntelliSearch: Ask to change a setting..."
                        className="w-full pl-10 pr-4 py-2 bg-gray-200 rounded-lg border-2 border-transparent focus:border-accent focus:ring-0 focus:outline-none transition-all"
                        disabled={isLoading}
                    />
                    <div className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
                         {isLoading ? <div className="w-5 h-5 border-2 border-gray-400 border-t-transparent rounded-full animate-spin"/> : '✨'}
                    </div>
                </div>
            </header>
            <main className="flex-grow p-6 overflow-y-auto">
                {renderPanel()}
            </main>
        </div>
    );
};