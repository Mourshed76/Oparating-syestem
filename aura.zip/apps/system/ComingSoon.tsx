import React from 'react';

export const ComingSoonApp: React.FC = () => {
    return (
        <div className="w-full h-full flex flex-col items-center justify-center text-center p-8 text-mac-text-secondary bg-mac-gray">
            <div className="text-6xl mb-4">🚧</div>
            <h1 className="text-2xl font-semibold text-mac-text">Coming Soon!</h1>
            <p className="mt-2 max-w-md">
                This app is currently under construction. Please check back later!
            </p>
        </div>
    );
};
