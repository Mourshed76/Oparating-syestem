import React from 'react';

export interface User {
    id: string;
    username: string;
    password?: string; // It's a simulation, so password is not stored securely.
    isAI?: boolean;
    bio: string;
    friends: string[];
    friendRequests: { from: string, to: string }[];
    coverPhotoSeed: string;
}

export type AppCategory = 'System' | 'Productivity' | 'Entertainment' | 'Games';

export interface OSAction {
  action: 'open_app' | 'set_wallpaper' | 'set_dock_size' | 'set_theme';
  payload: {
    appId?: string;
    filePath?: string; // Optional: for opening a file with its default app
    url?: string;
    value?: any;
  };
}

export interface AppProps {
    windowId: string;
    onExecuteAction?: (action: OSAction) => void;
    filePath?: string; // To open a specific file
}

export interface AppDefinition {
  id: string;
  name: string;
  icon: React.ReactNode;
  component: React.ComponentType<AppProps>;
  defaultSize?: { width: number; height: number };
  description: string;
  category: AppCategory;
  sizeMB: number;
  allowMultiInstance?: boolean;
}

export interface WindowInstance {
  id: string;
  appId: string;
  title: string;
  x: number;
  y: number;
  width: number;
  height: number;
  zIndex: number;
  isMinimized: boolean;
  isMaximized: boolean;
  isFullScreen: boolean;
  preMaximizedState?: { x: number, y: number, width: number, height: number };
  component: React.ComponentType<AppProps>;
  icon: React.ReactNode;
  filePath?: string; // To pass file path to the app component
}

export type WindowPair = string[];

export type ShelfItemType = 'text' | 'image' | 'file';
export interface ShelfItem {
    id: string;
    type: ShelfItemType;
    data: string; // content for text, URL for image, or path for file
    name?: string; // for files
}

export interface ChecklistItem {
    id:string;
    text: string;
    completed: boolean;
}

// --- Notes App Types ---
export interface Note {
    id: string;
    folderId: string | null; // null for root notes
    title: string;
    content: string; // Can be plain text, HTML, or JSON for checklists
    updatedAt: number;
    type: 'text' | 'checklist';
}

export interface NoteFolder {
    id:string;
    name: string;
}

export interface NotesState {
    notes: Note[];
    folders: NoteFolder[];
}

// --- Mail App Types ---
export interface Email {
    id: string;
    senderName: string;
    senderEmail: string;
    subject: string;
    body: string;
    timestamp: number;
    isRead: boolean;
    mailbox: 'inbox' | 'sent' | 'trash';
}


// --- Browser App Types ---
export interface Tab {
    id: string;
    title: string;
    type: 'home' | 'webpage' | 'search' | 'history';
    history: string[]; // URLs only
    historyIndex: number;
    isLoading: boolean;
    favicon?: string;
    searchQuery?: string;
    searchResult?: SearchResult | null;
    error?: string | null;
    groupId?: string | null;
}

export interface TabGroup {
    id: string;
    name: string;
    color: string;
}

export interface GroundingChunk {
    web?: {
        uri?: string;
        title?: string;
    };
}

export interface SearchResult {
    summary: string;
    links: GroundingChunk[];
}

export interface Bookmark {
    id: string;
    url: string;
    title: string;
    favicon: string;
}

export interface HistoryItem {
    id: string;
    url: string;
    title: string;
    timestamp: number;
}

export interface BrowserState {
    bookmarks: Bookmark[];
    history: HistoryItem[];
    tabGroups: TabGroup[];
}

// --- Photos App Types ---
export interface Photo {
    id: string; // The seed used for picsum
    albumIds: string[];
    addedAt: number;
}
export interface PhotoAlbum {
    id:string;
    name: string;
    coverPhotoId?: string;
}
export interface PhotosState {
    photos: Photo[];
    albums: PhotoAlbum[];
    privateAlbumPassword?: string;
}

// --- VFS Types for Finder ---
export type VFSItemType = 'file' | 'folder' | 'app';

export interface VFSBase {
  id: string;
  name: string;
  parentId: string | null;
  path: string;
}

export interface VFSFile extends VFSBase {
  type: 'file';
  content?: string; // For text files
  size: number; // in bytes
  createdAt: number;
  modifiedAt: number;
  appId?: string; // Default app to open this file
}

export interface VFSFolder extends VFSBase {
  type: 'folder';
  children: string[]; // Array of children IDs
}

export type VFSItem = VFSFile | VFSFolder;

export interface VFS {
  items: Record<string, VFSItem>;
  rootId: string;
  homeId: string;
  desktopId: string;
  documentsId: string;
  downloadsId: string;
  trashId: string;
}

// --- ConnectSphere (Social Media) App Types ---
export interface ConnectSphereComment {
    id: string;
    authorId: string;
    authorName: string;
    content: string;
    timestamp: number;
}

export interface ConnectSpherePost {
    id: string;
    authorId: string;
    authorName: string;
    content: string;
    imageUrl?: string;
    timestamp: number;
    likes: number;
    likedBy: string[];
    comments: ConnectSphereComment[];
}

export interface DirectMessage {
    id: string;
    senderId: string;
    content: string;
    timestamp: number;
}

export interface Conversation {
    id: string; // combination of two user IDs
    participants: [string, string];
    messages: DirectMessage[];
}

export interface ConnectSphereState {
    posts: ConnectSpherePost[];
    conversations: Conversation[];
}

// --- System Settings ---
export type NetworkSpeed = 'fast' | 'medium' | 'slow' | 'offline';

export interface ThemeSettings {
    accentColor: string;
    mode: 'light' | 'dark';
    glassmorphism: boolean;
}

export interface FocusMode {
    id: string;
    name: string;
    icon: string;
    settings: {
        hideDesktopIcons?: boolean;
        hideDock?: boolean;
    }
}

// --- Game-related Types ---
export type GameState = 'menu' | 'playing' | 'paused' | 'gameOver' | 'won';


// --- Kingdoms: Ascendancy Game Types ---
export type ResourceId = 'wood' | 'gold' | 'food' | 'stone';

export interface KingdomsResources {
  wood: number;
  gold: number;
  food: number;
  stone: number;
  population: number;
  maxPopulation: number;
}

export interface PlacedBuilding {
  id: string;
  type: string;
  x: number;
  y: number;
  level: number;
  owner: 'player' | 'enemy';
  health: number;
  maxHealth: number;
  isConstructing: boolean;
  constructionProgress: number;
  trainingQueue: { unitType: string; progress: number, id: string }[];
}

export type UnitTaskType = 'idle' | 'move' | 'gather' | 'attack' | 'build' | 'return';
export interface UnitTask {
  type: UnitTaskType;
  targetId?: string;
  targetPosition?: { x: number; y: number };
  resourceType?: ResourceId;
}

export interface GameUnit {
  id: string;
  type: 'villager' | 'swordsman' | 'archer';
  x: number;
  y: number;
  health: number;
  maxHealth: number;
  task: UnitTask;
  owner: 'player' | 'enemy';
  resourceAmount: number;
  attackCooldown: number;
}

export interface ResourceNode {
  id: string;
  type: ResourceId;
  x: number;
  y: number;
  amount: number;
}

export interface AiState {
    attackWaveCooldown: number;
    state: 'expanding' | 'attacking' | 'defending';
    scoutTarget: {x: number; y: number} | null;
}

export interface KingdomsAscendancyState {
  resources: KingdomsResources;
  enemyResources: KingdomsResources;
  buildings: PlacedBuilding[];
  units: GameUnit[];
  resourceNodes: ResourceNode[];
  researchedTechs: string[];
  currentAge: 'Stone Age' | 'Bronze Age';
  lastUpdated: number;
  gameSpeed: number;
  aiState: AiState;
  notifications: {id: string, message: string, timestamp: number}[];
}

// --- Calendar App Types ---
export interface CalendarEvent {
    id: string;
    date: string; // YYYY-MM-DD
    title: string;
    color: 'blue' | 'green' | 'red' | 'purple';
}

// --- Music App Types ---
export interface MusicTrack {
    id: string;
    title: string;
    artist: string;
    duration: string;
}
export interface MusicAlbum {
    id: string;
    title: string;
    artist: string;
    coverSeed: string;
    tracks: MusicTrack[];
}

// --- TV App Types ---
export interface MediaItem {
    id: string;
    title: string;
    type: 'Movie' | 'Show';
    description: string;
    coverSeed: string;
}

// --- Contacts App Types ---
export interface Contact {
    id: string;
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    address: string;
    notes: string;
}
